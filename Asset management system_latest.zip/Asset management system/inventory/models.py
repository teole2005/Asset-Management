from datetime import date
from decimal import Decimal

from django.conf import settings
from django.core.exceptions import ValidationError
from django.core.validators import FileExtensionValidator, MinValueValidator
from django.db import IntegrityError, models, transaction
from django.db.models import F, Q

from .utils import add_months, days_until, next_due_date, years_to_months, years_used


ASSET_NUMBER_SEQUENCE_KEY = "asset_number_sequence"


class TimestampedModel(models.Model):
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    created_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
        related_name="%(class)s_created",
    )
    updated_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
        related_name="%(class)s_updated",
    )

    class Meta:
        abstract = True


class AssetStatus(models.TextChoices):
    AVAILABLE = "Available", "Available"
    ASSIGNED = "Assigned", "Assigned"
    UNDER_REPAIR = "Under Repair", "Under Repair"
    RETIRED = "Retired", "Retired"
    SOLD = "Sold", "Sold"
    DISPOSED = "Disposed", "Disposed"


class AssetCondition(models.TextChoices):
    NEW = "New", "New"
    GOOD = "Good", "Good"
    FAIR = "Fair", "Fair"
    NEEDS_ATTENTION = "Needs Attention", "Needs Attention"
    DAMAGED = "Damaged", "Damaged"


class PhysicalAuditResult(models.TextChoices):
    FOUND = "found", "Found"
    MISSING = "missing", "Missing"


class SaleDisposalAction(models.TextChoices):
    SOLD = "sold", "Sold"
    DISPOSED = "disposed", "Disposed"


class ImportBatchStatus(models.TextChoices):
    UPLOADED = "uploaded", "Uploaded"
    DRY_RUN_OK = "dry_run_ok", "Dry Run OK"
    DRY_RUN_FAILED = "dry_run_failed", "Dry Run Failed"
    COMMITTED = "committed", "Committed"
    FAILED = "failed", "Failed"


class BackupBundleKind(models.TextChoices):
    MANUAL = "manual", "Manual"
    NIGHTLY = "nightly", "Nightly"
    PRE_RESTORE = "pre_restore", "Pre-Restore Safety Backup"


class Department(models.Model):
    name = models.CharField(max_length=200, unique=True)
    code = models.CharField(max_length=20, blank=True)

    class Meta:
        ordering = ["name"]

    def __str__(self):
        return self.name


class Location(models.Model):
    name = models.CharField(max_length=200, unique=True)
    description = models.CharField(max_length=255, blank=True)

    class Meta:
        ordering = ["name"]

    def __str__(self):
        return self.name


class Vendor(models.Model):
    name = models.CharField(max_length=200, unique=True)
    email = models.EmailField(blank=True)
    phone = models.CharField(max_length=50, blank=True)
    notes = models.TextField(blank=True)

    class Meta:
        ordering = ["name"]

    def __str__(self):
        return self.name


class AssetType(models.Model):
    name = models.CharField(max_length=100, unique=True)

    class Meta:
        ordering = ["name"]

    def __str__(self):
        return self.name


class StaffMember(models.Model):
    name = models.CharField(max_length=200)
    email = models.EmailField(blank=True)
    employee_id = models.CharField(max_length=50, blank=True, unique=True, null=True)
    department = models.ForeignKey(
        Department,
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
        related_name="staff_members",
    )
    location = models.ForeignKey(
        Location,
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
        related_name="staff_members",
    )
    is_active = models.BooleanField(default=True)

    class Meta:
        ordering = ["name"]
        constraints = [
            models.UniqueConstraint(
                fields=["name", "email"],
                name="uniq_staff_member_name_email",
            ),
        ]

    def clean(self):
        if self.employee_id == "":
            self.employee_id = None

    def __str__(self):
        return self.name


class ImportBatch(TimestampedModel):
    batch_id = models.CharField(max_length=40, unique=True)
    source_file = models.FileField(upload_to="imports/source/")
    source_filename = models.CharField(max_length=255)
    source_format = models.CharField(max_length=10, blank=True)
    status = models.CharField(
        max_length=20,
        choices=ImportBatchStatus.choices,
        default=ImportBatchStatus.UPLOADED,
    )
    source_headers = models.JSONField(default=list, blank=True)
    column_mapping = models.JSONField(default=dict, blank=True)
    preview_rows = models.JSONField(default=list, blank=True)
    row_errors = models.JSONField(default=list, blank=True)
    duplicate_rows = models.JSONField(default=list, blank=True)
    summary = models.JSONField(default=dict, blank=True)
    committed_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        ordering = ["-created_at"]

    def __str__(self):
        return self.batch_id


class Asset(TimestampedModel):
    legacy_no = models.CharField(max_length=50, blank=True)
    type = models.ForeignKey(AssetType, on_delete=models.PROTECT, related_name="assets")
    owner = models.CharField(max_length=200, blank=True)
    tracking_code = models.CharField(max_length=100, unique=True)
    asset_tag = models.CharField(max_length=100, unique=True)
    brand = models.CharField(max_length=100)
    model = models.CharField(max_length=100)
    serial_no = models.CharField(max_length=150, blank=True)
    price = models.DecimalField(
        max_digits=12,
        decimal_places=2,
        validators=[MinValueValidator(Decimal("0"))],
    )
    purchase_date = models.DateField()
    estimate_lifespan_years = models.DecimalField(
        max_digits=5,
        decimal_places=2,
        verbose_name="Estimate lifespan (years)",
        validators=[MinValueValidator(Decimal("0.01"))],
    )
    start_date = models.DateField(null=True, blank=True)
    warranty_expiry_date = models.DateField(null=True, blank=True)
    vendor = models.ForeignKey(
        Vendor,
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
        related_name="assets",
    )
    invoice_no = models.CharField(max_length=100, blank=True)
    condition = models.CharField(
        max_length=30,
        choices=AssetCondition.choices,
        default=AssetCondition.GOOD,
    )
    status = models.CharField(
        max_length=30,
        choices=AssetStatus.choices,
        default=AssetStatus.AVAILABLE,
    )
    current_location = models.ForeignKey(
        Location,
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
        related_name="assets",
    )
    department = models.ForeignKey(
        Department,
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
        related_name="assets",
    )
    custodian_it_owner = models.ForeignKey(
        StaffMember,
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
        related_name="owned_assets",
    )
    specs_json = models.JSONField(default=dict, blank=True)
    import_batch = models.ForeignKey(
        ImportBatch,
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
        related_name="assets",
    )

    class Meta:
        ordering = ["tracking_code"]
        constraints = [
            models.UniqueConstraint(
                fields=["legacy_no"],
                condition=~Q(legacy_no=""),
                name="uniq_asset_number_nonblank",
            ),
            models.UniqueConstraint(
                fields=["serial_no"],
                condition=~Q(serial_no=""),
                name="uniq_asset_nonblank_serial_no",
            ),
            models.CheckConstraint(
                condition=Q(price__gte=0),
                name="asset_price_nonnegative",
            ),
            models.CheckConstraint(
                condition=Q(estimate_lifespan_years__gt=0),
                name="asset_lifespan_years_positive",
            ),
            models.CheckConstraint(
                condition=(
                    Q(warranty_expiry_date__isnull=True)
                    | Q(warranty_expiry_date__gte=F("purchase_date"))
                ),
                name="asset_warranty_after_purchase",
            ),
            models.CheckConstraint(
                condition=Q(start_date__isnull=True) | Q(start_date__gte=F("purchase_date")),
                name="asset_start_after_purchase",
            ),
        ]

    @staticmethod
    def _parse_asset_number(value):
        text = str(value).strip()
        if not text:
            return None
        if not text.isdigit():
            return None
        return int(text)

    @classmethod
    def _current_max_assigned_number(cls):
        numbers = [
            parsed
            for parsed in (cls._parse_asset_number(value) for value in cls.objects.values_list("legacy_no", flat=True))
            if parsed is not None
        ]
        return max(numbers, default=0)

    @classmethod
    def _reserve_next_asset_number(cls):
        while True:
            try:
                with transaction.atomic():
                    setting, _created = SystemSetting.objects.select_for_update().get_or_create(
                        key=ASSET_NUMBER_SEQUENCE_KEY,
                        defaults={"value": cls._current_max_assigned_number()},
                    )
                    current = cls._parse_asset_number(setting.value)
                    if current is None:
                        current = cls._current_max_assigned_number()
                    next_number = current + 1
                    setting.value = next_number
                    setting.save(update_fields=["value"])
                    return str(next_number)
            except IntegrityError:
                continue

    def _stored_asset_number(self):
        if not self.pk:
            return ""
        return type(self).objects.filter(pk=self.pk).values_list("legacy_no", flat=True).first() or ""

    def clean(self):
        if not self.asset_tag:
            self.asset_tag = self.tracking_code
        stored_number = self._stored_asset_number()
        if stored_number and self.legacy_no != stored_number:
            raise ValidationError({"legacy_no": "Number is assigned automatically and cannot be changed."})
        if self.warranty_expiry_date and self.warranty_expiry_date < self.purchase_date:
            raise ValidationError(
                {"warranty_expiry_date": "Warranty expiry must be on or after the purchase date."}
            )
        if self.start_date and self.start_date < self.purchase_date:
            raise ValidationError(
                {"start_date": "Start date must be on or after the purchase date."}
            )

    def save(self, *args, **kwargs):
        update_fields = kwargs.get("update_fields")
        stored_number = self._stored_asset_number()
        if stored_number:
            if self.legacy_no != stored_number:
                raise ValidationError({"legacy_no": "Number is assigned automatically and cannot be changed."})
            self.legacy_no = stored_number
        else:
            self.legacy_no = self._reserve_next_asset_number()
            if update_fields is not None:
                kwargs["update_fields"] = set(update_fields) | {"legacy_no"}
        return super().save(*args, **kwargs)

    def __str__(self):
        return f"{self.tracking_code} - {self.brand} {self.model}"

    @property
    def lifespan_months(self):
        return years_to_months(self.estimate_lifespan_years)

    @property
    def expiry_date(self):
        return add_months(self.purchase_date, self.lifespan_months)

    @property
    def used_years(self):
        return years_used(self.start_date or self.purchase_date)

    @property
    def replacement_flag(self):
        if self.status in {AssetStatus.RETIRED, AssetStatus.SOLD, AssetStatus.DISPOSED}:
            return self.status
        return "Due" if self.replacement_due_soon else "Healthy"

    @property
    def current_assignee(self):
        assignment = self.assignments.filter(returned_at__isnull=True).select_related("staff_member").first()
        return assignment.staff_member if assignment else None

    @property
    def replacement_due_soon(self):
        remaining = days_until(self.expiry_date)
        return remaining is not None and remaining <= settings.REPLACEMENT_DUE_SOON_DAYS

    @property
    def warranty_due_soon(self):
        remaining = days_until(self.warranty_expiry_date)
        return remaining is not None and remaining <= settings.WARRANTY_DUE_SOON_DAYS

    @property
    def last_audit_at(self):
        latest = self.physical_audits.order_by("-audited_at").first()
        return latest.audited_at.date() if latest else None

    @property
    def next_audit_due_at(self):
        reference_date = self.last_audit_at or self.created_at.date()
        return next_due_date(reference_date, settings.PHYSICAL_AUDIT_CADENCE_DAYS)

    @property
    def audit_due_soon(self):
        remaining = days_until(self.next_audit_due_at)
        return remaining is not None and remaining <= settings.AUDIT_DUE_SOON_DAYS

    @property
    def has_open_repair(self):
        return self.repairs.filter(closed_at__isnull=True).exists()


class Assignment(TimestampedModel):
    asset = models.ForeignKey(Asset, on_delete=models.PROTECT, related_name="assignments")
    staff_member = models.ForeignKey(
        StaffMember,
        on_delete=models.PROTECT,
        related_name="assignments",
    )
    assigned_at = models.DateField(default=date.today)
    returned_at = models.DateField(null=True, blank=True)
    notes = models.TextField(blank=True)

    class Meta:
        ordering = ["-assigned_at", "-created_at"]
        constraints = [
            models.UniqueConstraint(
                fields=["asset"],
                condition=Q(returned_at__isnull=True),
                name="uniq_active_assignment_per_asset",
            ),
            models.CheckConstraint(
                condition=Q(returned_at__isnull=True) | Q(returned_at__gte=F("assigned_at")),
                name="assignment_return_after_assign",
            ),
        ]

    def clean(self):
        if not self.asset_id:
            raise ValidationError("Assignment requires an asset.")
        if self.asset.status in {AssetStatus.SOLD, AssetStatus.DISPOSED}:
            raise ValidationError("Sold or disposed assets cannot be assigned.")
        if self.asset.repairs.filter(closed_at__isnull=True).exclude(pk=self.pk).exists():
            raise ValidationError("Assets under repair cannot be assigned.")

    def __str__(self):
        return f"{self.asset.tracking_code} -> {self.staff_member.name}"


class RepairLog(TimestampedModel):
    asset = models.ForeignKey(Asset, on_delete=models.PROTECT, related_name="repairs")
    vendor = models.ForeignKey(
        Vendor,
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
        related_name="repairs",
    )
    issue = models.TextField()
    resolution_notes = models.TextField(blank=True)
    opened_at = models.DateField(default=date.today)
    closed_at = models.DateField(null=True, blank=True)
    cost = models.DecimalField(
        max_digits=12,
        decimal_places=2,
        default=Decimal("0.00"),
        validators=[MinValueValidator(Decimal("0.00"))],
    )

    class Meta:
        ordering = ["-opened_at", "-created_at"]
        constraints = [
            models.UniqueConstraint(
                fields=["asset"],
                condition=Q(closed_at__isnull=True),
                name="uniq_open_repair_per_asset",
            ),
            models.CheckConstraint(
                condition=Q(closed_at__isnull=True) | Q(closed_at__gte=F("opened_at")),
                name="repair_close_after_open",
            ),
        ]

    def clean(self):
        if self.asset.status in {AssetStatus.SOLD, AssetStatus.DISPOSED}:
            raise ValidationError("Sold or disposed assets cannot be repaired.")

    def __str__(self):
        return f"Repair {self.asset.tracking_code}"


def attachment_upload_path(instance, filename):
    import uuid
    from pathlib import Path

    extension = Path(filename).suffix.lower()
    return f"attachments/{instance.asset_id}/{uuid.uuid4().hex}{extension}"


class Attachment(TimestampedModel):
    asset = models.ForeignKey(Asset, on_delete=models.PROTECT, related_name="attachments")
    file = models.FileField(
        upload_to=attachment_upload_path,
        validators=[FileExtensionValidator(["pdf", "jpg", "jpeg", "png"])],
    )
    original_name = models.CharField(max_length=255)
    content_type = models.CharField(max_length=100)
    size_bytes = models.PositiveIntegerField(default=0)
    sha256 = models.CharField(max_length=64)
    description = models.CharField(max_length=255, blank=True)

    class Meta:
        ordering = ["-created_at"]

    def __str__(self):
        return self.original_name


class SaleDisposal(TimestampedModel):
    asset = models.OneToOneField(Asset, on_delete=models.PROTECT, related_name="sale_disposal")
    action = models.CharField(max_length=10, choices=SaleDisposalAction.choices)
    recorded_at = models.DateField(default=date.today)
    suggested_price = models.DecimalField(max_digits=12, decimal_places=2)
    final_price = models.DecimalField(max_digits=12, decimal_places=2)
    notes = models.TextField(blank=True)

    class Meta:
        ordering = ["-recorded_at", "-created_at"]
        constraints = [
            models.CheckConstraint(
                condition=Q(suggested_price__gte=0) & Q(final_price__gte=0),
                name="sale_disposal_prices_nonnegative",
            ),
        ]

    def clean(self):
        if self.recorded_at and self.recorded_at < self.asset.purchase_date:
            raise ValidationError("Sale/disposal date cannot precede purchase date.")

    def __str__(self):
        return f"{self.get_action_display()} {self.asset.tracking_code}"


class PhysicalAudit(TimestampedModel):
    asset = models.ForeignKey(Asset, on_delete=models.PROTECT, related_name="physical_audits")
    result = models.CharField(max_length=10, choices=PhysicalAuditResult.choices)
    verified_location = models.ForeignKey(
        Location,
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
        related_name="physical_audits",
    )
    verified_condition = models.CharField(
        max_length=30,
        choices=AssetCondition.choices,
        default=AssetCondition.GOOD,
    )
    audited_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.PROTECT,
        related_name="physical_audits",
    )
    audited_at = models.DateTimeField()
    follow_up_action = models.TextField(blank=True)

    class Meta:
        ordering = ["-audited_at"]

    def __str__(self):
        return f"Audit {self.asset.tracking_code}"


class BackupBundle(TimestampedModel):
    bundle_id = models.CharField(max_length=40, unique=True)
    kind = models.CharField(max_length=20, choices=BackupBundleKind.choices)
    archive_name = models.CharField(max_length=255)
    archive_path = models.CharField(max_length=500)
    size_bytes = models.PositiveBigIntegerField(default=0)
    manifest = models.JSONField(default=dict, blank=True)
    sha256 = models.CharField(max_length=64)

    class Meta:
        ordering = ["-created_at"]

    def __str__(self):
        return self.bundle_id


class AuditEvent(models.Model):
    created_at = models.DateTimeField(auto_now_add=True)
    actor = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
        related_name="audit_events",
    )
    event_type = models.CharField(max_length=100)
    object_type = models.CharField(max_length=100, blank=True)
    object_id = models.CharField(max_length=100, blank=True)
    description = models.TextField(blank=True)
    metadata = models.JSONField(default=dict, blank=True)
    ip_address = models.CharField(max_length=50, blank=True)
    success = models.BooleanField(default=True)

    class Meta:
        ordering = ["-created_at"]

    def __str__(self):
        return f"{self.event_type} @ {self.created_at:%Y-%m-%d %H:%M}"


class SystemSetting(models.Model):
    key = models.CharField(max_length=100, unique=True)
    value = models.JSONField(default=dict, blank=True)

    class Meta:
        ordering = ["key"]

    def __str__(self):
        return self.key


class UserSecurityProfile(models.Model):
    user = models.OneToOneField(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name="security_profile",
    )
    permissions_version = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.user.get_username()
