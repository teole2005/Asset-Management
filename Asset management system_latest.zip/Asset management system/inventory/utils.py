import ast
import csv
import hashlib
import json
from datetime import date, datetime, timedelta
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
from pathlib import Path


SPEC_LABELS = {
    "cpu": "CPU",
    "ram": "RAM",
    "storage": "Storage",
    "printer_type": "Printer Type",
    "printer_color": "Printer Color",
    "connectivity": "Connectivity",
    "function": "Function",
    "monitor_size": "Monitor Size",
    "input_type": "Input Type",
}


def clean_text(value):
    if value is None:
        return ""
    return str(value).strip()


def spec_label(value):
    key = clean_text(value)
    if not key:
        return "Spec"
    if key.lower() in SPEC_LABELS:
        return SPEC_LABELS[key.lower()]
    if "_" in key or key == key.lower():
        return key.replace("_", " ").title()
    return key


def _spec_value_text(value):
    if value is None:
        return ""
    if isinstance(value, dict):
        parts = []
        for key, item in value.items():
            item_text = _spec_value_text(item)
            if item_text:
                parts.append(f"{spec_label(key)}: {item_text}")
        return "; ".join(parts)
    if isinstance(value, (list, tuple)):
        parts = [clean_text(item) for item in value if clean_text(item)]
        return ", ".join(parts)
    return clean_text(value)


def build_spec_items(raw_specs):
    if raw_specs in (None, "", {}, []):
        return []

    specs = raw_specs
    if isinstance(specs, str):
        text = specs.strip()
        if not text:
            return []
        for parser in (json.loads, ast.literal_eval):
            try:
                parsed = parser(text)
            except (TypeError, ValueError, SyntaxError):
                continue
            if isinstance(parsed, (dict, list, tuple)):
                specs = parsed
                break
        else:
            return [{"label": "Specs", "value": text}]

    if isinstance(specs, dict):
        items = []
        for key, value in specs.items():
            value_text = _spec_value_text(value)
            if value_text:
                items.append({"label": spec_label(key), "value": value_text})
        return items

    if isinstance(specs, (list, tuple)):
        items = []
        for entry in specs:
            if isinstance(entry, dict) and {"label", "value"}.issubset(entry):
                value_text = _spec_value_text(entry.get("value"))
                if value_text:
                    items.append(
                        {
                            "label": clean_text(entry.get("label")) or "Spec",
                            "value": value_text,
                        }
                    )
                continue
            value_text = _spec_value_text(entry)
            if value_text:
                items.append({"label": "Spec", "value": value_text})
        return items

    value_text = _spec_value_text(specs)
    if not value_text:
        return []
    return [{"label": "Specs", "value": value_text}]


def parse_date(value):
    if value in (None, ""):
        return None
    if isinstance(value, datetime):
        return value.date()
    if isinstance(value, date):
        return value
    text = clean_text(value)
    for fmt in ("%Y-%m-%d", "%d/%m/%Y", "%m/%d/%Y", "%d-%m-%Y"):
        try:
            return datetime.strptime(text, fmt).date()
        except ValueError:
            continue
    return None


def parse_currency(value):
    if value in (None, ""):
        return None
    if isinstance(value, Decimal):
        return value
    if isinstance(value, (int, float)):
        return Decimal(str(value))
    text = clean_text(value).replace("RM", "").replace(",", "")
    try:
        return Decimal(text)
    except InvalidOperation:
        return None


def parse_lifespan_years(value):
    if value in (None, ""):
        return None

    if isinstance(value, Decimal):
        raw_number = value
    elif isinstance(value, (int, float)):
        raw_number = Decimal(str(value))
    else:
        raw_number = None

    if raw_number is not None:
        if raw_number <= 0:
            return None
        if raw_number == raw_number.to_integral_value() and raw_number >= 12:
            return (raw_number / Decimal("12")).quantize(Decimal("0.01"))
        return raw_number.quantize(Decimal("0.01"))

    text = clean_text(value).lower()
    is_month_value = "month" in text
    is_year_value = "year" in text
    text = (
        text.replace("months", "")
        .replace("month", "")
        .replace("years", "")
        .replace("year", "")
        .strip()
    )
    try:
        number = Decimal(text)
    except InvalidOperation:
        return None
    if number <= 0:
        return None
    if is_month_value:
        return (number / Decimal("12")).quantize(Decimal("0.01"))
    if is_year_value:
        return number.quantize(Decimal("0.01"))
    if number == number.to_integral_value() and number >= 12:
        return (number / Decimal("12")).quantize(Decimal("0.01"))
    return number.quantize(Decimal("0.01"))


def years_to_months(value):
    if value in (None, ""):
        return None
    years = value if isinstance(value, Decimal) else Decimal(str(value))
    return int((years * Decimal("12")).quantize(Decimal("1"), rounding=ROUND_HALF_UP))


def add_months(value, months):
    if value is None or months is None:
        return None
    month_index = value.month - 1 + months
    year = value.year + month_index // 12
    month = month_index % 12 + 1
    max_days = [
        31,
        29 if year % 4 == 0 and (year % 100 != 0 or year % 400 == 0) else 28,
        31,
        30,
        31,
        30,
        31,
        31,
        30,
        31,
        30,
        31,
    ]
    day = min(value.day, max_days[month - 1])
    return date(year, month, day)


def years_used(start_date, end_date=None):
    if not start_date:
        return None
    end_date = end_date or date.today()
    return round((end_date - start_date).days / 365.25, 1)


def days_until(value, today=None):
    if not value:
        return None
    today = today or date.today()
    return (value - today).days


def hash_file(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for chunk in iter(lambda: handle.read(8192), b""):
            digest.update(chunk)
    return digest.hexdigest()


def csv_bytes(rows, headers):
    from io import StringIO

    stream = StringIO()
    writer = csv.DictWriter(stream, fieldnames=headers)
    writer.writeheader()
    for row in rows:
        writer.writerow(row)
    return stream.getvalue().encode("utf-8-sig")


def next_due_date(reference_date, cadence_days):
    if not reference_date:
        return None
    return reference_date + timedelta(days=cadence_days)


def make_json_safe(value):
    if isinstance(value, dict):
        return {str(key): make_json_safe(item) for key, item in value.items()}
    if isinstance(value, list):
        return [make_json_safe(item) for item in value]
    if isinstance(value, tuple):
        return [make_json_safe(item) for item in value]
    if isinstance(value, Decimal):
        return str(value)
    if isinstance(value, (date, datetime)):
        return value.isoformat()
    return value
