from django.urls import path

from . import views


urlpatterns = [
    path("login", views.login_view, name="login"),
    path("logout", views.logout_view, name="logout"),
    path("dashboard", views.dashboard_view, name="dashboard"),
    path("assets", views.asset_list_view, name="asset-list"),
    path("assets/new", views.asset_create_view, name="asset-create"),
    path("assets/<int:asset_id>", views.asset_detail_view, name="asset-detail"),
    path("assets/<int:asset_id>/edit", views.asset_update_view, name="asset-edit"),
    path("assets/<int:asset_id>/delete", views.asset_delete_view, name="asset-delete"),
    path("assets/<int:asset_id>/assign", views.asset_assign_view, name="asset-assign"),
    path("assignments/<int:assignment_id>/return", views.assignment_return_view, name="assignment-return"),
    path("assets/<int:asset_id>/repair", views.asset_repair_view, name="asset-repair"),
    path("repairs/<int:repair_id>/close", views.repair_close_view, name="repair-close"),
    path("assets/<int:asset_id>/sell", views.asset_sell_view, name="asset-sell"),
    path("attachments/<int:attachment_id>/download", views.attachment_download_view, name="attachment-download"),
    path("attachments/<int:attachment_id>/delete", views.attachment_delete_view, name="attachment-delete"),
    path("audits", views.audits_view, name="audits"),
    path("imports", views.imports_view, name="imports"),
    path("imports/<int:batch_id>", views.import_detail_view, name="import-detail"),
    path("exports", views.exports_view, name="exports"),
    path("backups", views.backups_view, name="backups"),
    path("backups/<int:bundle_id>/download", views.backup_download_view, name="backup-download"),
    path("backups/<int:bundle_id>/restore", views.backup_restore_view, name="backup-restore"),
    path("staff", views.staff_view, name="staff"),
    path("departments", views.departments_view, name="departments"),
    path("vendors", views.vendors_view, name="vendors"),
    path("admin-users", views.admin_users_view, name="admin-users"),
    path("settings", views.settings_view, name="settings"),
    path("audit-log", views.audit_log_view, name="audit-log"),
]
