import csv
import uuid
from pathlib import Path

from django.conf import settings
from django.core.exceptions import ValidationError
from django.db import transaction
from django.utils import timezone
from openpyxl import load_workbook

from .models import (
    Asset,
    AssetCondition,
    AssetStatus,
    AssetType,
    Department,
    ImportBatch,
    ImportBatchStatus,
    StaffMember,
)
from .permissions import require_admin_access
from .services import create_assignment, log_event, touch_instance
from .utils import clean_text, make_json_safe, parse_currency, parse_date, parse_lifespan_years


SUPPORTED_IMPORT_SUFFIXES = {".csv", ".xlsx"}
HEADER_SCAN_LIMIT = 50
FIELD_LABELS = [
    ("legacy_no", "Legacy No."),
    ("type_name", "Asset Type"),
    ("owner", "Owner"),
    ("tracking_code", "Tracking Code"),
    ("asset_tag", "Asset Tag"),
    ("brand", "Brand"),
    ("model", "Model"),
    ("serial_no", "Serial No."),
    ("price", "Price"),
    ("purchase_date", "Purchase Date"),
    ("estimate_lifespan_years", "Estimate Lifespan (Years)"),
    ("start_date", "Start Date"),
    ("warranty_expiry_date", "Warranty Expiry"),
    ("condition", "Condition"),
    ("assignment_status", "Assignment Status"),
    ("assignee_name", "Assignee"),
    ("department_name", "Department"),
    ("assignment_date", "Assignment Date"),
    ("cpu", "CPU"),
    ("ram", "RAM"),
    ("storage", "Storage"),
    ("printer_type", "Printer Type"),
    ("printer_color", "Printer Color"),
    ("connectivity", "Connectivity"),
    ("function", "Function"),
    ("monitor_size", "Monitor Size"),
    ("input_type", "Input Type"),
]

FIELD_CHOICES = [("", "Ignore")] + FIELD_LABELS
REQUIRED_FIELDS = {
    "type_name",
    "tracking_code",
    "brand",
    "model",
    "price",
    "purchase_date",
    "estimate_lifespan_years",
}
SPEC_FIELDS = {
    "cpu",
    "ram",
    "storage",
    "printer_type",
    "printer_color",
    "connectivity",
    "function",
    "monitor_size",
    "input_type",
}
FIELD_ERROR_LABELS = {
    "assignment_date": "assignment date",
    "asset_tag": "asset tag",
    "estimate_lifespan_years": "estimate lifespan",
    "price": "price",
    "purchase_date": "purchase date",
    "serial_no": "serial number",
    "start_date": "start date",
    "tracking_code": "tracking code",
    "type_name": "asset type",
    "warranty_expiry_date": "warranty expiry date",
}
ALIASES = {
    "no.": "legacy_no",
    "no": "legacy_no",
    "type": "type_name",
    "owner": "owner",
    "tracking code": "tracking_code",
    "asset tag": "asset_tag",
    "brand": "brand",
    "model": "model",
    "serial no.": "serial_no",
    "serial no": "serial_no",
    "price": "price",
    "purchase date": "purchase_date",
    "estimate lifespan": "estimate_lifespan_years",
    "estimate lifespan (years)": "estimate_lifespan_years",
    "expiry date": "warranty_expiry_date",
    "start date": "start_date",
    "assignment status": "assignment_status",
    "user's name": "assignee_name",
    "department": "department_name",
    "assignment date": "assignment_date",
    "cpu": "cpu",
    "ram": "ram",
    "storage": "storage",
    "printer type": "printer_type",
    "printer color": "printer_color",
    "connectivity": "connectivity",
    "function": "function",
    "monitor size": "monitor_size",
    "input type": "input_type",
}


def generate_batch_id():
    return f"IMP-{timezone.now():%Y%m%d}-{uuid.uuid4().hex[:6].upper()}"


def normalize_header(value):
    return clean_text(value).lower()


def _field_error_label(field_name):
    return FIELD_ERROR_LABELS.get(field_name, field_name.replace("_", " "))


def _is_missing_required_value(value):
    return value is None or value == ""


def _load_source_rows(path):
    suffix = Path(path).suffix.lower()
    if suffix not in SUPPORTED_IMPORT_SUFFIXES:
        raise ValidationError("Only CSV and XLSX files are supported.")

    try:
        if suffix == ".csv":
            with open(path, newline="", encoding="utf-8-sig") as handle:
                return list(csv.reader(handle))

        workbook = load_workbook(path, read_only=True, data_only=True)
        try:
            worksheet = workbook[workbook.sheetnames[0]]
            return list(worksheet.iter_rows(values_only=True))
        finally:
            workbook.close()
    except ValidationError:
        raise
    except Exception as exc:
        raise ValidationError("Could not read the import file. Upload a valid CSV or XLSX file.") from exc


def _detect_header_index(rows):
    if not rows:
        raise ValidationError("The import file is empty.")

    required_headers = {"tracking_code", "type_name"}
    for index, row in enumerate(rows[:HEADER_SCAN_LIMIT]):
        values = {
            ALIASES.get(normalize_header(value), normalize_header(value))
            for value in row
            if clean_text(value)
        }
        if required_headers.issubset(values):
            return index

    raise ValidationError("Could not detect a header row. Include at least Type and Tracking Code columns.")


def detect_headers_and_rows(path):
    rows = _load_source_rows(path)
    header_index = _detect_header_index(rows)
    headers = [clean_text(cell) for cell in rows[header_index]]
    data_rows = rows[header_index + 1 :]
    cleaned_headers = [header if header else f"column_{index + 1}" for index, header in enumerate(headers)]
    records = []
    for row_number, row in enumerate(data_rows, start=header_index + 2):
        row_values = list(row)
        if not any(clean_text(value) for value in row_values):
            continue
        records.append((row_number, dict(zip(cleaned_headers, row_values))))
    return cleaned_headers, records


def default_column_mapping(headers):
    return {header: ALIASES.get(normalize_header(header), "") for header in headers}


def _normalise_status(value):
    text = clean_text(value)
    if not text:
        return AssetStatus.AVAILABLE
    if text.lower() == "occupied":
        return AssetStatus.ASSIGNED
    if text in dict(AssetStatus.choices):
        return text
    return text


def normalize_import_row(row_number, row_data, mapping):
    normalized = {"row_number": row_number, "specs_json": {}}
    errors = []
    invalid_fields = set()
    reverse_mapping = {}
    for source_header, target_field in mapping.items():
        if target_field:
            reverse_mapping[target_field] = source_header

    for field_name, source_header in reverse_mapping.items():
        raw_value = row_data.get(source_header)
        if field_name in {"purchase_date", "start_date", "warranty_expiry_date", "assignment_date"}:
            normalized[field_name] = parse_date(raw_value)
            if clean_text(raw_value) and normalized[field_name] is None:
                invalid_fields.add(field_name)
                errors.append(f"{_field_error_label(field_name).capitalize()} is invalid.")
        elif field_name == "price":
            normalized[field_name] = parse_currency(raw_value)
            if clean_text(raw_value) and normalized[field_name] is None:
                invalid_fields.add(field_name)
                errors.append("Price is invalid.")
        elif field_name == "estimate_lifespan_years":
            normalized[field_name] = parse_lifespan_years(raw_value)
            if clean_text(raw_value) and normalized[field_name] is None:
                invalid_fields.add(field_name)
                errors.append("Estimate lifespan is invalid.")
        elif field_name == "assignment_status":
            normalized[field_name] = _normalise_status(raw_value)
        elif field_name in SPEC_FIELDS:
            normalized["specs_json"][field_name] = clean_text(raw_value)
        else:
            normalized[field_name] = clean_text(raw_value)

    normalized["asset_tag"] = normalized.get("asset_tag") or normalized.get("tracking_code")
    normalized["condition"] = normalized.get("condition") or AssetCondition.GOOD

    for field_name in REQUIRED_FIELDS:
        if _is_missing_required_value(normalized.get(field_name)):
            if field_name in invalid_fields:
                continue
            errors.append(f"{_field_error_label(field_name).capitalize()} is required.")
    if normalized.get("assignment_status") == AssetStatus.ASSIGNED:
        if not normalized.get("assignee_name"):
            errors.append("Assigned assets must include an assignee.")
        if not normalized.get("assignment_date"):
            errors.append("Assigned assets must include an assignment date.")
    if normalized.get("warranty_expiry_date") and normalized.get("purchase_date"):
        if normalized["warranty_expiry_date"] < normalized["purchase_date"]:
            errors.append("Warranty expiry date must be on or after purchase date.")
    if normalized.get("start_date") and normalized.get("purchase_date"):
        if normalized["start_date"] < normalized["purchase_date"]:
            errors.append("Start date must be on or after purchase date.")
    if normalized.get("assignment_status") not in dict(AssetStatus.choices):
        errors.append("Assignment status is invalid.")

    return normalized, errors


def _existing_values():
    return {
        "tracking_code": set(Asset.objects.values_list("tracking_code", flat=True)),
        "asset_tag": set(Asset.objects.values_list("asset_tag", flat=True)),
        "serial_no": set(Asset.objects.exclude(serial_no="").values_list("serial_no", flat=True)),
    }


def validate_batch(batch, mapping):
    headers, rows = detect_headers_and_rows(batch.source_file.path)
    existing_values = _existing_values()
    seen_values = {"tracking_code": set(), "asset_tag": set(), "serial_no": set()}
    preview_rows = []
    row_errors = []
    duplicate_rows = []
    valid_rows = []

    for row_number, row_data in rows:
        normalized, errors = normalize_import_row(row_number, row_data, mapping)
        for field_name in ("tracking_code", "asset_tag", "serial_no"):
            value = normalized.get(field_name)
            if not value:
                continue
            if value in seen_values[field_name]:
                duplicate_rows.append(
                    {"row_number": row_number, "field": field_name, "value": value, "source": "batch"}
                )
            if value in existing_values[field_name]:
                duplicate_rows.append(
                    {"row_number": row_number, "field": field_name, "value": value, "source": "database"}
                )
            seen_values[field_name].add(value)
        if errors:
            row_errors.append({"row_number": row_number, "errors": errors})
        valid_rows.append(normalized)
        if len(preview_rows) < settings.IMPORT_PREVIEW_LIMIT:
            preview_rows.append(make_json_safe(normalized))

    valid = not row_errors and not duplicate_rows
    summary = {
        "total_rows": len(valid_rows),
        "valid_rows": len(valid_rows) - len(row_errors),
        "invalid_rows": len(row_errors),
        "duplicate_count": len(duplicate_rows),
    }
    batch.source_headers = headers
    batch.column_mapping = mapping
    batch.preview_rows = preview_rows
    batch.row_errors = row_errors
    batch.duplicate_rows = duplicate_rows
    batch.summary = summary
    batch.status = ImportBatchStatus.DRY_RUN_OK if valid else ImportBatchStatus.DRY_RUN_FAILED
    batch.save(
        update_fields=[
            "source_headers",
            "column_mapping",
            "preview_rows",
            "row_errors",
            "duplicate_rows",
            "summary",
            "status",
            "updated_at",
        ]
    )
    return valid_rows, row_errors, duplicate_rows


def create_batch_from_upload(uploaded_file, actor):
    require_admin_access(actor)
    batch = ImportBatch(
        batch_id=generate_batch_id(),
        source_file=uploaded_file,
        source_filename=uploaded_file.name,
        source_format=Path(uploaded_file.name).suffix.lower().lstrip("."),
    )
    touch_instance(batch, actor)
    batch.save()
    try:
        headers, _ = detect_headers_and_rows(batch.source_file.path)
    except ValidationError:
        batch.source_file.delete(save=False)
        batch.delete()
        raise
    batch.source_headers = headers
    batch.column_mapping = default_column_mapping(headers)
    batch.save(update_fields=["source_headers", "column_mapping", "updated_at"])
    return batch


def commit_batch(batch, actor, request=None):
    require_admin_access(actor)
    if batch.status != ImportBatchStatus.DRY_RUN_OK:
        raise ValidationError("Run a successful dry run before committing.")

    valid_rows, row_errors, duplicate_rows = validate_batch(batch, batch.column_mapping)
    if row_errors or duplicate_rows:
        raise ValidationError("The batch contains errors and cannot be committed.")

    try:
        with transaction.atomic():
            for row in valid_rows:
                asset_type, _ = AssetType.objects.get_or_create(name=row["type_name"])
                department = None
                if row.get("department_name"):
                    department, _ = Department.objects.get_or_create(name=row["department_name"])
                asset = Asset(
                    legacy_no=row.get("legacy_no", ""),
                    type=asset_type,
                    owner=row.get("owner", ""),
                    tracking_code=row["tracking_code"],
                    asset_tag=row["asset_tag"],
                    brand=row["brand"],
                    model=row["model"],
                    serial_no=row.get("serial_no", ""),
                    price=row["price"],
                    purchase_date=row["purchase_date"],
                    estimate_lifespan_years=row["estimate_lifespan_years"],
                    start_date=row.get("start_date"),
                    warranty_expiry_date=row.get("warranty_expiry_date"),
                    condition=row.get("condition") or AssetCondition.GOOD,
                    status=AssetStatus.AVAILABLE,
                    department=department,
                    specs_json={key: value for key, value in row.get("specs_json", {}).items() if value},
                    import_batch=batch,
                )
                touch_instance(asset, actor)
                asset.full_clean()
                asset.save()

                if row.get("assignment_status") == AssetStatus.ASSIGNED:
                    staff_member, _ = StaffMember.objects.get_or_create(
                        name=row["assignee_name"],
                        email="",
                        defaults={"department": department},
                    )
                    create_assignment(
                        asset=asset,
                        staff_member=staff_member,
                        assigned_at=row["assignment_date"],
                        notes=f"Imported from batch {batch.batch_id}",
                        actor=actor,
                        request=request,
                    )

            batch.status = ImportBatchStatus.COMMITTED
            batch.committed_at = timezone.now()
            batch.save(update_fields=["status", "committed_at", "updated_at"])
            log_event(
                "import_committed",
                actor=actor,
                target=batch,
                request=request,
                description=f"Import batch {batch.batch_id} committed.",
                metadata=batch.summary,
            )
    except Exception as exc:
        batch.status = ImportBatchStatus.FAILED
        batch.committed_at = None
        batch.save(update_fields=["status", "committed_at", "updated_at"])
        log_event(
            "import_commit_failed",
            actor=actor,
            target=batch,
            request=request,
            description=f"Import batch {batch.batch_id} failed during commit.",
            metadata={"error": str(exc)},
            success=False,
        )
        raise

    return batch
