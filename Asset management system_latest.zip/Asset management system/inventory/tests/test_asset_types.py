from django.contrib.auth import get_user_model
from django.contrib.auth.models import Group
from django.test import TestCase
from django.urls import reverse

from inventory.asset_types import DEFAULT_ASSET_TYPE_NAMES
from inventory.forms import AssetForm
from inventory.models import AssetType


User = get_user_model()


class AssetTypeOptionsTests(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.user = User.objects.create_user(username="asset-type-admin", password="test-password-123")
        cls.user.groups.add(Group.objects.get(name="admin"))

    def setUp(self):
        self.client.force_login(self.user)

    def test_asset_form_includes_default_and_custom_asset_types(self):
        AssetType.objects.create(name="Server")

        form = AssetForm()

        self.assertEqual(list(form.fields["type"].queryset.values_list("name", flat=True)), ["Laptop", "Monitor", "Desktop", "Printer", "Server"])

    def test_asset_list_shows_custom_asset_types(self):
        AssetType.objects.create(name="Server")

        response = self.client.get(reverse("asset-list"))

        self.assertEqual(response.status_code, 200)
        for name in DEFAULT_ASSET_TYPE_NAMES:
            self.assertContains(response, f"{name}</option>")
        self.assertContains(response, "Server</option>")

    def test_asset_form_excludes_auto_assigned_number_field(self):
        form = AssetForm()

        self.assertNotIn("legacy_no", form.fields)
