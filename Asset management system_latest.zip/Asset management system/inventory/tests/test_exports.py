from datetime import date, timedelta
from decimal import Decimal
from io import BytesIO

from django.contrib.auth import get_user_model
from django.contrib.auth.models import Group
from django.test import TestCase
from django.urls import reverse
from django.utils import timezone
from openpyxl import load_workbook

from inventory.models import (
    Asset,
    AssetCondition,
    AssetStatus,
    AssetType,
    AuditEvent,
    Department,
    Location,
    SaleDisposal,
    StaffMember,
    Vendor,
)
from inventory.services import create_assignment, open_repair, record_physical_audit


User = get_user_model()


class ExportWorkflowTests(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.admin_group = Group.objects.get(name="admin")
        cls.super_group = Group.objects.get(name="super_admin")
        cls.admin_user = User.objects.create_user(username="export-admin", password="test-password-123")
        cls.admin_user.groups.add(cls.admin_group)
        cls.super_user = User.objects.create_user(username="export-super", password="test-password-123")
        cls.super_user.groups.add(cls.super_group)

        cls.asset_type = AssetType.objects.create(name="Laptop")
        cls.department = Department.objects.create(name="IT")
        cls.location = Location.objects.create(name="HQ")
        cls.staff_member = StaffMember.objects.create(
            name="Jane Doe",
            email="jane.doe@example.com",
            department=cls.department,
            location=cls.location,
        )
        cls.vendor = Vendor.objects.create(name="Fixit Vendor")

        cls.assigned_asset = cls._create_asset("TRK-ASSIGNED", "TAG-ASSIGNED", "SER-ASSIGNED")
        create_assignment(
            asset=cls.assigned_asset,
            staff_member=cls.staff_member,
            assigned_at=date.today() - timedelta(days=2),
            notes="Assigned for testing",
            actor=cls.admin_user,
        )
        cls.available_asset = cls._create_asset("TRK-AVAILABLE", "TAG-AVAILABLE", "SER-AVAILABLE")

        cls.repair_asset = cls._create_asset("TRK-REPAIR", "TAG-REPAIR", "SER-REPAIR")
        open_repair(
            asset=cls.repair_asset,
            issue="Battery replacement",
            opened_at=date.today() - timedelta(days=1),
            cost=Decimal("75.00"),
            vendor=cls.vendor,
            resolution_notes="Awaiting part",
            actor=cls.admin_user,
        )

        cls.sold_asset = cls._create_asset("TRK-SOLD", "TAG-SOLD", "SER-SOLD")
        cls.sold_asset.status = AssetStatus.SOLD
        cls.sold_asset.save(update_fields=["status"])
        SaleDisposal.objects.create(
            asset=cls.sold_asset,
            action="sold",
            recorded_at=date.today(),
            suggested_price=Decimal("150.00"),
            final_price=Decimal("175.00"),
            notes="Sold to staff",
        )

        cls.audit_asset = cls._create_asset("TRK-AUDIT", "TAG-AUDIT", "SER-AUDIT")
        record_physical_audit(
            asset=cls.audit_asset,
            result="found",
            verified_location=cls.location,
            verified_condition=AssetCondition.GOOD,
            audited_at=timezone.now(),
            follow_up_action="Matched asset tag.",
            actor=cls.admin_user,
        )

        AuditEvent.objects.create(
            actor=cls.super_user,
            event_type="login_failed",
            description="Invalid password",
            success=False,
            ip_address="10.0.0.5",
            metadata={"username": "someone"},
        )
        AuditEvent.objects.create(
            actor=cls.super_user,
            event_type="asset_updated",
            description="Updated asset record",
            success=True,
            ip_address="10.0.0.8",
        )

    @classmethod
    def _create_asset(cls, tracking_code, asset_tag, serial_no):
        return Asset.objects.create(
            type=cls.asset_type,
            tracking_code=tracking_code,
            asset_tag=asset_tag,
            brand="Dell",
            model="Latitude",
            serial_no=serial_no,
            price=Decimal("2400.00"),
            purchase_date=date.today() - timedelta(days=90),
            estimate_lifespan_years=Decimal("4.00"),
            department=cls.department,
            current_location=cls.location,
            created_by=cls.admin_user,
            updated_by=cls.admin_user,
        )

    def _xlsx_rows(self, response):
        workbook = load_workbook(BytesIO(response.content), read_only=True)
        try:
            worksheet = workbook.active
            return list(worksheet.iter_rows(values_only=True))
        finally:
            workbook.close()

    def test_assets_export_respects_filters_for_csv_and_xlsx(self):
        self.client.force_login(self.admin_user)

        csv_response = self.client.get(
            reverse("exports"),
            {
                "dataset": "assets",
                "format": "csv",
                "q": "TRK-ASSIGNED",
                "status": AssetStatus.ASSIGNED,
            },
        )
        self.assertEqual(csv_response.status_code, 200)
        csv_text = csv_response.content.decode("utf-8-sig")
        self.assertIn("TRK-ASSIGNED", csv_text)
        self.assertNotIn("TRK-AVAILABLE", csv_text)

        xlsx_response = self.client.get(
            reverse("exports"),
            {
                "dataset": "assets",
                "format": "xlsx",
                "q": "TRK-ASSIGNED",
                "status": AssetStatus.ASSIGNED,
            },
        )
        self.assertEqual(xlsx_response.status_code, 200)
        rows = self._xlsx_rows(xlsx_response)
        self.assertEqual(len(rows), 2)
        self.assertEqual(rows[1][0], "TRK-ASSIGNED")

    def test_operational_datasets_export_in_csv_and_xlsx(self):
        self.client.force_login(self.admin_user)
        expectations = {
            "assignments": "Assigned for testing",
            "repairs": "Battery replacement",
            "sales": "TRK-SOLD",
            "audits": "TRK-AUDIT",
        }

        for dataset, expected_value in expectations.items():
            csv_response = self.client.get(reverse("exports"), {"dataset": dataset, "format": "csv"})
            self.assertEqual(csv_response.status_code, 200, dataset)
            self.assertIn(expected_value, csv_response.content.decode("utf-8-sig"))

            xlsx_response = self.client.get(reverse("exports"), {"dataset": dataset, "format": "xlsx"})
            self.assertEqual(xlsx_response.status_code, 200, dataset)
            flattened = " ".join(str(value) for row in self._xlsx_rows(xlsx_response) for value in row if value is not None)
            self.assertIn(expected_value, flattened)

    def test_activity_export_is_super_admin_only_and_preserves_filters(self):
        self.client.force_login(self.admin_user)
        denied = self.client.get(reverse("exports"), {"dataset": "activity", "format": "csv"})
        self.assertEqual(denied.status_code, 403)

        self.client.force_login(self.super_user)
        csv_response = self.client.get(
            reverse("exports"),
            {
                "dataset": "activity",
                "format": "csv",
                "event_type": "login_failed",
                "success": "0",
            },
        )
        self.assertEqual(csv_response.status_code, 200)
        csv_text = csv_response.content.decode("utf-8-sig")
        self.assertIn("login_failed", csv_text)
        self.assertNotIn("asset_updated", csv_text)

        xlsx_response = self.client.get(
            reverse("exports"),
            {
                "dataset": "activity",
                "format": "xlsx",
                "event_type": "login_failed",
                "success": "0",
            },
        )
        self.assertEqual(xlsx_response.status_code, 200)
        rows = self._xlsx_rows(xlsx_response)
        self.assertEqual(len(rows), 2)
        self.assertEqual(rows[1][1], "login_failed")

        audit_log_response = self.client.get(reverse("audit-log"), {"event_type": "login_failed", "success": "0"})
        self.assertContains(
            audit_log_response,
            "/exports?dataset=activity&format=csv&event_type=login_failed&amp;success=0",
        )
        self.assertContains(
            audit_log_response,
            "/exports?dataset=activity&format=xlsx&event_type=login_failed&amp;success=0",
        )
