import shutil
import tempfile
from datetime import date
from decimal import Decimal
from pathlib import Path
from unittest.mock import patch

from django.conf import settings
from django.contrib.auth import get_user_model
from django.contrib.auth.models import Group
from django.core.exceptions import ValidationError
from django.core.files.uploadedfile import SimpleUploadedFile
from django.test import TestCase, override_settings
from django.urls import reverse

from inventory.imports import commit_batch, create_batch_from_upload, validate_batch
from inventory.models import Asset, AssetStatus, AssetType, ImportBatch, ImportBatchStatus


User = get_user_model()


@override_settings(ANTIVIRUS_COMMAND="")
class ImportWorkflowTests(TestCase):
    @classmethod
    def setUpClass(cls):
        cls._media_root = tempfile.mkdtemp(prefix="asset-import-tests-")
        cls._media_override = override_settings(MEDIA_ROOT=cls._media_root)
        cls._media_override.enable()
        super().setUpClass()

    @classmethod
    def tearDownClass(cls):
        super().tearDownClass()
        cls._media_override.disable()
        shutil.rmtree(cls._media_root, ignore_errors=True)

    @classmethod
    def setUpTestData(cls):
        cls.user = User.objects.create_user(username="import-admin", password="test-password-123")
        cls.user.groups.add(Group.objects.get(name="admin"))
        cls.asset_type = AssetType.objects.create(name="Laptop")
        cls.workbook_path = settings.BASE_DIR / "Asset_Search_listing_latest.xlsx"

    def setUp(self):
        self.client.force_login(self.user)

    def _csv_upload(self, content, filename="assets.csv"):
        return SimpleUploadedFile(filename, content.encode("utf-8"), content_type="text/csv")

    def _xlsx_upload(self, path=None):
        path = path or self.workbook_path
        return SimpleUploadedFile(
            path.name,
            path.read_bytes(),
            content_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        )

    def _mapping_post_data(self, batch, overrides=None, action="save_mapping"):
        overrides = overrides or {}
        data = {"action": action}
        for index, header in enumerate(batch.source_headers):
            data[f"map_{index}"] = overrides.get(header, batch.column_mapping.get(header, ""))
        return data

    def test_csv_header_detection_skips_preamble_and_mapping_persists(self):
        csv_text = "\n".join(
            [
                "Module,,,Asset Register",
                "Exported Date:,,,2026-03-10",
                "Type,Tracking Code,Brand,Model,Serial No.,Price,Purchase Date,Estimate Lifespan,Assignment Status",
                "Laptop,TRK-100,Dell,Latitude,SER-100,3200,2026-01-01,60 month,Available",
            ]
        )

        response = self.client.post(reverse("imports"), {"source_file": self._csv_upload(csv_text)})

        self.assertEqual(response.status_code, 302)
        batch = ImportBatch.objects.get()
        self.assertEqual(batch.source_headers[0], "Type")
        self.assertEqual(batch.column_mapping["Tracking Code"], "tracking_code")

        response = self.client.post(
            reverse("import-detail", args=[batch.pk]),
            self._mapping_post_data(batch, overrides={"Brand": "owner"}),
            follow=True,
        )

        self.assertEqual(response.status_code, 200)
        batch.refresh_from_db()
        self.assertEqual(batch.column_mapping["Brand"], "owner")

    def test_dry_run_reports_invalid_values_missing_required_fields_and_duplicates(self):
        Asset.objects.create(
            tracking_code="TRK-EXISTING",
            asset_tag="TAG-EXISTING",
            type=self.asset_type,
            brand="A",
            model="B",
            serial_no="SER-EXISTING",
            price=Decimal("1.00"),
            purchase_date=date.today(),
            estimate_lifespan_years=Decimal("1.00"),
        )

        csv_text = "\n".join(
            [
                "Type,Tracking Code,Asset Tag,Brand,Model,Serial No.,Price,Purchase Date,Estimate Lifespan,Assignment Status",
                "Laptop,TRK-NEW,,Dell,Latitude,SER-NEW,not-money,not-a-date,60 month,Available",
                "Laptop,,TAG-EXISTING,Dell,Latitude,SER-EXISTING,3200,2026-01-01,60 month,Available",
                "Laptop,TRK-NEW,AT-003,Dell,Latitude,SER-BATCH,3200,2026-01-01,60 month,Available",
                "Laptop,TRK-004,AT-004,Dell,Latitude,SER-BATCH,3200,2026-01-01,60 month,Available",
            ]
        )

        batch = create_batch_from_upload(self._csv_upload(csv_text), actor=self.user)
        valid_rows, row_errors, duplicate_rows = validate_batch(batch, batch.column_mapping)

        self.assertEqual(len(valid_rows), 4)
        self.assertEqual(valid_rows[0]["asset_tag"], "TRK-NEW")
        self.assertEqual(batch.status, ImportBatchStatus.DRY_RUN_FAILED)

        errors_by_row = {entry["row_number"]: entry["errors"] for entry in row_errors}
        self.assertIn("Price is invalid.", errors_by_row[2])
        self.assertIn("Purchase date is invalid.", errors_by_row[2])
        self.assertIn("Tracking code is required.", errors_by_row[3])

        duplicate_keys = {
            (entry["row_number"], entry["field"], entry["value"], entry["source"])
            for entry in duplicate_rows
        }
        self.assertIn((3, "asset_tag", "TAG-EXISTING", "database"), duplicate_keys)
        self.assertIn((3, "serial_no", "SER-EXISTING", "database"), duplicate_keys)
        self.assertIn((4, "tracking_code", "TRK-NEW", "batch"), duplicate_keys)
        self.assertIn((5, "serial_no", "SER-BATCH", "batch"), duplicate_keys)

    def test_commit_creates_assets_assignments_and_defaults_asset_tag(self):
        csv_text = "\n".join(
            [
                "Type,Tracking Code,Brand,Model,Serial No.,Price,Purchase Date,Estimate Lifespan,Assignment Status,User's Name,Department,Assignment Date",
                "Laptop,TRK-100,Dell,Latitude,SER-100,3200,2026-01-01,60 month,Occupied,Jane Doe,IT,2026-01-15",
            ]
        )

        batch = create_batch_from_upload(self._csv_upload(csv_text), actor=self.user)
        validate_batch(batch, batch.column_mapping)
        commit_batch(batch, actor=self.user)

        asset = Asset.objects.get(tracking_code="TRK-100")
        batch.refresh_from_db()
        self.assertEqual(asset.asset_tag, "TRK-100")
        self.assertEqual(asset.estimate_lifespan_years, Decimal("5.00"))
        self.assertEqual(asset.status, AssetStatus.ASSIGNED)
        self.assertEqual(asset.current_assignee.name, "Jane Doe")
        self.assertEqual(batch.status, ImportBatchStatus.COMMITTED)

    def test_commit_rolls_back_entire_batch_when_commit_fails(self):
        csv_text = "\n".join(
            [
                "Type,Tracking Code,Brand,Model,Serial No.,Price,Purchase Date,Estimate Lifespan,Assignment Status",
                "Laptop,TRK-101,Dell,Latitude,SER-101,3200,2026-01-01,60 month,Available",
                "Laptop,TRK-102,Dell,Latitude,SER-102,3200,2026-01-01,60 month,Available",
            ]
        )

        batch = create_batch_from_upload(self._csv_upload(csv_text), actor=self.user)
        validate_batch(batch, batch.column_mapping)

        with patch("inventory.imports.Asset.full_clean", side_effect=[None, ValidationError("forced failure")]):
            with self.assertRaises(ValidationError):
                commit_batch(batch, actor=self.user)

        batch.refresh_from_db()
        self.assertEqual(batch.status, ImportBatchStatus.FAILED)
        self.assertIsNone(batch.committed_at)
        self.assertEqual(Asset.objects.count(), 0)

    def test_import_detail_disables_commit_until_dry_run_succeeds(self):
        csv_text = "\n".join(
            [
                "Type,Tracking Code,Brand,Model,Serial No.,Price,Purchase Date,Estimate Lifespan,Assignment Status",
                "Laptop,TRK-201,Dell,Latitude,SER-201,3200,2026-01-01,60 month,Available",
            ]
        )

        batch = create_batch_from_upload(self._csv_upload(csv_text), actor=self.user)

        response = self.client.get(reverse("import-detail", args=[batch.pk]))
        self.assertContains(response, 'value="commit"')
        self.assertContains(response, 'disabled title="Run a clean dry run with no row errors or duplicates before committing."')
        self.assertContains(
            response,
            "Commit stays disabled until the batch has a successful dry run with no row errors or duplicates.",
        )

        validate_batch(batch, batch.column_mapping)
        batch.refresh_from_db()
        self.assertEqual(batch.status, ImportBatchStatus.DRY_RUN_OK)

        response = self.client.get(reverse("import-detail", args=[batch.pk]))
        self.assertContains(response, 'value="commit"')
        self.assertNotContains(
            response,
            'disabled title="Run a clean dry run with no row errors or duplicates before committing."',
        )
        self.assertNotContains(
            response,
            "Commit stays disabled until the batch has a successful dry run with no row errors or duplicates.",
        )

    def test_real_workbook_dry_run_uses_actual_header_row_and_reports_duplicates(self):
        self.assertTrue(self.workbook_path.exists(), f"Missing workbook fixture: {self.workbook_path}")

        batch = create_batch_from_upload(self._xlsx_upload(), actor=self.user)
        valid_rows, row_errors, duplicate_rows = validate_batch(batch, batch.column_mapping)

        self.assertEqual(batch.source_headers[:4], ["No.", "Type", "Owner", "Tracking Code"])
        self.assertEqual(batch.column_mapping["No."], "legacy_no")
        self.assertEqual(batch.column_mapping["Assignment Status"], "assignment_status")
        self.assertGreater(batch.summary["total_rows"], 200)
        self.assertEqual(len(valid_rows), batch.summary["total_rows"])
        self.assertEqual(batch.status, ImportBatchStatus.DRY_RUN_FAILED)

        errors_by_row = {entry["row_number"]: entry["errors"] for entry in row_errors}
        self.assertEqual(sorted(errors_by_row), [120, 121, 122, 125])
        self.assertIn("Estimate lifespan is invalid.", errors_by_row[120])
        self.assertIn("Warranty expiry date must be on or after purchase date.", errors_by_row[120])
        self.assertIn("Estimate lifespan is invalid.", errors_by_row[125])

        duplicate_keys = {(entry["field"], entry["value"], entry["source"]) for entry in duplicate_rows}
        self.assertIn(("tracking_code", "DT/MFM/083", "batch"), duplicate_keys)
        self.assertIn(("serial_no", "'CN71A3H207", "batch"), duplicate_keys)

        preview_row = next(row for row in batch.preview_rows if row["tracking_code"] == "LT/MFM/344")
        self.assertEqual(preview_row["assignment_status"], AssetStatus.ASSIGNED)
        self.assertEqual(preview_row["asset_tag"], "LT/MFM/344")
