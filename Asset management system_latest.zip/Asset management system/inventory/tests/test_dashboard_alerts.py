from datetime import date, timedelta
from decimal import Decimal
from io import StringIO

from django.contrib.auth import get_user_model
from django.contrib.auth.models import Group
from django.core import mail
from django.core.management import call_command
from django.test import Client, TestCase, override_settings
from django.urls import reverse
from django.utils import timezone

from inventory.models import (
    Asset,
    AssetCondition,
    AssetStatus,
    AssetType,
    AuditEvent,
    Department,
    Location,
    PhysicalAudit,
    PhysicalAuditResult,
    RepairLog,
)
from inventory.services import get_alert_recipient_list, get_setting, set_alert_recipient_list, set_setting


User = get_user_model()


@override_settings(
    EMAIL_BACKEND="django.core.mail.backends.locmem.EmailBackend",
    DEFAULT_FROM_EMAIL="alerts@example.test",
)
class DashboardAndAlertsTests(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.admin_group = Group.objects.get(name="admin")
        cls.super_group = Group.objects.get(name="super_admin")
        cls.admin_user = User.objects.create_user(username="dashboard-admin", password="test-password-123")
        cls.admin_user.groups.add(cls.admin_group)
        cls.super_user = User.objects.create_user(username="dashboard-super", password="test-password-123")
        cls.super_user.groups.add(cls.super_group)
        cls.asset_type = AssetType.objects.create(name="Laptop")
        cls.department = Department.objects.create(name="Operations")
        cls.location = Location.objects.create(name="HQ")

    def setUp(self):
        mail.outbox = []
        set_setting("maintenance_mode", False)
        set_alert_recipient_list("", actor=self.super_user)

    def create_asset(
        self,
        *,
        status=AssetStatus.AVAILABLE,
        purchase_days_ago=30,
        lifespan_years=Decimal("5.00"),
        warranty_days_from_today=365,
        invoice_no=None,
        audit_days_ago=30,
        created_days_ago=None,
        **overrides,
    ):
        today = date.today()
        asset_number = Asset.objects.count() + 1
        defaults = {
            "type": self.asset_type,
            "tracking_code": f"TRK-{asset_number}",
            "asset_tag": f"TAG-{asset_number}",
            "brand": "Dell",
            "model": "Latitude",
            "serial_no": f"SER-{asset_number}",
            "price": Decimal("2500.00"),
            "purchase_date": today - timedelta(days=purchase_days_ago),
            "estimate_lifespan_years": lifespan_years,
            "warranty_expiry_date": None if warranty_days_from_today is None else today + timedelta(days=warranty_days_from_today),
            "invoice_no": invoice_no if invoice_no is not None else f"INV-{asset_number}",
            "condition": AssetCondition.GOOD,
            "status": status,
            "department": self.department,
            "current_location": self.location,
            "created_by": self.admin_user,
            "updated_by": self.admin_user,
        }
        defaults.update(overrides)
        asset = Asset.objects.create(**defaults)

        created_days_ago = created_days_ago if created_days_ago is not None else max(
            purchase_days_ago,
            (audit_days_ago + 1) if audit_days_ago is not None else 1,
        )
        created_at = timezone.now() - timedelta(days=created_days_ago)
        Asset.objects.filter(pk=asset.pk).update(created_at=created_at, updated_at=created_at)
        asset.refresh_from_db()

        if audit_days_ago is not None:
            PhysicalAudit.objects.create(
                asset=asset,
                result=PhysicalAuditResult.FOUND,
                verified_location=self.location,
                verified_condition=AssetCondition.GOOD,
                audited_by=self.admin_user,
                audited_at=timezone.now() - timedelta(days=audit_days_ago),
                created_by=self.admin_user,
                updated_by=self.admin_user,
            )
        return asset

    def populate_operational_data(self):
        replacement_due_soon = self.create_asset(
            tracking_code="REP-SOON",
            asset_tag="REP-SOON",
            serial_no="REP-SOON",
            purchase_days_ago=300,
            lifespan_years=Decimal("1.00"),
            warranty_days_from_today=180,
        )
        replacement_overdue = self.create_asset(
            tracking_code="REP-OVER",
            asset_tag="REP-OVER",
            serial_no="REP-OVER",
            purchase_days_ago=430,
            lifespan_years=Decimal("1.00"),
            warranty_days_from_today=180,
        )
        audit_due_soon = self.create_asset(
            tracking_code="AUD-SOON",
            asset_tag="AUD-SOON",
            serial_no="AUD-SOON",
            purchase_days_ago=200,
            lifespan_years=Decimal("10.00"),
            warranty_days_from_today=200,
            audit_days_ago=340,
            created_days_ago=360,
        )
        audit_overdue = self.create_asset(
            tracking_code="AUD-OVER",
            asset_tag="AUD-OVER",
            serial_no="AUD-OVER",
            purchase_days_ago=220,
            lifespan_years=Decimal("10.00"),
            warranty_days_from_today=200,
            audit_days_ago=400,
            created_days_ago=430,
        )
        never_audited = self.create_asset(
            tracking_code="AUD-NEVER",
            asset_tag="AUD-NEVER",
            serial_no="AUD-NEVER",
            purchase_days_ago=50,
            lifespan_years=Decimal("10.00"),
            warranty_days_from_today=220,
            audit_days_ago=None,
            created_days_ago=20,
        )
        warranty_due_soon = self.create_asset(
            tracking_code="WAR-SOON",
            asset_tag="WAR-SOON",
            serial_no="WAR-SOON",
            purchase_days_ago=120,
            lifespan_years=Decimal("10.00"),
            warranty_days_from_today=10,
        )
        warranty_overdue = self.create_asset(
            tracking_code="WAR-OVER",
            asset_tag="WAR-OVER",
            serial_no="WAR-OVER",
            purchase_days_ago=150,
            lifespan_years=Decimal("10.00"),
            warranty_days_from_today=-5,
        )
        missing_invoice = self.create_asset(
            tracking_code="INV-MISS",
            asset_tag="INV-MISS",
            serial_no="INV-MISS",
            purchase_days_ago=80,
            lifespan_years=Decimal("10.00"),
            warranty_days_from_today=150,
            invoice_no="",
        )
        open_repair = self.create_asset(
            tracking_code="REP-OPEN",
            asset_tag="REP-OPEN",
            serial_no="REP-OPEN",
            purchase_days_ago=100,
            lifespan_years=Decimal("10.00"),
            warranty_days_from_today=140,
            status=AssetStatus.UNDER_REPAIR,
        )
        RepairLog.objects.create(
            asset=open_repair,
            issue="Motherboard replacement pending vendor quote",
            opened_at=date.today() - timedelta(days=7),
            cost=Decimal("0.00"),
            created_by=self.admin_user,
            updated_by=self.admin_user,
        )
        AuditEvent.objects.create(
            actor=self.admin_user,
            event_type="asset_updated",
            description="Asset REP-SOON updated.",
        )
        return {
            "replacement_due_soon": replacement_due_soon,
            "replacement_overdue": replacement_overdue,
            "audit_due_soon": audit_due_soon,
            "audit_overdue": audit_overdue,
            "never_audited": never_audited,
            "warranty_due_soon": warranty_due_soon,
            "warranty_overdue": warranty_overdue,
            "missing_invoice": missing_invoice,
            "open_repair": open_repair,
        }

    def test_dashboard_shows_operational_counts_and_separates_never_audited(self):
        assets = self.populate_operational_data()
        client = Client()
        client.force_login(self.admin_user)

        response = client.get(reverse("dashboard"))

        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.context["status_counts"][AssetStatus.AVAILABLE], 8)
        self.assertEqual(response.context["status_counts"][AssetStatus.UNDER_REPAIR], 1)
        self.assertEqual(response.context["due_replacement"], 2)
        self.assertEqual(response.context["due_audit"], 2)
        self.assertEqual(response.context["never_audited_count"], 1)
        self.assertEqual(response.context["warranty_due"], 1)
        self.assertEqual(response.context["warranty_overdue"], 1)
        self.assertEqual(response.context["open_repairs_count"], 1)
        self.assertEqual(response.context["missing_invoices"], 1)
        self.assertEqual(len(response.context["audit_due_soon_assets"]), 1)
        self.assertEqual(len(response.context["audit_overdue_assets"]), 1)
        self.assertEqual([item["asset"] for item in response.context["never_audited_assets"]], [assets["never_audited"]])
        audit_due_assets = [item["asset"] for item in response.context["audit_due_soon_assets"]]
        audit_due_assets += [item["asset"] for item in response.context["audit_overdue_assets"]]
        self.assertNotIn(assets["never_audited"], audit_due_assets)
        self.assertContains(response, "Never Audited")
        self.assertContains(response, "AUD-NEVER")
        self.assertContains(response, "Asset REP-SOON updated.")

    def test_settings_page_saves_maintenance_mode_and_alert_recipients(self):
        client = Client()
        client.force_login(self.super_user)

        response = client.post(
            reverse("settings"),
            {
                "maintenance_mode": "on",
                "alert_recipients": "ops@example.com\nalerts@example.com, ops@example.com",
            },
            follow=True,
        )

        self.assertEqual(response.status_code, 200)
        self.assertTrue(get_setting("maintenance_mode", False))
        self.assertEqual(
            get_alert_recipient_list(),
            ["ops@example.com", "alerts@example.com"],
        )
        self.assertTrue(AuditEvent.objects.filter(event_type="settings_updated", actor=self.super_user).exists())
        self.assertContains(response, "Maintenance mode enabled")
        self.assertContains(response, "ops@example.com")
        self.assertContains(response, "alerts@example.com")

    def test_settings_page_rejects_invalid_alert_recipient_addresses(self):
        client = Client()
        client.force_login(self.super_user)

        response = client.post(
            reverse("settings"),
            {
                "maintenance_mode": "",
                "alert_recipients": "not-an-email",
            },
        )

        self.assertEqual(response.status_code, 200)
        self.assertFormError(
            response.context["form"],
            "alert_recipients",
            "Enter valid email addresses only. Invalid: not-an-email",
        )
        self.assertEqual(get_alert_recipient_list(), [])

    def test_daily_alert_command_uses_configured_recipients_and_due_buckets(self):
        self.populate_operational_data()
        set_alert_recipient_list("ops@example.com, lead@example.com", actor=self.super_user)
        stdout = StringIO()

        call_command("send_daily_alerts", stdout=stdout)

        self.assertIn("Alerts sent to ops@example.com, lead@example.com", stdout.getvalue())
        self.assertEqual(len(mail.outbox), 1)
        email = mail.outbox[0]
        self.assertEqual(email.to, ["ops@example.com", "lead@example.com"])
        self.assertIn("Replacement due soon: 1", email.body)
        self.assertIn("Replacement overdue: 1", email.body)
        self.assertIn("Audit due soon: 1", email.body)
        self.assertIn("Audit overdue: 1", email.body)
        self.assertIn("Never audited: 1", email.body)
        self.assertIn("Warranty due soon: 1", email.body)
        self.assertIn("Warranty overdue: 1", email.body)
        self.assertIn("Open repairs: 1", email.body)
        self.assertIn("Missing invoices: 1", email.body)
        self.assertIn("REP-SOON", email.body)
        self.assertIn("AUD-NEVER", email.body)
        self.assertTrue(AuditEvent.objects.filter(event_type="daily_alerts_sent").exists())

    def test_daily_alert_command_skips_send_when_no_recipients_are_configured(self):
        self.populate_operational_data()
        stdout = StringIO()

        call_command("send_daily_alerts", stdout=stdout)

        self.assertIn("No alert recipients configured.", stdout.getvalue())
        self.assertEqual(len(mail.outbox), 0)
