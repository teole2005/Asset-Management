import base64
import shutil
import tempfile
from datetime import date, timedelta
from decimal import Decimal

from django.contrib.auth import get_user_model
from django.contrib.auth.models import Group
from django.core.exceptions import ValidationError
from django.core.files.uploadedfile import SimpleUploadedFile
from django.db import connection
from django.test import TestCase, override_settings
from django.urls import reverse
from django.utils import timezone

from inventory.models import (
    Asset,
    AssetCondition,
    AssetStatus,
    AssetType,
    Assignment,
    Attachment,
    AuditEvent,
    Department,
    Location,
    StaffMember,
    Vendor,
)
from inventory.services import create_assignment, create_attachment, open_repair, record_physical_audit, suggested_sale_price
from inventory.views import ASSET_LIST_PAGE_SIZE


User = get_user_model()
PNG_1X1 = base64.b64decode(
    "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO4B8t8AAAAASUVORK5CYII="
)


@override_settings(ANTIVIRUS_COMMAND="")
class IntegrityTests(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.admin_group = Group.objects.get(name="admin")
        cls.user = User.objects.create_user(username="admin-user", password="test-password-123")
        cls.user.groups.add(cls.admin_group)
        cls.asset_type, _ = AssetType.objects.get_or_create(name="Laptop")
        cls.department = Department.objects.create(name="IT")
        cls.location = Location.objects.create(name="HQ")
        cls.staff_member = StaffMember.objects.create(
            name="Jane Doe",
            email="jane@example.com",
            department=cls.department,
            location=cls.location,
        )

    def setUp(self):
        self.client.force_login(self.user)

    def create_asset(self, **overrides):
        defaults = {
            "type": self.asset_type,
            "tracking_code": f"TRK-{Asset.objects.count() + 1}",
            "asset_tag": f"TAG-{Asset.objects.count() + 1}",
            "brand": "Dell",
            "model": "Latitude",
            "serial_no": f"SER-{Asset.objects.count() + 1}",
            "price": Decimal("3200.00"),
            "purchase_date": date.today() - timedelta(days=30),
            "estimate_lifespan_years": Decimal("5.00"),
            "condition": AssetCondition.GOOD,
            "department": self.department,
            "current_location": self.location,
            "created_by": self.user,
            "updated_by": self.user,
        }
        defaults.update(overrides)
        return Asset.objects.create(**defaults)

    def asset_form_payload(self, **overrides):
        defaults = {
            "type": self.asset_type.pk,
            "owner": "",
            "tracking_code": f"TRK-FORM-{Asset.objects.count() + 1}",
            "asset_tag": f"TAG-FORM-{Asset.objects.count() + 1}",
            "brand": "Dell",
            "model": "Latitude",
            "serial_no": f"SER-FORM-{Asset.objects.count() + 1}",
            "price": "3200.00",
            "purchase_date": (date.today() - timedelta(days=30)).isoformat(),
            "estimate_lifespan_years": "5.00",
            "start_date": "",
            "warranty_expiry_date": "",
            "vendor": "",
            "invoice_no": "",
            "condition": AssetCondition.GOOD,
            "status": AssetStatus.AVAILABLE,
            "current_location": self.location.pk,
            "department": self.department.pk,
            "custodian_it_owner": self.staff_member.pk,
            "cpu": "",
            "ram": "",
            "storage": "",
            "printer_type": "",
            "printer_color": "",
            "connectivity": "",
            "function": "",
            "monitor_size": "",
            "input_type": "",
        }
        defaults.update(overrides)
        return defaults

    def test_sqlite_runtime_pragmas_enabled(self):
        with connection.cursor() as cursor:
            cursor.execute("PRAGMA foreign_keys;")
            foreign_keys = cursor.fetchone()[0]
            cursor.execute("PRAGMA journal_mode;")
            journal_mode = cursor.fetchone()[0]
        self.assertEqual(foreign_keys, 1)
        self.assertEqual(str(journal_mode).lower(), "wal")

    def test_asset_unique_and_date_constraints(self):
        asset = self.create_asset()
        duplicate = Asset(
            type=self.asset_type,
            tracking_code="TRK-2",
            asset_tag="TAG-2",
            brand="Dell",
            model="Latitude",
            serial_no=asset.serial_no,
            price=Decimal("1000.00"),
            purchase_date=date.today(),
            estimate_lifespan_years=Decimal("5.00"),
        )
        with self.assertRaises(ValidationError):
            duplicate.full_clean()

        invalid_dates = Asset(
            type=self.asset_type,
            tracking_code="TRK-3",
            asset_tag="TAG-3",
            brand="Dell",
            model="Latitude",
            serial_no="SER-3",
            price=Decimal("1000.00"),
            purchase_date=date.today(),
            estimate_lifespan_years=Decimal("5.00"),
            warranty_expiry_date=date.today() - timedelta(days=1),
        )
        with self.assertRaises(ValidationError):
            invalid_dates.full_clean()

    def test_assignment_and_repair_rules(self):
        asset = self.create_asset()
        assignment = create_assignment(asset, self.staff_member, date.today(), "", self.user)
        self.assertEqual(asset.assignments.filter(returned_at__isnull=True).count(), 1)

        with self.assertRaises(ValidationError):
            create_assignment(asset, self.staff_member, date.today(), "", self.user)

        open_repair(asset, "Battery replacement", date.today(), Decimal("0.00"), None, "", self.user)
        with self.assertRaises(ValidationError):
            open_repair(asset, "Screen", date.today(), Decimal("0.00"), None, "", self.user)

        assignment.returned_at = date.today()
        assignment.save(update_fields=["returned_at"])
        sold_asset = self.create_asset(
            tracking_code="TRK-SOLD",
            asset_tag="TAG-SOLD",
            serial_no="SER-SOLD",
            status=AssetStatus.SOLD,
        )
        inactive_staff = StaffMember.objects.create(name="Inactive", email="inactive@example.com", is_active=False)
        with self.assertRaises(ValidationError):
            create_assignment(self.create_asset(tracking_code="TRK-INACTIVE", asset_tag="TAG-INACTIVE", serial_no="SER-INACTIVE"), inactive_staff, date.today(), "", self.user)
        with self.assertRaises(ValidationError):
            create_assignment(sold_asset, self.staff_member, date.today(), "", self.user)

        response = self.client.get(reverse("asset-detail", args=[asset.pk]))
        self.assertContains(response, "Assignment History")
        self.assertContains(response, "Jane Doe")

    def test_assignment_validation_without_asset_raises_validation_error(self):
        assignment = Assignment(
            staff_member=self.staff_member,
            assigned_at=date.today(),
            notes="",
        )

        with self.assertRaises(ValidationError):
            assignment.full_clean()

    def test_asset_assign_view_posts_without_descriptor_error(self):
        asset = self.create_asset(tracking_code="TRK-ASSIGN", asset_tag="TAG-ASSIGN", serial_no="SER-ASSIGN")

        response = self.client.post(
            reverse("asset-assign", args=[asset.pk]),
            {
                "staff_member": self.staff_member.pk,
                "assigned_at": date.today().isoformat(),
                "notes": "",
            },
        )

        self.assertRedirects(response, reverse("asset-detail", args=[asset.pk]))
        asset.refresh_from_db()
        assignment = asset.assignments.get(returned_at__isnull=True)
        self.assertEqual(assignment.staff_member, self.staff_member)
        self.assertEqual(asset.status, AssetStatus.ASSIGNED)

    def test_computed_flags_and_suggested_price_floor(self):
        asset = self.create_asset(
            tracking_code="TRK-FLAG",
            asset_tag="TAG-FLAG",
            serial_no="SER-FLAG",
            purchase_date=date.today() - timedelta(days=365 * 6),
            estimate_lifespan_years=Decimal("1.00"),
            warranty_expiry_date=date.today() + timedelta(days=10),
        )
        self.assertTrue(asset.replacement_due_soon)
        self.assertTrue(asset.warranty_due_soon)
        self.assertIsNone(asset.last_audit_at)
        self.assertFalse(asset.audit_due_soon)
        self.assertEqual(suggested_sale_price(asset, date.today()), Decimal("320.00"))

    def test_asset_detail_formats_specs_as_cards_instead_of_raw_json_dump(self):
        asset = self.create_asset(
            tracking_code="TRK-SPECS",
            asset_tag="TAG-SPECS",
            serial_no="SER-SPECS",
            specs_json={
                "cpu": "Intel Core i5-1335U CPU @ 1.30GHz",
                "ram": "16GB DDR4",
                "storage": "512GB M.2 NVME SSD",
            },
        )

        response = self.client.get(reverse("asset-detail", args=[asset.pk]))
        html = response.content.decode()

        self.assertContains(response, "CPU")
        self.assertContains(response, "16GB DDR4")
        self.assertContains(response, 'class="spec-grid"')
        self.assertNotIn("<pre>", html)
        self.assertNotIn("{&#x27;cpu&#x27;:", html)

    def test_asset_create_view_saves_specs_from_structured_inputs(self):
        response = self.client.post(
            reverse("asset-create"),
            self.asset_form_payload(
                tracking_code="TRK-CREATE-SPECS",
                asset_tag="TAG-CREATE-SPECS",
                serial_no="SER-CREATE-SPECS",
                cpu="Intel Core i7",
                ram="16GB DDR4",
                storage="512GB SSD",
                connectivity="Wi-Fi 6",
            ),
        )

        self.assertEqual(response.status_code, 302)
        asset = Asset.objects.get(tracking_code="TRK-CREATE-SPECS")
        self.assertEqual(
            asset.specs_json,
            {
                "cpu": "Intel Core i7",
                "ram": "16GB DDR4",
                "storage": "512GB SSD",
                "connectivity": "Wi-Fi 6",
            },
        )

    def test_asset_edit_form_prefills_structured_specs_and_preserves_unknown_keys(self):
        asset = self.create_asset(
            tracking_code="TRK-EDIT-SPECS",
            asset_tag="TAG-EDIT-SPECS",
            serial_no="SER-EDIT-SPECS",
            specs_json={"cpu": "Intel Core i5", "gpu": "RTX 4060"},
        )

        response = self.client.get(reverse("asset-edit", args=[asset.pk]))

        self.assertContains(response, 'name="cpu"')
        self.assertContains(response, 'value="Intel Core i5"')
        self.assertNotContains(response, 'name="specs_json"')

        response = self.client.post(
            reverse("asset-edit", args=[asset.pk]),
            self.asset_form_payload(
                tracking_code=asset.tracking_code,
                asset_tag=asset.asset_tag,
                serial_no=asset.serial_no,
                cpu="Intel Core i5",
                ram="32GB DDR4",
            ),
        )

        self.assertRedirects(response, reverse("asset-detail", args=[asset.pk]))
        asset.refresh_from_db()
        self.assertEqual(asset.specs_json["cpu"], "Intel Core i5")
        self.assertEqual(asset.specs_json["ram"], "32GB DDR4")
        self.assertEqual(asset.specs_json["gpu"], "RTX 4060")

    def test_asset_list_renders_status_filter_without_template_errors(self):
        asset = self.create_asset(
            tracking_code="TRK-LIST",
            asset_tag="TAG-LIST",
            serial_no="SER-LIST",
            status=AssetStatus.ASSIGNED,
        )

        response = self.client.get(reverse("asset-list"), {"status": AssetStatus.ASSIGNED})
        html = response.content.decode()

        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'option value="Assigned" selected')
        self.assertContains(response, "<th>Number</th>", html=True)
        self.assertContains(response, asset.legacy_no)
        self.assertContains(response, "TRK-LIST")
        self.assertContains(response, "Available")
        self.assertContains(response, "Assigned")
        self.assertLess(html.index("<th>Number</th>"), html.index("<th>Tracking Code</th>"))

    def test_asset_list_orders_rows_by_asset_number(self):
        first_asset = self.create_asset(
            tracking_code="TRK-300",
            asset_tag="TAG-300",
            serial_no="SER-300",
        )
        second_asset = self.create_asset(
            tracking_code="TRK-100",
            asset_tag="TAG-100",
            serial_no="SER-100",
        )
        third_asset = self.create_asset(
            tracking_code="TRK-200",
            asset_tag="TAG-200",
            serial_no="SER-200",
        )

        response = self.client.get(reverse("asset-list"))
        html = response.content.decode()

        self.assertEqual(first_asset.legacy_no, "1")
        self.assertEqual(second_asset.legacy_no, "2")
        self.assertEqual(third_asset.legacy_no, "3")
        self.assertLess(html.index("TRK-300"), html.index("TRK-100"))
        self.assertLess(html.index("TRK-100"), html.index("TRK-200"))

    def test_asset_list_is_paginated(self):
        for index in range(ASSET_LIST_PAGE_SIZE + 1):
            asset_number = index + 1
            self.create_asset(
                tracking_code=f"TRK-PAGE-{asset_number}",
                asset_tag=f"TAG-PAGE-{asset_number}",
                serial_no=f"SER-PAGE-{asset_number}",
            )

        response = self.client.get(reverse("asset-list"))

        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.context["page_obj"].number, 1)
        self.assertEqual(response.context["page_obj"].paginator.num_pages, 2)
        self.assertContains(response, "Page 1 of 2")
        self.assertContains(response, "TRK-PAGE-1")
        self.assertContains(response, "TRK-PAGE-25")
        self.assertNotContains(response, "TRK-PAGE-26")
        self.assertContains(response, "?page=2")

        response = self.client.get(reverse("asset-list"), {"page": 2})

        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.context["page_obj"].number, 2)
        self.assertContains(response, "Page 2 of 2")
        self.assertContains(response, "TRK-PAGE-26")
        self.assertNotContains(response, "TRK-PAGE-1")

    def test_asset_detail_shows_number_before_tracking_code(self):
        asset = self.create_asset(
            tracking_code="TRK-DETAIL-NUM",
            asset_tag="TAG-DETAIL-NUM",
            serial_no="SER-DETAIL-NUM",
        )

        response = self.client.get(reverse("asset-detail", args=[asset.pk]))
        html = response.content.decode()

        self.assertContains(response, "Number:")
        self.assertContains(response, asset.legacy_no)
        self.assertContains(response, "Tracking Code:")
        self.assertContains(response, "TRK-DETAIL-NUM")
        self.assertLess(html.index("Number:</strong>"), html.index("Tracking Code:</strong>"))

    def test_asset_number_is_auto_assigned_and_cannot_be_changed(self):
        first_asset = self.create_asset(
            tracking_code="TRK-NUM-1",
            asset_tag="TAG-NUM-1",
            serial_no="SER-NUM-1",
        )
        second_asset = self.create_asset(
            tracking_code="TRK-NUM-2",
            asset_tag="TAG-NUM-2",
            serial_no="SER-NUM-2",
        )

        self.assertEqual(int(second_asset.legacy_no), int(first_asset.legacy_no) + 1)

        first_asset.legacy_no = "999"
        with self.assertRaises(ValidationError):
            first_asset.full_clean()
        with self.assertRaises(ValidationError):
            first_asset.save()

    def test_asset_edit_ignores_posted_number_changes(self):
        asset = self.create_asset(
            tracking_code="TRK-NUM-EDIT",
            asset_tag="TAG-NUM-EDIT",
            serial_no="SER-NUM-EDIT",
        )
        original_number = asset.legacy_no

        response = self.client.post(
            reverse("asset-edit", args=[asset.pk]),
            self.asset_form_payload(
                legacy_no="999",
                tracking_code=asset.tracking_code,
                asset_tag=asset.asset_tag,
                serial_no=asset.serial_no,
            ),
        )

        self.assertRedirects(response, reverse("asset-detail", args=[asset.pk]))
        asset.refresh_from_db()
        self.assertEqual(asset.legacy_no, original_number)

    def test_attachment_upload_randomizes_filename(self):
        asset = self.create_asset(tracking_code="TRK-FILE", asset_tag="TAG-FILE", serial_no="SER-FILE")
        with tempfile.TemporaryDirectory() as temp_dir:
            with override_settings(MEDIA_ROOT=temp_dir):
                upload = SimpleUploadedFile("invoice.png", PNG_1X1, content_type="image/png")
                attachment = create_attachment(asset, upload, "Invoice", self.user)
                self.assertNotEqual(attachment.file.name.split("/")[-1], "invoice.png")
                self.assertTrue(attachment.file.name.endswith(".png"))

    def test_physical_audit_updates_asset(self):
        asset = self.create_asset(tracking_code="TRK-AUDIT", asset_tag="TAG-AUDIT", serial_no="SER-AUDIT")
        record_physical_audit(
            asset=asset,
            result="found",
            verified_location=self.location,
            verified_condition=AssetCondition.FAIR,
            audited_at=timezone.now(),
            follow_up_action="Observed cosmetic wear.",
            actor=self.user,
        )
        asset.refresh_from_db()
        self.assertEqual(asset.condition, AssetCondition.FAIR)

    def test_staff_view_supports_blank_employee_ids_update_and_delete(self):
        create_payloads = [
            {
                "action": "save_staff",
                "name": "Alice One",
                "email": "alice.one@example.com",
                "employee_id": "",
                "department": self.department.pk,
                "location": self.location.pk,
                "is_active": "on",
            },
            {
                "action": "save_staff",
                "name": "Bob Two",
                "email": "bob.two@example.com",
                "employee_id": "",
                "department": self.department.pk,
                "location": self.location.pk,
                "is_active": "on",
            },
        ]

        for payload in create_payloads:
            response = self.client.post(reverse("staff"), payload)
            self.assertEqual(response.status_code, 302)

        alice = StaffMember.objects.get(name="Alice One")
        bob = StaffMember.objects.get(name="Bob Two")
        self.assertIsNone(alice.employee_id)
        self.assertIsNone(bob.employee_id)

        response = self.client.post(
            reverse("staff"),
            {
                "action": "save_staff",
                "staff_id": alice.pk,
                "name": "Alice Updated",
                "email": "alice.one@example.com",
                "employee_id": "",
                "department": self.department.pk,
                "location": self.location.pk,
                "is_active": "on",
            },
        )
        self.assertEqual(response.status_code, 302)
        alice.refresh_from_db()
        self.assertEqual(alice.name, "Alice Updated")

        response = self.client.post(reverse("staff"), {"action": "delete_staff", "staff_id": bob.pk})
        self.assertEqual(response.status_code, 302)
        self.assertFalse(StaffMember.objects.filter(pk=bob.pk).exists())

    def test_departments_locations_and_vendors_can_be_managed_through_the_app(self):
        response = self.client.post(
            reverse("departments"),
            {
                "action": "save_department",
                "department-name": "Finance",
                "department-code": "FIN",
            },
        )
        self.assertEqual(response.status_code, 302)
        department = Department.objects.get(name="Finance")

        response = self.client.post(
            reverse("departments"),
            {
                "action": "save_department",
                "department_id": department.pk,
                "department-name": "Finance Ops",
                "department-code": "FIN-OPS",
            },
        )
        self.assertEqual(response.status_code, 302)
        department.refresh_from_db()
        self.assertEqual(department.name, "Finance Ops")

        response = self.client.post(
            reverse("departments"),
            {
                "action": "save_location",
                "location-name": "Warehouse",
                "location-description": "Secondary store room",
            },
        )
        self.assertEqual(response.status_code, 302)
        location = Location.objects.get(name="Warehouse")

        response = self.client.post(
            reverse("departments"),
            {"action": "delete_location", "location_id": location.pk},
        )
        self.assertEqual(response.status_code, 302)
        self.assertFalse(Location.objects.filter(pk=location.pk).exists())

        response = self.client.post(
            reverse("vendors"),
            {
                "action": "save_vendor",
                "name": "Acme Supplies",
                "email": "sales@acme.example.com",
                "phone": "12345",
                "notes": "Preferred vendor",
            },
        )
        self.assertEqual(response.status_code, 302)
        vendor = Vendor.objects.get(name="Acme Supplies")

        response = self.client.post(
            reverse("vendors"),
            {
                "action": "save_vendor",
                "vendor_id": vendor.pk,
                "name": "Acme Supplies Updated",
                "email": "sales@acme.example.com",
                "phone": "99999",
                "notes": "Updated vendor",
            },
        )
        self.assertEqual(response.status_code, 302)
        vendor.refresh_from_db()
        self.assertEqual(vendor.name, "Acme Supplies Updated")

        response = self.client.post(reverse("vendors"), {"action": "delete_vendor", "vendor_id": vendor.pk})
        self.assertEqual(response.status_code, 302)
        self.assertFalse(Vendor.objects.filter(pk=vendor.pk).exists())

    def test_attachment_upload_download_and_delete_flow(self):
        asset = self.create_asset(tracking_code="TRK-DOC", asset_tag="TAG-DOC", serial_no="SER-DOC")
        temp_dir = tempfile.mkdtemp()
        try:
            with override_settings(MEDIA_ROOT=temp_dir):
                delete_upload = SimpleUploadedFile("delete-me.png", PNG_1X1, content_type="image/png")
                response = self.client.post(
                    reverse("asset-detail", args=[asset.pk]),
                    {"file": delete_upload, "description": "Delete me"},
                )
                self.assertEqual(response.status_code, 302)

                attachment = asset.attachments.get()
                delete = self.client.post(reverse("attachment-delete", args=[attachment.pk]))
                self.assertEqual(delete.status_code, 302)
                self.assertFalse(asset.attachments.exists())

                download_upload = SimpleUploadedFile("invoice.png", PNG_1X1, content_type="image/png")
                response = self.client.post(
                    reverse("asset-detail", args=[asset.pk]),
                    {"file": download_upload, "description": "Invoice copy"},
                )
                self.assertEqual(response.status_code, 302)

                attachment = asset.attachments.get()
                download = self.client.get(reverse("attachment-download", args=[attachment.pk]))
                self.assertEqual(download.status_code, 200)
                self.assertIn("invoice.png", download.headers["Content-Disposition"])
        finally:
            shutil.rmtree(temp_dir, ignore_errors=True)
        event_types = list(AuditEvent.objects.values_list("event_type", flat=True))
        self.assertIn("attachment_uploaded", event_types)
        self.assertIn("attachment_downloaded", event_types)
        self.assertIn("attachment_deleted", event_types)

    def test_admin_can_delete_unused_asset_and_its_attachments(self):
        asset = self.create_asset(tracking_code="TRK-DELETE", asset_tag="TAG-DELETE", serial_no="SER-DELETE")
        asset_pk = asset.pk
        temp_dir = tempfile.mkdtemp()
        try:
            with override_settings(MEDIA_ROOT=temp_dir):
                upload = SimpleUploadedFile("delete-asset.png", PNG_1X1, content_type="image/png")
                create_attachment(asset, upload, "Delete with asset", self.user)

                response = self.client.post(reverse("asset-delete", args=[asset.pk]))

                self.assertEqual(response.status_code, 302)
                self.assertFalse(Asset.objects.filter(pk=asset_pk).exists())
                self.assertFalse(Attachment.objects.filter(asset_id=asset_pk).exists())
                self.assertTrue(AuditEvent.objects.filter(event_type="asset_deleted", actor=self.user).exists())
        finally:
            shutil.rmtree(temp_dir, ignore_errors=True)

    def test_asset_delete_is_blocked_when_assignment_history_exists(self):
        asset = self.create_asset(tracking_code="TRK-KEEP", asset_tag="TAG-KEEP", serial_no="SER-KEEP")
        assignment = create_assignment(asset, self.staff_member, date.today(), "", self.user)
        assignment.returned_at = date.today()
        assignment.save(update_fields=["returned_at"])

        response = self.client.post(reverse("asset-delete", args=[asset.pk]), follow=True)

        self.assertEqual(response.status_code, 200)
        self.assertTrue(Asset.objects.filter(pk=asset.pk).exists())
        self.assertContains(response, "This asset cannot be deleted while assignment, repair, sale/disposal, or audit history still references it.")

    def test_sale_disposal_workflow_defaults_final_price_and_renders_price_history(self):
        asset = self.create_asset(
            tracking_code="TRK-SALE",
            asset_tag="TAG-SALE",
            serial_no="SER-SALE",
            purchase_date=date.today() - timedelta(days=400),
            estimate_lifespan_years=Decimal("2.00"),
        )

        response = self.client.post(
            reverse("asset-sell", args=[asset.pk]),
            {
                "action": "sold",
                "recorded_at": date.today().isoformat(),
                "final_price": "",
                "notes": "Sold to staff member",
            },
        )
        self.assertEqual(response.status_code, 302)

        asset.refresh_from_db()
        sale_record = asset.sale_disposal
        self.assertEqual(asset.status, AssetStatus.SOLD)
        self.assertEqual(sale_record.final_price, sale_record.suggested_price)

        audit_event = AuditEvent.objects.filter(event_type="sale_disposal_recorded").order_by("-created_at").first()
        self.assertEqual(audit_event.metadata["suggested_price"], str(sale_record.suggested_price))
        self.assertEqual(audit_event.metadata["final_price"], str(sale_record.final_price))

        response = self.client.get(reverse("asset-detail", args=[asset.pk]))
        self.assertContains(response, "Sale / Disposal")
        self.assertContains(response, str(sale_record.suggested_price))
        self.assertContains(response, str(sale_record.final_price))

    def test_physical_audit_missing_requires_follow_up_action(self):
        asset = self.create_asset(tracking_code="TRK-MISS", asset_tag="TAG-MISS", serial_no="SER-MISS")
        response = self.client.post(
            reverse("audits"),
            {
                "asset": asset.pk,
                "result": "missing",
                "verified_location": self.location.pk,
                "verified_condition": AssetCondition.FAIR,
                "audited_at": timezone.now().strftime("%Y-%m-%dT%H:%M"),
                "follow_up_action": "",
            },
        )

        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Follow-up action is required when an asset is marked missing.")

    def test_physical_audit_found_updates_asset_and_history_display(self):
        asset = self.create_asset(tracking_code="TRK-HIST", asset_tag="TAG-HIST", serial_no="SER-HIST")
        response = self.client.post(
            reverse("audits"),
            {
                "asset": asset.pk,
                "result": "found",
                "verified_location": self.location.pk,
                "verified_condition": AssetCondition.FAIR,
                "audited_at": timezone.now().strftime("%Y-%m-%dT%H:%M"),
                "follow_up_action": "Confirmed label and desk location.",
            },
        )
        self.assertEqual(response.status_code, 302)

        asset.refresh_from_db()
        self.assertEqual(asset.condition, AssetCondition.FAIR)

        response = self.client.get(reverse("asset-detail", args=[asset.pk]))
        self.assertContains(response, "Confirmed label and desk location.")
        self.assertContains(response, "Fair")
