from decimal import Decimal

from django.core.validators import MinValueValidator
from django.db import migrations, models
from django.db.models import Q


def convert_lifespan_months_to_years(apps, schema_editor):
    Asset = apps.get_model("inventory", "Asset")
    for asset in Asset.objects.all().only("pk", "estimate_lifespan_years"):
        months = Decimal(str(asset.estimate_lifespan_years or 0))
        asset.estimate_lifespan_years = (months / Decimal("12")).quantize(Decimal("0.01"))
        asset.save(update_fields=["estimate_lifespan_years"])


class Migration(migrations.Migration):
    dependencies = [
        ("inventory", "0001_initial"),
    ]

    operations = [
        migrations.RemoveConstraint(
            model_name="asset",
            name="asset_lifespan_positive",
        ),
        migrations.RenameField(
            model_name="asset",
            old_name="estimate_lifespan_months",
            new_name="estimate_lifespan_years",
        ),
        migrations.AlterField(
            model_name="asset",
            name="estimate_lifespan_years",
            field=models.DecimalField(
                decimal_places=2,
                max_digits=5,
                validators=[MinValueValidator(Decimal("0.01"))],
                verbose_name="Estimate lifespan (years)",
            ),
        ),
        migrations.RunPython(
            convert_lifespan_months_to_years,
            migrations.RunPython.noop,
        ),
        migrations.AddConstraint(
            model_name="asset",
            constraint=models.CheckConstraint(
                condition=Q(estimate_lifespan_years__gt=0),
                name="asset_lifespan_years_positive",
            ),
        ),
    ]
