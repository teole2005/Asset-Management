from django.db import migrations


ALLOWED_ASSET_TYPE_NAMES = ("Laptop", "Monitor", "Desktop", "Printer")


def canonicalize_asset_type_name(value):
    normalized = (value or "").strip()
    if not normalized:
        return ""

    lowered = normalized.casefold()
    for allowed_name in ALLOWED_ASSET_TYPE_NAMES:
        if lowered == allowed_name.casefold():
            return allowed_name

    for allowed_name in ALLOWED_ASSET_TYPE_NAMES:
        if allowed_name.casefold() in lowered:
            return allowed_name

    return ""


def normalize_asset_types(apps, schema_editor):
    Asset = apps.get_model("inventory", "Asset")
    AssetType = apps.get_model("inventory", "AssetType")

    allowed_types = {}
    for name in ALLOWED_ASSET_TYPE_NAMES:
        allowed_types[name], _ = AssetType.objects.get_or_create(name=name)

    for asset_type in AssetType.objects.exclude(name__in=ALLOWED_ASSET_TYPE_NAMES).order_by("pk"):
        canonical_name = canonicalize_asset_type_name(asset_type.name)
        if canonical_name:
            Asset.objects.filter(type_id=asset_type.pk).update(type_id=allowed_types[canonical_name].pk)
            asset_type.delete()
            continue

        if not Asset.objects.filter(type_id=asset_type.pk).exists():
            asset_type.delete()


class Migration(migrations.Migration):

    dependencies = [
        ("inventory", "0002_estimate_lifespan_years"),
    ]

    operations = [
        migrations.RunPython(normalize_asset_types, migrations.RunPython.noop),
    ]
