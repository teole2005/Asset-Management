from django.db import migrations, models
from django.db.models import Q


ASSET_NUMBER_SEQUENCE_KEY = "asset_number_sequence"


def backfill_asset_numbers(apps, schema_editor):
    Asset = apps.get_model("inventory", "Asset")
    SystemSetting = apps.get_model("inventory", "SystemSetting")

    assets = list(Asset.objects.order_by("pk").only("pk"))
    for index, asset in enumerate(assets, start=1):
        Asset.objects.filter(pk=asset.pk).update(legacy_no=str(index))

    SystemSetting.objects.update_or_create(
        key=ASSET_NUMBER_SEQUENCE_KEY,
        defaults={"value": len(assets)},
    )


class Migration(migrations.Migration):

    dependencies = [
        ("inventory", "0003_normalize_asset_types"),
    ]

    operations = [
        migrations.RunPython(backfill_asset_numbers, migrations.RunPython.noop),
        migrations.AddConstraint(
            model_name="asset",
            constraint=models.UniqueConstraint(
                fields=("legacy_no",),
                condition=~Q(legacy_no=""),
                name="uniq_asset_number_nonblank",
            ),
        ),
    ]
