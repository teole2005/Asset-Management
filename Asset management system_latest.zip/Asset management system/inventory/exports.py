from datetime import datetime

from django.core.exceptions import PermissionDenied
from django.db.models import Q
from django.http import HttpResponse
from django.utils import timezone
from openpyxl import Workbook

from .models import Asset, Assignment, AuditEvent, PhysicalAudit, RepairLog, SaleDisposal
from .permissions import has_super_admin_access
from .services import filter_assets
from .utils import csv_bytes


DATASET_LABELS = {
    "assets": "Assets",
    "assignments": "Assignments",
    "repairs": "Repairs",
    "sales": "Sales and Disposals",
    "audits": "Physical Audits",
    "activity": "Audit Activity",
}


def _filtered_assignments(params):
    queryset = Assignment.objects.select_related("asset", "staff_member")
    search = params.get("q", "").strip()
    active = params.get("active", "").strip()

    if search:
        queryset = queryset.filter(
            Q(asset__tracking_code__icontains=search)
            | Q(asset__asset_tag__icontains=search)
            | Q(staff_member__name__icontains=search)
            | Q(notes__icontains=search)
        )
    if active in {"0", "1"}:
        queryset = queryset.filter(returned_at__isnull=active == "1")
    return queryset


def _filtered_repairs(params):
    queryset = RepairLog.objects.select_related("asset", "vendor")
    search = params.get("q", "").strip()
    open_only = params.get("open_only", "").strip()

    if search:
        queryset = queryset.filter(
            Q(asset__tracking_code__icontains=search)
            | Q(asset__asset_tag__icontains=search)
            | Q(issue__icontains=search)
            | Q(resolution_notes__icontains=search)
            | Q(vendor__name__icontains=search)
        )
    if open_only in {"0", "1"}:
        queryset = queryset.filter(closed_at__isnull=open_only == "1")
    return queryset


def _filtered_sales(params):
    queryset = SaleDisposal.objects.select_related("asset")
    search = params.get("q", "").strip()
    action = params.get("action", "").strip()

    if search:
        queryset = queryset.filter(
            Q(asset__tracking_code__icontains=search)
            | Q(asset__asset_tag__icontains=search)
            | Q(notes__icontains=search)
        )
    if action:
        queryset = queryset.filter(action=action)
    return queryset


def _filtered_audits(params):
    queryset = PhysicalAudit.objects.select_related("asset", "audited_by", "verified_location")
    search = params.get("q", "").strip()
    result = params.get("result", "").strip()

    if search:
        queryset = queryset.filter(
            Q(asset__tracking_code__icontains=search)
            | Q(asset__asset_tag__icontains=search)
            | Q(follow_up_action__icontains=search)
            | Q(audited_by__username__icontains=search)
        )
    if result:
        queryset = queryset.filter(result=result)
    return queryset


def _filtered_activity(params):
    queryset = AuditEvent.objects.select_related("actor")
    event_type = params.get("event_type", "").strip()
    success = params.get("success", "").strip()
    search = params.get("q", "").strip()

    if event_type:
        queryset = queryset.filter(event_type=event_type)
    if success in {"0", "1"}:
        queryset = queryset.filter(success=success == "1")
    if search:
        queryset = queryset.filter(
            Q(event_type__icontains=search)
            | Q(description__icontains=search)
            | Q(ip_address__icontains=search)
            | Q(actor__username__icontains=search)
        )
    return queryset


def dataset_rows(dataset, params, user):
    if dataset == "assets":
        queryset = filter_assets(
            Asset.objects.select_related("type", "department", "current_location"),
            params,
        )
        headers = [
            "Number",
            "Tracking Code",
            "Asset Tag",
            "Type",
            "Status",
            "Brand",
            "Model",
            "Serial No.",
            "Current Assignee",
            "Department",
            "Replacement Due Soon",
            "Warranty Due Soon",
            "Audit Due Soon",
        ]
        rows = [
            {
                "Number": asset.legacy_no,
                "Tracking Code": asset.tracking_code,
                "Asset Tag": asset.asset_tag,
                "Type": asset.type.name,
                "Status": asset.status,
                "Brand": asset.brand,
                "Model": asset.model,
                "Serial No.": asset.serial_no,
                "Current Assignee": getattr(asset.current_assignee, "name", ""),
                "Department": getattr(asset.department, "name", ""),
                "Replacement Due Soon": "Yes" if asset.replacement_due_soon else "No",
                "Warranty Due Soon": "Yes" if asset.warranty_due_soon else "No",
                "Audit Due Soon": "Yes" if asset.audit_due_soon else "No",
            }
            for asset in queryset
        ]
        return headers, rows

    if dataset == "assignments":
        headers = ["Asset", "Staff Member", "Assigned At", "Returned At", "Notes"]
        rows = [
            {
                "Asset": assignment.asset.tracking_code,
                "Staff Member": assignment.staff_member.name,
                "Assigned At": assignment.assigned_at,
                "Returned At": assignment.returned_at,
                "Notes": assignment.notes,
            }
            for assignment in _filtered_assignments(params)
        ]
        return headers, rows

    if dataset == "repairs":
        headers = ["Asset", "Issue", "Opened At", "Closed At", "Cost", "Vendor"]
        rows = [
            {
                "Asset": repair.asset.tracking_code,
                "Issue": repair.issue,
                "Opened At": repair.opened_at,
                "Closed At": repair.closed_at,
                "Cost": repair.cost,
                "Vendor": repair.vendor.name if repair.vendor else "",
            }
            for repair in _filtered_repairs(params)
        ]
        return headers, rows

    if dataset == "sales":
        headers = ["Asset", "Action", "Recorded At", "Suggested Price", "Final Price", "Notes"]
        rows = [
            {
                "Asset": record.asset.tracking_code,
                "Action": record.get_action_display(),
                "Recorded At": record.recorded_at,
                "Suggested Price": record.suggested_price,
                "Final Price": record.final_price,
                "Notes": record.notes,
            }
            for record in _filtered_sales(params)
        ]
        return headers, rows

    if dataset == "audits":
        headers = [
            "Asset",
            "Result",
            "Audited At",
            "Audited By",
            "Verified Location",
            "Verified Condition",
            "Follow Up",
        ]
        rows = [
            {
                "Asset": audit.asset.tracking_code,
                "Result": audit.get_result_display(),
                "Audited At": audit.audited_at,
                "Audited By": audit.audited_by.get_username(),
                "Verified Location": audit.verified_location.name if audit.verified_location else "",
                "Verified Condition": audit.verified_condition,
                "Follow Up": audit.follow_up_action,
            }
            for audit in _filtered_audits(params)
        ]
        return headers, rows

    if dataset == "activity":
        if not has_super_admin_access(user):
            raise PermissionDenied("Only super-admins can export security and auth logs.")
        headers = ["Timestamp", "Event", "Actor", "Success", "Description", "IP Address"]
        rows = [
            {
                "Timestamp": event.created_at,
                "Event": event.event_type,
                "Actor": event.actor.get_username() if event.actor else "",
                "Success": "Yes" if event.success else "No",
                "Description": event.description,
                "IP Address": event.ip_address,
            }
            for event in _filtered_activity(params)
        ]
        return headers, rows

    raise ValueError("Unknown dataset.")


def _xlsx_cell_value(value):
    if isinstance(value, datetime) and timezone.is_aware(value):
        return timezone.localtime(value).replace(tzinfo=None)
    return value


def build_export_response(dataset, fmt, params, user):
    if fmt not in {"csv", "xlsx"}:
        raise ValueError("Unknown export format.")
    headers, rows = dataset_rows(dataset, params, user)
    filename = f"{dataset}.{fmt}"
    if fmt == "csv":
        response = HttpResponse(csv_bytes(rows, headers), content_type="text/csv")
        response["Content-Disposition"] = f'attachment; filename="{filename}"'
        return response

    workbook = Workbook()
    worksheet = workbook.active
    worksheet.title = dataset.title()
    worksheet.append(headers)
    for row in rows:
        worksheet.append([_xlsx_cell_value(row.get(header, "")) for header in headers])
    response = HttpResponse(
        content_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    )
    response["Content-Disposition"] = f'attachment; filename="{filename}"'
    workbook.save(response)
    return response
