from pathlib import Path

from django import forms
from django.core.validators import validate_email
from django.contrib.auth import password_validation
from django.contrib.auth.forms import AuthenticationForm
from django.utils import timezone

from .asset_types import asset_types_queryset, ensure_default_asset_types
from .permissions import ADMIN_ROLE, SUPER_ADMIN_ROLE
from .utils import SPEC_LABELS, clean_text
from .models import (
    Asset,
    AssetStatus,
    Assignment,
    Department,
    ImportBatch,
    Location,
    PhysicalAudit,
    PhysicalAuditResult,
    RepairLog,
    SaleDisposal,
    StaffMember,
    Vendor,
)


ASSET_SPEC_WIDGETS = {
    "cpu": forms.TextInput(attrs={"placeholder": "Intel Core i5-1335U"}),
    "ram": forms.TextInput(attrs={"placeholder": "16GB DDR4"}),
    "storage": forms.TextInput(attrs={"placeholder": "512GB SSD"}),
    "printer_type": forms.TextInput(attrs={"placeholder": "Laser / Inkjet"}),
    "printer_color": forms.TextInput(attrs={"placeholder": "Mono / Color"}),
    "connectivity": forms.TextInput(attrs={"placeholder": "Wi-Fi, Ethernet"}),
    "function": forms.TextInput(attrs={"placeholder": "Print / Scan / Copy"}),
    "monitor_size": forms.TextInput(attrs={"placeholder": "24 inch"}),
    "input_type": forms.TextInput(attrs={"placeholder": "USB / Wireless"}),
}


class BaseFormMixin:
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for field in self.fields.values():
            css = field.widget.attrs.get("class", "")
            if isinstance(field.widget, forms.CheckboxInput):
                field.widget.attrs["class"] = f"{css} form-check-input".strip()
                continue
            field.widget.attrs["class"] = f"{css} form-control".strip()


class LoginForm(BaseFormMixin, AuthenticationForm):
    username = forms.CharField(widget=forms.TextInput(attrs={"autofocus": True}))


class AssetForm(BaseFormMixin, forms.ModelForm):
    cpu = forms.CharField(required=False, label="CPU", widget=ASSET_SPEC_WIDGETS["cpu"])
    ram = forms.CharField(required=False, label="RAM", widget=ASSET_SPEC_WIDGETS["ram"])
    storage = forms.CharField(required=False, label="Storage", widget=ASSET_SPEC_WIDGETS["storage"])
    printer_type = forms.CharField(
        required=False,
        label="Printer Type",
        widget=ASSET_SPEC_WIDGETS["printer_type"],
    )
    printer_color = forms.CharField(
        required=False,
        label="Printer Color",
        widget=ASSET_SPEC_WIDGETS["printer_color"],
    )
    connectivity = forms.CharField(
        required=False,
        label="Connectivity",
        widget=ASSET_SPEC_WIDGETS["connectivity"],
    )
    function = forms.CharField(required=False, label="Function", widget=ASSET_SPEC_WIDGETS["function"])
    monitor_size = forms.CharField(
        required=False,
        label="Monitor Size",
        widget=ASSET_SPEC_WIDGETS["monitor_size"],
    )
    input_type = forms.CharField(required=False, label="Input Type", widget=ASSET_SPEC_WIDGETS["input_type"])

    class Meta:
        model = Asset
        fields = [
            "tracking_code",
            "type",
            "owner",
            "asset_tag",
            "brand",
            "model",
            "serial_no",
            "price",
            "purchase_date",
            "estimate_lifespan_years",
            "start_date",
            "warranty_expiry_date",
            "vendor",
            "invoice_no",
            "condition",
            "status",
            "current_location",
            "department",
            "custodian_it_owner",
        ]
        widgets = {
            "purchase_date": forms.DateInput(attrs={"type": "date"}),
            "estimate_lifespan_years": forms.NumberInput(attrs={"step": "0.01", "min": "0.01"}),
            "start_date": forms.DateInput(attrs={"type": "date"}),
            "warranty_expiry_date": forms.DateInput(attrs={"type": "date"}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        ensure_default_asset_types()
        self.fields["type"].queryset = asset_types_queryset()
        self.fields["estimate_lifespan_years"].help_text = "Enter the expected lifespan in years."
        self.fields["status"].choices = [
            (AssetStatus.AVAILABLE, AssetStatus.AVAILABLE),
            (AssetStatus.RETIRED, AssetStatus.RETIRED),
        ]
        existing_specs = self.instance.specs_json if getattr(self.instance, "specs_json", None) else {}
        if not isinstance(existing_specs, dict):
            existing_specs = {}
        self._extra_specs = {
            key: value
            for key, value in existing_specs.items()
            if key not in SPEC_LABELS and clean_text(value)
        }
        for field_name in SPEC_LABELS:
            self.fields[field_name].initial = existing_specs.get(field_name, "")
        self.general_bound_fields = [self[name] for name in self.Meta.fields]
        self.spec_bound_fields = [self[name] for name in SPEC_LABELS]
        if self.instance and self.instance.pk and self.instance.status in {AssetStatus.SOLD, AssetStatus.DISPOSED}:
            self.fields["status"].disabled = True

    def save(self, commit=True):
        asset = super().save(commit=False)
        specs_json = dict(self._extra_specs)
        for field_name in SPEC_LABELS:
            value = clean_text(self.cleaned_data.get(field_name))
            if value:
                specs_json[field_name] = value
        asset.specs_json = specs_json
        if commit:
            asset.save()
            self.save_m2m()
        return asset


class AssignmentForm(BaseFormMixin, forms.ModelForm):
    def __init__(self, *args, **kwargs):
        asset = kwargs.pop("asset", None)
        instance = kwargs.get("instance")
        if asset is not None:
            if instance is None:
                kwargs["instance"] = Assignment(asset=asset)
            else:
                instance.asset = asset
        super().__init__(*args, **kwargs)
        self.fields["staff_member"].queryset = StaffMember.objects.filter(is_active=True)

    class Meta:
        model = Assignment
        fields = ["staff_member", "assigned_at", "notes"]
        widgets = {
            "assigned_at": forms.DateInput(attrs={"type": "date"}),
            "notes": forms.Textarea(attrs={"rows": 3}),
        }


class ReturnAssignmentForm(BaseFormMixin, forms.Form):
    returned_at = forms.DateField(
        initial=timezone.localdate,
        widget=forms.DateInput(attrs={"type": "date"}),
    )


class RepairLogForm(BaseFormMixin, forms.ModelForm):
    class Meta:
        model = RepairLog
        fields = ["issue", "vendor", "opened_at", "cost", "resolution_notes"]
        widgets = {
            "opened_at": forms.DateInput(attrs={"type": "date"}),
            "issue": forms.Textarea(attrs={"rows": 3}),
            "resolution_notes": forms.Textarea(attrs={"rows": 3}),
        }


class RepairCloseForm(BaseFormMixin, forms.Form):
    closed_at = forms.DateField(
        initial=timezone.localdate,
        widget=forms.DateInput(attrs={"type": "date"}),
    )
    resolution_notes = forms.CharField(widget=forms.Textarea(attrs={"rows": 3}), required=False)


class SaleDisposalForm(BaseFormMixin, forms.ModelForm):
    def clean(self):
        cleaned_data = super().clean()
        if cleaned_data.get("final_price") in (None, "") and self.suggested_price is not None:
            cleaned_data["final_price"] = self.suggested_price
            self.instance.final_price = self.suggested_price
        return cleaned_data

    class Meta:
        model = SaleDisposal
        fields = ["action", "recorded_at", "final_price", "notes"]
        widgets = {
            "recorded_at": forms.DateInput(attrs={"type": "date"}),
            "notes": forms.Textarea(attrs={"rows": 3}),
        }

    def __init__(self, *args, **kwargs):
        suggested_price = kwargs.pop("suggested_price", None)
        super().__init__(*args, **kwargs)
        self.suggested_price = suggested_price
        self.fields["final_price"].required = False
        if suggested_price is not None:
            self.fields["final_price"].help_text = f"Suggested straight-line price: RM {suggested_price}"
            self.fields["final_price"].initial = suggested_price


class AttachmentForm(BaseFormMixin, forms.Form):
    file = forms.FileField()
    description = forms.CharField(required=False, max_length=255)


class PhysicalAuditForm(BaseFormMixin, forms.ModelForm):
    def clean(self):
        cleaned_data = super().clean()
        result = cleaned_data.get("result")
        follow_up_action = (cleaned_data.get("follow_up_action") or "").strip()
        if result == PhysicalAuditResult.MISSING and not follow_up_action:
            self.add_error("follow_up_action", "Follow-up action is required when an asset is marked missing.")
        return cleaned_data

    class Meta:
        model = PhysicalAudit
        fields = [
            "asset",
            "result",
            "verified_location",
            "verified_condition",
            "audited_at",
            "follow_up_action",
        ]
        widgets = {
            "audited_at": forms.DateTimeInput(attrs={"type": "datetime-local"}),
            "follow_up_action": forms.Textarea(attrs={"rows": 3}),
        }


class StaffMemberForm(BaseFormMixin, forms.ModelForm):
    class Meta:
        model = StaffMember
        fields = ["name", "email", "department", "location", "is_active"]

    def save(self, commit=True):
        self.instance.employee_id = None
        return super().save(commit=commit)


class DepartmentForm(BaseFormMixin, forms.ModelForm):
    class Meta:
        model = Department
        fields = ["name", "code"]


class LocationForm(BaseFormMixin, forms.ModelForm):
    class Meta:
        model = Location
        fields = ["name", "description"]


class VendorForm(BaseFormMixin, forms.ModelForm):
    class Meta:
        model = Vendor
        fields = ["name", "email", "phone", "notes"]
        widgets = {"notes": forms.Textarea(attrs={"rows": 3})}


class ImportUploadForm(BaseFormMixin, forms.ModelForm):
    class Meta:
        model = ImportBatch
        fields = ["source_file"]

    def clean_source_file(self):
        source_file = self.cleaned_data["source_file"]
        if Path(source_file.name).suffix.lower() not in {".csv", ".xlsx"}:
            raise forms.ValidationError("Only CSV and XLSX files are supported.")
        return source_file


class SettingsForm(BaseFormMixin, forms.Form):
    maintenance_mode = forms.BooleanField(required=False)
    alert_recipients = forms.CharField(
        required=False,
        help_text="Comma-separated email recipients for daily reminders.",
        widget=forms.Textarea(attrs={"rows": 3}),
    )

    def clean_alert_recipients(self):
        raw_value = self.cleaned_data.get("alert_recipients", "")
        recipients = []
        seen = set()
        invalid = []

        for token in raw_value.replace(";", ",").replace("\n", ",").split(","):
            email = token.strip()
            if not email or email in seen:
                continue
            try:
                validate_email(email)
            except forms.ValidationError:
                invalid.append(email)
                continue
            recipients.append(email)
            seen.add(email)

        if invalid:
            raise forms.ValidationError(
                f"Enter valid email addresses only. Invalid: {', '.join(invalid)}"
            )
        return ", ".join(recipients)


class AdminUserCreateForm(BaseFormMixin, forms.Form):
    username = forms.CharField(max_length=150)
    email = forms.EmailField(required=False)
    password = forms.CharField(widget=forms.PasswordInput())
    role = forms.ChoiceField(
        choices=[
            (ADMIN_ROLE, "Admin"),
            (SUPER_ADMIN_ROLE, "Super Admin"),
        ]
    )

    def __init__(self, *args, user_model=None, **kwargs):
        self.user_model = user_model
        super().__init__(*args, **kwargs)

    def clean_username(self):
        username = self.cleaned_data["username"].strip()
        if self.user_model and self.user_model.objects.filter(username=username).exists():
            raise forms.ValidationError("A user with that username already exists.")
        return username

    def clean_password(self):
        password = self.cleaned_data["password"]
        if self.user_model is not None:
            temp_user = self.user_model(username=self.cleaned_data.get("username", ""))
            password_validation.validate_password(password, temp_user)
        return password
