import hashlib
import shutil
import sqlite3
import subprocess
import tempfile
from datetime import date, datetime, timedelta
from decimal import Decimal
from pathlib import Path

import filetype
from django.contrib.auth import get_user_model
from django.contrib.auth.models import Group
from django.conf import settings
from django.core.exceptions import ImproperlyConfigured, ValidationError
from django.core.files.base import ContentFile
from django.db import connection, transaction
from django.db.models.deletion import ProtectedError
from django.db.models import Max, Q
from django.utils import timezone

from .models import (
    Asset,
    AssetStatus,
    Assignment,
    Attachment,
    AuditEvent,
    BackupBundle,
    ImportBatch,
    PhysicalAudit,
    PhysicalAuditResult,
    RepairLog,
    SaleDisposal,
    SaleDisposalAction,
    StaffMember,
    SystemSetting,
)
from .permissions import (
    ADMIN_ROLE,
    SUPER_ADMIN_ROLE,
    get_user_admin_role,
    require_admin_access,
    require_super_admin_access,
)
from .utils import days_until, next_due_date


ALLOWED_UPLOAD_MIME_TYPES = {
    "application/pdf",
    "image/jpeg",
    "image/png",
}
User = get_user_model()


def get_request_ip(request):
    if not request:
        return ""
    forwarded = request.META.get("HTTP_X_FORWARDED_FOR")
    if forwarded:
        return forwarded.split(",")[0].strip()
    return request.META.get("REMOTE_ADDR", "")


def _require_admin_actor(actor):
    if actor is not None:
        require_admin_access(actor)


def _require_super_admin_actor(actor):
    if actor is not None:
        require_super_admin_access(actor)


def _super_admin_user_queryset():
    return User.objects.filter(is_active=True).filter(
        Q(is_superuser=True) | Q(groups__name=SUPER_ADMIN_ROLE)
    ).distinct()


def log_event(event_type, actor=None, target=None, request=None, description="", metadata=None, success=True):
    object_type = ""
    object_id = ""
    if target is not None:
        object_type = target.__class__.__name__
        object_id = str(target.pk)
    return AuditEvent.objects.create(
        actor=actor,
        event_type=event_type,
        object_type=object_type,
        object_id=object_id,
        description=description,
        metadata=metadata or {},
        ip_address=get_request_ip(request),
        success=success,
    )


def ensure_runtime_security_state():
    if connection.vendor != "sqlite":
        return

    connection.ensure_connection()
    with connection.cursor() as cursor:
        cursor.execute("PRAGMA foreign_keys = ON;")
        cursor.execute("PRAGMA journal_mode = WAL;")
        cursor.fetchone()
        cursor.execute("PRAGMA foreign_keys;")
        foreign_keys = cursor.fetchone()[0]
        cursor.execute("PRAGMA journal_mode;")
        journal_mode = str(cursor.fetchone()[0]).lower()

    if foreign_keys != 1:
        raise ImproperlyConfigured("PRAGMA foreign_keys=ON is required.")
    if journal_mode != "wal":
        raise ImproperlyConfigured("PRAGMA journal_mode=WAL is required.")


def get_setting(key, default=None):
    try:
        setting = SystemSetting.objects.get(key=key)
    except SystemSetting.DoesNotExist:
        return default
    return setting.value if setting.value != {} else default


def set_setting(key, value, actor=None):
    if actor is not None:
        require_super_admin_access(actor)
    setting, _ = SystemSetting.objects.update_or_create(key=key, defaults={"value": value})
    return setting


def touch_instance(instance, user):
    if not instance.pk and hasattr(instance, "created_by") and not instance.created_by_id:
        instance.created_by = user
    if hasattr(instance, "updated_by"):
        instance.updated_by = user


def sync_asset_status(asset, actor=None):
    if asset.status in {AssetStatus.SOLD, AssetStatus.DISPOSED}:
        return asset.status
    if asset.repairs.filter(closed_at__isnull=True).exists():
        asset.status = AssetStatus.UNDER_REPAIR
    elif asset.assignments.filter(returned_at__isnull=True).exists():
        asset.status = AssetStatus.ASSIGNED
    elif asset.status != AssetStatus.RETIRED:
        asset.status = AssetStatus.AVAILABLE
    if actor:
        asset.updated_by = actor
    asset.save(update_fields=["status", "updated_at", "updated_by"])
    return asset.status


def create_assignment(asset, staff_member, assigned_at, notes, actor, request=None):
    _require_admin_actor(actor)
    if asset.status in {AssetStatus.SOLD, AssetStatus.DISPOSED}:
        raise ValidationError("Sold or disposed assets cannot be assigned.")
    if not staff_member.is_active:
        raise ValidationError("Inactive staff members cannot receive new assignments.")
    if asset.assignments.filter(returned_at__isnull=True).exists():
        raise ValidationError("This asset already has an active assignment.")
    if asset.repairs.filter(closed_at__isnull=True).exists():
        raise ValidationError("Assets under repair cannot be assigned.")

    with transaction.atomic():
        assignment = Assignment(
            asset=asset,
            staff_member=staff_member,
            assigned_at=assigned_at,
            notes=notes,
        )
        touch_instance(assignment, actor)
        assignment.full_clean()
        assignment.save()
        asset.status = AssetStatus.ASSIGNED
        asset.department = staff_member.department or asset.department
        asset.current_location = staff_member.location or asset.current_location
        touch_instance(asset, actor)
        asset.save()
        log_event(
            "assignment_created",
            actor=actor,
            target=assignment,
            request=request,
            description=f"{asset.tracking_code} assigned to {staff_member.name}.",
        )
    return assignment


def return_assignment(assignment, returned_at, actor, request=None):
    _require_admin_actor(actor)
    if assignment.returned_at:
        raise ValidationError("This assignment has already been returned.")
    if returned_at < assignment.assigned_at:
        raise ValidationError("Return date must be on or after the assignment date.")

    with transaction.atomic():
        assignment.returned_at = returned_at
        touch_instance(assignment, actor)
        assignment.full_clean()
        assignment.save(update_fields=["returned_at", "updated_at", "updated_by"])
        sync_asset_status(assignment.asset, actor=actor)
        log_event(
            "assignment_returned",
            actor=actor,
            target=assignment,
            request=request,
            description=f"{assignment.asset.tracking_code} returned from {assignment.staff_member.name}.",
        )
    return assignment


def open_repair(asset, issue, opened_at, cost, vendor, resolution_notes, actor, request=None):
    _require_admin_actor(actor)
    if asset.status in {AssetStatus.SOLD, AssetStatus.DISPOSED}:
        raise ValidationError("Sold or disposed assets cannot be repaired.")
    if asset.repairs.filter(closed_at__isnull=True).exists():
        raise ValidationError("This asset already has an open repair.")

    with transaction.atomic():
        repair = RepairLog(
            asset=asset,
            issue=issue,
            opened_at=opened_at,
            cost=cost,
            vendor=vendor,
            resolution_notes=resolution_notes or "",
        )
        touch_instance(repair, actor)
        repair.full_clean()
        repair.save()
        asset.status = AssetStatus.UNDER_REPAIR
        touch_instance(asset, actor)
        asset.save()
        log_event(
            "repair_opened",
            actor=actor,
            target=repair,
            request=request,
            description=f"Repair opened for {asset.tracking_code}.",
        )
    return repair


def close_repair(repair, closed_at, resolution_notes, actor, request=None):
    _require_admin_actor(actor)
    if repair.closed_at:
        raise ValidationError("This repair is already closed.")
    if closed_at < repair.opened_at:
        raise ValidationError("Close date must be on or after the open date.")

    with transaction.atomic():
        repair.closed_at = closed_at
        repair.resolution_notes = resolution_notes
        touch_instance(repair, actor)
        repair.full_clean()
        repair.save(update_fields=["closed_at", "resolution_notes", "updated_at", "updated_by"])
        sync_asset_status(repair.asset, actor=actor)
        log_event(
            "repair_closed",
            actor=actor,
            target=repair,
            request=request,
            description=f"Repair closed for {repair.asset.tracking_code}.",
        )
    return repair


def suggested_sale_price(asset, recorded_at):
    elapsed_days = Decimal(str(max((recorded_at - asset.purchase_date).days, 0)))
    lifespan_days = max(Decimal(str(asset.lifespan_months)) * Decimal("30"), Decimal("1"))
    remaining_ratio = max(Decimal("0.10"), Decimal("1") - (elapsed_days / lifespan_days))
    price = asset.price * remaining_ratio
    return price.quantize(Decimal("0.01"))


def record_sale_disposal(asset, action, recorded_at, final_price, notes, actor, request=None):
    _require_admin_actor(actor)
    if asset.status in {AssetStatus.SOLD, AssetStatus.DISPOSED}:
        raise ValidationError("This asset has already reached a terminal lifecycle state.")
    if SaleDisposal.objects.filter(asset=asset).exists():
        raise ValidationError("This asset already has a sale/disposal record.")
    if asset.assignments.filter(returned_at__isnull=True).exists():
        raise ValidationError("Return the active assignment before selling or disposing this asset.")
    if asset.repairs.filter(closed_at__isnull=True).exists():
        raise ValidationError("Close the active repair before selling or disposing this asset.")

    suggested = suggested_sale_price(asset, recorded_at)
    final_price = final_price if final_price is not None else suggested
    with transaction.atomic():
        record = SaleDisposal(
            asset=asset,
            action=action,
            recorded_at=recorded_at,
            suggested_price=suggested,
            final_price=final_price,
            notes=notes,
        )
        touch_instance(record, actor)
        record.full_clean()
        record.save()
        asset.status = AssetStatus.SOLD if action == SaleDisposalAction.SOLD else AssetStatus.DISPOSED
        touch_instance(asset, actor)
        asset.save()
        log_event(
            "sale_disposal_recorded",
            actor=actor,
            target=record,
            request=request,
            metadata={
                "suggested_price": str(suggested),
                "final_price": str(final_price),
            },
            description=f"{asset.tracking_code} marked as {asset.status}.",
        )
    return record


def record_physical_audit(asset, result, verified_location, verified_condition, audited_at, follow_up_action, actor, request=None):
    _require_admin_actor(actor)
    follow_up_action = (follow_up_action or "").strip()
    if result == PhysicalAuditResult.MISSING and not follow_up_action:
        raise ValidationError("Follow-up action is required when an asset is marked missing.")

    with transaction.atomic():
        audit = PhysicalAudit(
            asset=asset,
            result=result,
            verified_location=verified_location,
            verified_condition=verified_condition,
            audited_by=actor,
            audited_at=audited_at,
            follow_up_action=follow_up_action,
        )
        touch_instance(audit, actor)
        audit.full_clean()
        audit.save()
        if result == PhysicalAuditResult.FOUND and verified_location:
            asset.current_location = verified_location
        if result == PhysicalAuditResult.FOUND and verified_condition:
            asset.condition = verified_condition
        touch_instance(asset, actor)
        asset.save()
        log_event(
            "physical_audit_recorded",
            actor=actor,
            target=audit,
            request=request,
            description=f"Physical audit recorded for {asset.tracking_code}.",
        )
    return audit


def _run_antivirus_scan(file_bytes):
    command = settings.ANTIVIRUS_COMMAND
    if not command or not shutil.which(command):
        return
    with tempfile.NamedTemporaryFile(delete=False) as temp_file:
        temp_file.write(file_bytes)
        temp_path = temp_file.name
    try:
        result = subprocess.run(
            [command, "--no-summary", temp_path],
            capture_output=True,
            text=True,
            timeout=30,
            check=False,
        )
    finally:
        Path(temp_path).unlink(missing_ok=True)
    if result.returncode not in (0, 1):
        raise ValidationError("Antivirus scan failed.")
    if result.returncode == 1:
        raise ValidationError("Uploaded file failed antivirus scanning.")


def create_attachment(asset, uploaded_file, description, actor, request=None):
    _require_admin_actor(actor)
    file_bytes = uploaded_file.read()
    uploaded_file.seek(0)

    if len(file_bytes) > settings.FILE_UPLOAD_MAX_MEMORY_SIZE:
        raise ValidationError("Files must be 10 MB or smaller.")

    kind = filetype.guess(file_bytes)
    mime = kind.mime if kind else ""
    if mime not in ALLOWED_UPLOAD_MIME_TYPES:
        raise ValidationError("Only PDF, JPG, JPEG, and PNG files are allowed.")

    _run_antivirus_scan(file_bytes)

    digest = hashlib.sha256(file_bytes).hexdigest()
    attachment = Attachment(
        asset=asset,
        original_name=uploaded_file.name,
        content_type=mime,
        size_bytes=len(file_bytes),
        sha256=digest,
        description=description,
    )
    touch_instance(attachment, actor)
    attachment.file.save(uploaded_file.name, ContentFile(file_bytes), save=False)
    attachment.full_clean()
    attachment.save()
    log_event(
        "attachment_uploaded",
        actor=actor,
        target=attachment,
        request=request,
        description=f"Attachment uploaded for {asset.tracking_code}.",
    )
    return attachment


def delete_attachment(attachment, actor, request=None):
    _require_admin_actor(actor)
    attachment.file.delete(save=False)
    log_event(
        "attachment_deleted",
        actor=actor,
        target=attachment,
        request=request,
        description=f"Attachment deleted for {attachment.asset.tracking_code}.",
    )
    attachment.delete()


def delete_asset(asset, actor, request=None):
    _require_admin_actor(actor)
    if (
        asset.assignments.exists()
        or asset.repairs.exists()
        or SaleDisposal.objects.filter(asset=asset).exists()
        or asset.physical_audits.exists()
    ):
        raise ValidationError(
            "This asset cannot be deleted while assignment, repair, sale/disposal, or audit history still references it."
        )

    attachments = list(asset.attachments.all())
    with transaction.atomic():
        log_event(
            "asset_deleted",
            actor=actor,
            target=asset,
            request=request,
            description=f"Asset {asset.tracking_code} deleted.",
            metadata={"attachment_count": len(attachments)},
        )
        for attachment in attachments:
            attachment.file.delete(save=False)
            attachment.delete()
        try:
            asset.delete()
        except ProtectedError as exc:
            raise ValidationError("This asset could not be deleted because other records still reference it.") from exc
    return asset


def filter_assets(queryset, params):
    search = params.get("q", "").strip()
    status = params.get("status", "").strip()
    type_id = params.get("type", "").strip()
    department_id = params.get("department", "").strip()

    if search:
        queryset = queryset.filter(
            Q(tracking_code__icontains=search)
            | Q(asset_tag__icontains=search)
            | Q(serial_no__icontains=search)
            | Q(brand__icontains=search)
            | Q(model__icontains=search)
        )
    if status:
        queryset = queryset.filter(status=status)
    if type_id:
        queryset = queryset.filter(type_id=type_id)
    if department_id:
        queryset = queryset.filter(department_id=department_id)
    return queryset


def failed_login_count(username, ip_address):
    cutoff = datetime.now().astimezone() - timedelta(minutes=settings.LOGIN_WINDOW_MINUTES)
    queryset = AuditEvent.objects.filter(
        event_type="login_failed",
        created_at__gte=cutoff,
    )
    if username:
        queryset = queryset.filter(Q(metadata__username=username) | Q(ip_address=ip_address))
    elif ip_address:
        queryset = queryset.filter(ip_address=ip_address)
    return queryset.count()


def can_attempt_login(username, ip_address):
    return failed_login_count(username, ip_address) < settings.MAX_LOGIN_ATTEMPTS


def set_user_admin_role(user, role, actor, request=None):
    _require_super_admin_actor(actor)
    normalized_role = role or ""
    if normalized_role not in {"", ADMIN_ROLE, SUPER_ADMIN_ROLE}:
        raise ValidationError("Unknown admin role.")
    if user.is_superuser and normalized_role != SUPER_ADMIN_ROLE:
        raise ValidationError("Built-in superusers must retain super-admin access.")

    previous_role = get_user_admin_role(user)
    if previous_role == SUPER_ADMIN_ROLE and normalized_role != SUPER_ADMIN_ROLE:
        remaining_super_admins = _super_admin_user_queryset().exclude(pk=user.pk).count()
        if remaining_super_admins == 0:
            raise ValidationError("At least one active super-admin must remain.")

    admin_group = Group.objects.get(name=ADMIN_ROLE)
    super_admin_group = Group.objects.get(name=SUPER_ADMIN_ROLE)
    user.groups.remove(admin_group, super_admin_group)
    if normalized_role == ADMIN_ROLE:
        user.groups.add(admin_group)
    elif normalized_role == SUPER_ADMIN_ROLE:
        user.groups.add(super_admin_group)

    current_role = get_user_admin_role(user)
    if current_role != previous_role:
        log_event(
            "admin_role_changed",
            actor=actor,
            target=user,
            request=request,
            description=f"Admin role for {user.get_username()} changed from {previous_role or 'none'} to {current_role or 'none'}.",
            metadata={"previous_role": previous_role, "current_role": current_role},
        )
    return current_role


def set_managed_user_active_state(user, *, is_active, actor, request=None):
    _require_super_admin_actor(actor)
    desired_state = bool(is_active)
    if user.is_superuser and not desired_state:
        raise ValidationError("Built-in superusers cannot be deactivated here.")
    if user.is_active == desired_state:
        return user.is_active

    if get_user_admin_role(user) == SUPER_ADMIN_ROLE and not desired_state:
        remaining_super_admins = _super_admin_user_queryset().exclude(pk=user.pk).count()
        if remaining_super_admins == 0:
            raise ValidationError("At least one active super-admin must remain.")

    user.is_active = desired_state
    user.save(update_fields=["is_active"])
    log_event(
        "admin_user_status_changed",
        actor=actor,
        target=user,
        request=request,
        description=f"User {user.get_username()} {'activated' if desired_state else 'deactivated'}.",
        metadata={"is_active": desired_state},
    )
    return user.is_active


def delete_managed_user(user, actor, request=None):
    _require_super_admin_actor(actor)
    if actor is not None and user.pk == actor.pk:
        raise ValidationError("You cannot delete your own account here.")
    if get_user_admin_role(user) == SUPER_ADMIN_ROLE:
        remaining_super_admins = _super_admin_user_queryset().exclude(pk=user.pk).count()
        if remaining_super_admins == 0:
            raise ValidationError("At least one active super-admin must remain.")

    previous_role = get_user_admin_role(user)
    try:
        with transaction.atomic():
            log_event(
                "admin_user_deleted",
                actor=actor,
                target=user,
                request=request,
                description=f"Managed user {user.get_username()} deleted.",
                metadata={"role": previous_role or "none"},
            )
            user.delete()
    except ProtectedError as exc:
        raise ValidationError("This user cannot be deleted while physical audit history still references them.") from exc
    return previous_role


def _normalize_alert_recipients(value):
    if isinstance(value, str):
        parts = value.replace(";", ",").replace("\n", ",").split(",")
    else:
        parts = value or []

    recipients = []
    seen = set()
    for raw_email in parts:
        email = str(raw_email).strip()
        if not email or email in seen:
            continue
        recipients.append(email)
        seen.add(email)
    return recipients


def _to_local_date(value):
    if value is None:
        return None
    if timezone.is_aware(value):
        return timezone.localtime(value).date()
    return value.date()


def _due_item(asset, due_date, days_remaining):
    return {
        "asset": asset,
        "due_date": due_date,
        "days_remaining": days_remaining,
    }


def build_operational_report(*, today=None, recent_changes_limit=12):
    today = today or timezone.localdate()
    assets = list(Asset.objects.select_related("type", "department", "current_location"))
    latest_audit_rows = PhysicalAudit.objects.values("asset_id").annotate(last_audited_at=Max("audited_at"))
    latest_audit_dates = {
        row["asset_id"]: _to_local_date(row["last_audited_at"])
        for row in latest_audit_rows
        if row["last_audited_at"]
    }
    open_repairs = list(RepairLog.objects.filter(closed_at__isnull=True).select_related("asset", "asset__type"))
    status_counts = {
        status: 0
        for status, _label in Asset._meta.get_field("status").choices
    }
    replacement_due_soon_assets = []
    replacement_overdue_assets = []
    audit_due_soon_assets = []
    audit_overdue_assets = []
    never_audited_assets = []
    warranty_due_soon_assets = []
    warranty_overdue_assets = []
    missing_invoice_assets = []

    for asset in assets:
        status_counts[asset.status] += 1
        if not asset.invoice_no.strip():
            missing_invoice_assets.append(asset)

        if asset.status not in {AssetStatus.RETIRED, AssetStatus.SOLD, AssetStatus.DISPOSED}:
            replacement_days = days_until(asset.expiry_date, today=today)
            if replacement_days is not None:
                if replacement_days < 0:
                    replacement_overdue_assets.append(_due_item(asset, asset.expiry_date, replacement_days))
                elif replacement_days <= settings.REPLACEMENT_DUE_SOON_DAYS:
                    replacement_due_soon_assets.append(_due_item(asset, asset.expiry_date, replacement_days))

        if asset.status not in {AssetStatus.SOLD, AssetStatus.DISPOSED}:
            warranty_days = days_until(asset.warranty_expiry_date, today=today)
            if warranty_days is not None:
                if warranty_days < 0:
                    warranty_overdue_assets.append(
                        _due_item(asset, asset.warranty_expiry_date, warranty_days)
                    )
                elif warranty_days <= settings.WARRANTY_DUE_SOON_DAYS:
                    warranty_due_soon_assets.append(
                        _due_item(asset, asset.warranty_expiry_date, warranty_days)
                    )

            last_audit_at = latest_audit_dates.get(asset.pk)
            if last_audit_at is None:
                first_due_date = next_due_date(asset.created_at.date(), settings.PHYSICAL_AUDIT_CADENCE_DAYS)
                never_audited_assets.append(_due_item(asset, first_due_date, days_until(first_due_date, today=today)))
            else:
                next_audit_due = next_due_date(last_audit_at, settings.PHYSICAL_AUDIT_CADENCE_DAYS)
                audit_days = days_until(next_audit_due, today=today)
                if audit_days is not None:
                    if audit_days < 0:
                        audit_overdue_assets.append(_due_item(asset, next_audit_due, audit_days))
                    elif audit_days <= settings.AUDIT_DUE_SOON_DAYS:
                        audit_due_soon_assets.append(_due_item(asset, next_audit_due, audit_days))

    return {
        "status_counts": status_counts,
        "due_replacement": len(replacement_due_soon_assets) + len(replacement_overdue_assets),
        "due_audit": len(audit_due_soon_assets) + len(audit_overdue_assets),
        "never_audited_count": len(never_audited_assets),
        "warranty_due": len(warranty_due_soon_assets),
        "warranty_overdue": len(warranty_overdue_assets),
        "open_repairs_count": len(open_repairs),
        "missing_invoices": len(missing_invoice_assets),
        "recent_changes": list(AuditEvent.objects.select_related("actor")[:recent_changes_limit]),
        "replacement_due_soon_assets": replacement_due_soon_assets,
        "replacement_overdue_assets": replacement_overdue_assets,
        "audit_due_soon_assets": audit_due_soon_assets,
        "audit_overdue_assets": audit_overdue_assets,
        "never_audited_assets": never_audited_assets,
        "warranty_due_soon_assets": warranty_due_soon_assets,
        "warranty_overdue_assets": warranty_overdue_assets,
        "open_repairs": open_repairs,
        "missing_invoice_assets": missing_invoice_assets,
    }


def get_alert_recipient_list():
    value = get_setting("alert_recipients", [])
    return _normalize_alert_recipients(value)


def set_alert_recipient_list(value, actor=None):
    recipients = _normalize_alert_recipients(value)
    set_setting("alert_recipients", recipients, actor=actor)
    return recipients
