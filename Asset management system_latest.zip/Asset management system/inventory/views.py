from django.contrib import messages
from django.contrib.auth import get_user_model
from django.contrib.auth import login, logout
from django.core.exceptions import PermissionDenied, ValidationError
from django.db.models.deletion import ProtectedError
from django.http import FileResponse, Http404
from django.shortcuts import get_object_or_404, redirect, render
from django.utils.dateparse import parse_date
from django.utils.http import url_has_allowed_host_and_scheme
from django.utils import timezone
from django.views.decorators.http import require_http_methods

from .backups import create_backup_bundle, restore_backup_bundle
from .exports import DATASET_LABELS, build_export_response
from .forms import (
    AdminUserCreateForm,
    AssetForm,
    AssignmentForm,
    AttachmentForm,
    DepartmentForm,
    ImportUploadForm,
    LocationForm,
    LoginForm,
    PhysicalAuditForm,
    RepairCloseForm,
    RepairLogForm,
    ReturnAssignmentForm,
    SaleDisposalForm,
    SettingsForm,
    StaffMemberForm,
    VendorForm,
)
from .imports import FIELD_CHOICES, commit_batch, create_batch_from_upload, validate_batch
from .models import (
    Asset,
    AssetStatus,
    AssetType,
    Assignment,
    Attachment,
    AuditEvent,
    BackupBundle,
    BackupBundleKind,
    Department,
    ImportBatch,
    ImportBatchStatus,
    Location,
    PhysicalAudit,
    RepairLog,
    SaleDisposal,
    StaffMember,
    Vendor,
)
from .permissions import (
    ADMIN_ROLE,
    SUPER_ADMIN_ROLE,
    get_user_admin_role,
    has_super_admin_access,
    require_admin_access,
    require_super_admin_access,
)
from .services import (
    build_operational_report,
    can_attempt_login,
    create_assignment,
    create_attachment,
    delete_asset,
    delete_managed_user,
    delete_attachment,
    filter_assets,
    get_alert_recipient_list,
    get_request_ip,
    get_setting,
    log_event,
    open_repair,
    record_physical_audit,
    record_sale_disposal,
    return_assignment,
    set_alert_recipient_list,
    set_setting,
    suggested_sale_price,
    sync_asset_status,
    touch_instance,
    close_repair,
    set_managed_user_active_state,
    set_user_admin_role,
)
from .utils import build_spec_items

User = get_user_model()


def _redirect_after_login(request):
    next_url = request.GET.get("next") or request.POST.get("next")
    if next_url and url_has_allowed_host_and_scheme(
        next_url,
        allowed_hosts={request.get_host()},
        require_https=request.is_secure(),
    ):
        return redirect(next_url)
    return redirect("dashboard")


def _get_optional_object(model, object_id):
    if not object_id:
        return None
    return get_object_or_404(model, pk=object_id)


def _delete_managed_object(request, obj, *, redirect_name, event_type, success_message, protected_message):
    try:
        obj.delete()
    except ProtectedError:
        messages.error(request, protected_message)
    else:
        log_event(event_type, actor=request.user, target=obj, request=request)
        messages.success(request, success_message)
    return redirect(redirect_name)


@require_http_methods(["GET", "POST"])
def login_view(request):
    if request.user.is_authenticated:
        return redirect("dashboard")

    username = request.POST.get("username", "").strip()
    ip_address = get_request_ip(request)
    throttled = request.method == "POST" and not can_attempt_login(username, ip_address)
    form = LoginForm(request, data=request.POST or None)

    if throttled:
        messages.error(request, "Too many failed login attempts. Try again later.")
        log_event(
            "login_throttled",
            request=request,
            success=False,
            metadata={"username": username},
            description="Login attempt blocked by throttling.",
        )
    elif request.method == "POST" and form.is_valid():
        login(request, form.get_user())
        return _redirect_after_login(request)

    return render(request, "registration/login.html", {"form": form})


def csrf_failure_view(request, reason=""):
    log_event(
        "csrf_rejected",
        actor=request.user if request.user.is_authenticated else None,
        request=request,
        success=False,
        description="CSRF verification failed.",
        metadata={"path": request.path, "method": request.method, "reason": reason},
    )
    return render(request, "inventory/csrf_failure.html", {"reason": reason}, status=403)


@require_http_methods(["POST"])
def logout_view(request):
    logout(request)
    return redirect("login")


def dashboard_view(request):
    require_admin_access(request.user)
    context = build_operational_report()
    return render(request, "inventory/dashboard.html", context)


def asset_list_view(request):
    require_admin_access(request.user)
    queryset = Asset.objects.select_related("type", "department", "current_location")
    queryset = filter_assets(queryset, request.GET)
    context = {
        "assets": queryset,
        "status_choices": AssetStatus.choices,
        "asset_types": AssetType.objects.all(),
        "departments": Department.objects.all(),
        "filters": request.GET,
        "export_querystring": request.GET.urlencode(),
    }
    return render(request, "inventory/asset_list.html", context)


@require_http_methods(["GET", "POST"])
def asset_create_view(request):
    require_admin_access(request.user)
    form = AssetForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        asset = form.save(commit=False)
        touch_instance(asset, request.user)
        asset.full_clean()
        asset.save()
        log_event("asset_created", actor=request.user, target=asset, request=request)
        messages.success(request, "Asset created.")
        return redirect("asset-detail", asset_id=asset.pk)
    return render(request, "inventory/asset_form.html", {"form": form, "page_title": "New Asset"})


@require_http_methods(["GET", "POST"])
def asset_update_view(request, asset_id):
    require_admin_access(request.user)
    asset = get_object_or_404(Asset, pk=asset_id)
    form = AssetForm(request.POST or None, instance=asset)
    if request.method == "POST" and form.is_valid():
        asset = form.save(commit=False)
        touch_instance(asset, request.user)
        asset.full_clean()
        asset.save()
        sync_asset_status(asset, actor=request.user)
        log_event("asset_updated", actor=request.user, target=asset, request=request)
        messages.success(request, "Asset updated.")
        return redirect("asset-detail", asset_id=asset.pk)
    return render(request, "inventory/asset_form.html", {"form": form, "page_title": "Edit Asset", "asset": asset})


@require_http_methods(["GET", "POST"])
def asset_detail_view(request, asset_id):
    require_admin_access(request.user)
    asset = get_object_or_404(
        Asset.objects.select_related("type", "department", "current_location", "vendor", "custodian_it_owner"),
        pk=asset_id,
    )
    attachment_form = AttachmentForm(request.POST or None, request.FILES or None)
    if request.method == "POST":
        if attachment_form.is_valid():
            try:
                create_attachment(
                    asset=asset,
                    uploaded_file=attachment_form.cleaned_data["file"],
                    description=attachment_form.cleaned_data["description"],
                    actor=request.user,
                    request=request,
                )
            except ValidationError as exc:
                attachment_form.add_error(None, exc)
            else:
                messages.success(request, "Attachment uploaded.")
                return redirect("asset-detail", asset_id=asset.pk)

    current_assignment = asset.assignments.filter(returned_at__isnull=True).select_related("staff_member").first()
    open_repair = asset.repairs.filter(closed_at__isnull=True).select_related("vendor").first()
    sale_disposal = getattr(asset, "sale_disposal", None)
    context = {
        "asset": asset,
        "spec_items": build_spec_items(asset.specs_json),
        "current_assignment": current_assignment,
        "open_repair": open_repair,
        "sale_disposal": sale_disposal,
        "attachments": asset.attachments.all(),
        "assignment_history": asset.assignments.select_related("staff_member"),
        "repair_history": asset.repairs.select_related("vendor"),
        "audit_history": asset.physical_audits.select_related("audited_by", "verified_location"),
        "attachment_form": attachment_form,
        "can_assign": asset.status not in {AssetStatus.SOLD, AssetStatus.DISPOSED} and current_assignment is None and open_repair is None,
        "can_repair": asset.status not in {AssetStatus.SOLD, AssetStatus.DISPOSED} and open_repair is None,
        "can_sell": (
            asset.status not in {AssetStatus.SOLD, AssetStatus.DISPOSED}
            and sale_disposal is None
            and current_assignment is None
            and open_repair is None
        ),
    }
    return render(request, "inventory/asset_detail.html", context)


@require_http_methods(["POST"])
def asset_delete_view(request, asset_id):
    require_admin_access(request.user)
    asset = get_object_or_404(Asset.objects.prefetch_related("attachments"), pk=asset_id)
    try:
        delete_asset(asset, actor=request.user, request=request)
    except ValidationError as exc:
        messages.error(request, exc)
        return redirect("asset-detail", asset_id=asset_id)
    messages.success(request, "Asset deleted.")
    return redirect("asset-list")


@require_http_methods(["GET", "POST"])
def asset_assign_view(request, asset_id):
    require_admin_access(request.user)
    asset = get_object_or_404(Asset, pk=asset_id)
    form = AssignmentForm(request.POST or None, asset=asset)
    if request.method == "POST" and form.is_valid():
        try:
            create_assignment(
                asset=asset,
                staff_member=form.cleaned_data["staff_member"],
                assigned_at=form.cleaned_data["assigned_at"],
                notes=form.cleaned_data["notes"],
                actor=request.user,
                request=request,
            )
        except ValidationError as exc:
            form.add_error(None, exc)
        else:
            messages.success(request, "Assignment recorded.")
            return redirect("asset-detail", asset_id=asset.pk)
    return render(request, "inventory/simple_form.html", {"form": form, "page_title": f"Assign {asset.tracking_code}"})


@require_http_methods(["GET", "POST"])
def assignment_return_view(request, assignment_id):
    require_admin_access(request.user)
    assignment = get_object_or_404(Assignment.objects.select_related("asset", "staff_member"), pk=assignment_id)
    form = ReturnAssignmentForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        try:
            return_assignment(
                assignment=assignment,
                returned_at=form.cleaned_data["returned_at"],
                actor=request.user,
                request=request,
            )
        except ValidationError as exc:
            form.add_error(None, exc)
        else:
            messages.success(request, "Assignment closed.")
            return redirect("asset-detail", asset_id=assignment.asset_id)
    return render(request, "inventory/simple_form.html", {"form": form, "page_title": "Return Assignment"})


@require_http_methods(["GET", "POST"])
def asset_repair_view(request, asset_id):
    require_admin_access(request.user)
    asset = get_object_or_404(Asset, pk=asset_id)
    form = RepairLogForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        try:
            open_repair(
                asset=asset,
                issue=form.cleaned_data["issue"],
                opened_at=form.cleaned_data["opened_at"],
                cost=form.cleaned_data["cost"],
                vendor=form.cleaned_data["vendor"],
                resolution_notes=form.cleaned_data["resolution_notes"],
                actor=request.user,
                request=request,
            )
        except ValidationError as exc:
            form.add_error(None, exc)
        else:
            messages.success(request, "Repair opened.")
            return redirect("asset-detail", asset_id=asset.pk)
    return render(request, "inventory/simple_form.html", {"form": form, "page_title": f"Repair {asset.tracking_code}"})


@require_http_methods(["GET", "POST"])
def repair_close_view(request, repair_id):
    require_admin_access(request.user)
    repair = get_object_or_404(RepairLog.objects.select_related("asset"), pk=repair_id)
    form = RepairCloseForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        try:
            close_repair(
                repair=repair,
                closed_at=form.cleaned_data["closed_at"],
                resolution_notes=form.cleaned_data["resolution_notes"],
                actor=request.user,
                request=request,
            )
        except ValidationError as exc:
            form.add_error(None, exc)
        else:
            messages.success(request, "Repair closed.")
            return redirect("asset-detail", asset_id=repair.asset_id)
    return render(request, "inventory/simple_form.html", {"form": form, "page_title": "Close Repair"})


@require_http_methods(["GET", "POST"])
def asset_sell_view(request, asset_id):
    require_admin_access(request.user)
    asset = get_object_or_404(Asset, pk=asset_id)
    if getattr(asset, "sale_disposal", None):
        messages.info(request, "A sale/disposal record already exists for this asset.")
        return redirect("asset-detail", asset_id=asset.pk)

    recorded_at = parse_date(request.POST.get("recorded_at", "")) if request.method == "POST" else None
    recorded_at = recorded_at or timezone.localdate()
    suggested_price = suggested_sale_price(asset, recorded_at)
    form = SaleDisposalForm(
        request.POST or None,
        instance=SaleDisposal(asset=asset),
        suggested_price=suggested_price,
        initial={"recorded_at": recorded_at, "final_price": suggested_price},
    )
    if request.method == "POST" and form.is_valid():
        try:
            record_sale_disposal(
                asset=asset,
                action=form.cleaned_data["action"],
                recorded_at=form.cleaned_data["recorded_at"],
                final_price=form.cleaned_data["final_price"],
                notes=form.cleaned_data["notes"],
                actor=request.user,
                request=request,
            )
        except ValidationError as exc:
            form.add_error(None, exc)
        else:
            messages.success(request, "Sale/disposal recorded.")
            return redirect("asset-detail", asset_id=asset.pk)
    return render(request, "inventory/simple_form.html", {"form": form, "page_title": f"Sell or Dispose {asset.tracking_code}"})


def attachment_download_view(request, attachment_id):
    require_admin_access(request.user)
    attachment = get_object_or_404(Attachment.objects.select_related("asset"), pk=attachment_id)
    if not attachment.file:
        raise Http404("Attachment file is missing.")
    log_event("attachment_downloaded", actor=request.user, target=attachment, request=request)
    return FileResponse(attachment.file.open("rb"), as_attachment=True, filename=attachment.original_name)


@require_http_methods(["POST"])
def attachment_delete_view(request, attachment_id):
    require_admin_access(request.user)
    attachment = get_object_or_404(Attachment.objects.select_related("asset"), pk=attachment_id)
    asset_id = attachment.asset_id
    delete_attachment(attachment, actor=request.user, request=request)
    messages.success(request, "Attachment deleted.")
    return redirect("asset-detail", asset_id=asset_id)


@require_http_methods(["GET", "POST"])
def audits_view(request):
    require_admin_access(request.user)
    form = PhysicalAuditForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        try:
            record_physical_audit(
                asset=form.cleaned_data["asset"],
                result=form.cleaned_data["result"],
                verified_location=form.cleaned_data["verified_location"],
                verified_condition=form.cleaned_data["verified_condition"],
                audited_at=form.cleaned_data["audited_at"],
                follow_up_action=form.cleaned_data["follow_up_action"],
                actor=request.user,
                request=request,
            )
        except ValidationError as exc:
            form.add_error(None, exc)
        else:
            messages.success(request, "Physical audit recorded.")
            return redirect("audits")

    assets = Asset.objects.select_related("type")
    context = {
        "form": form,
        "audits": PhysicalAudit.objects.select_related("asset", "audited_by", "verified_location")[:50],
        "never_audited": [asset for asset in assets if asset.last_audit_at is None],
        "audit_due": [asset for asset in assets if asset.audit_due_soon],
    }
    return render(request, "inventory/audits.html", context)


@require_http_methods(["GET", "POST"])
def imports_view(request):
    require_admin_access(request.user)
    form = ImportUploadForm(request.POST or None, request.FILES or None)
    if request.method == "POST" and form.is_valid():
        try:
            batch = create_batch_from_upload(form.cleaned_data["source_file"], actor=request.user)
        except ValidationError as exc:
            form.add_error("source_file", exc)
        else:
            log_event("import_uploaded", actor=request.user, target=batch, request=request)
            messages.success(request, f"Import batch {batch.batch_id} uploaded.")
            return redirect("import-detail", batch_id=batch.pk)
    context = {
        "form": form,
        "batches": ImportBatch.objects.select_related("created_by")[:25],
    }
    return render(request, "inventory/imports.html", context)


@require_http_methods(["GET", "POST"])
def import_detail_view(request, batch_id):
    require_admin_access(request.user)
    batch = get_object_or_404(ImportBatch.objects.select_related("created_by"), pk=batch_id)
    header_rows = [
        {"header": header, "field_name": f"map_{index}", "value": batch.column_mapping.get(header, "")}
        for index, header in enumerate(batch.source_headers)
    ]

    if request.method == "POST":
        mapping = {
            header: request.POST.get(f"map_{index}", "")
            for index, header in enumerate(batch.source_headers)
        }
        batch.column_mapping = mapping
        batch.save(update_fields=["column_mapping", "updated_at"])
        action = request.POST.get("action")
        if action == "dry_run":
            try:
                validate_batch(batch, mapping)
            except ValidationError as exc:
                messages.error(request, exc)
            else:
                log_event("import_dry_run", actor=request.user, target=batch, request=request)
                messages.success(request, f"Dry run completed for {batch.batch_id}.")
        elif action == "commit":
            try:
                commit_batch(batch, actor=request.user, request=request)
            except ValidationError as exc:
                messages.error(request, exc)
            else:
                messages.success(request, f"Import batch {batch.batch_id} committed.")
        else:
            messages.success(request, "Column mapping saved.")
        return redirect("import-detail", batch_id=batch.pk)

    context = {
        "batch": batch,
        "header_rows": header_rows,
        "field_choices": FIELD_CHOICES,
        "can_commit_batch": batch.status == ImportBatchStatus.DRY_RUN_OK,
    }
    return render(request, "inventory/import_detail.html", context)


def exports_view(request):
    require_admin_access(request.user)
    dataset = request.GET.get("dataset")
    export_format = request.GET.get("format")
    if dataset and export_format:
        try:
            response = build_export_response(dataset, export_format, request.GET, request.user)
        except ValueError as exc:
            messages.error(request, exc)
            return redirect("exports")
        log_event(
            "export_downloaded",
            actor=request.user,
            request=request,
            description=f"{dataset} exported as {export_format}.",
            metadata={"dataset": dataset, "format": export_format},
        )
        return response
    visible_datasets = DATASET_LABELS.copy()
    if not has_super_admin_access(request.user):
        visible_datasets.pop("activity", None)
    return render(request, "inventory/exports.html", {"datasets": visible_datasets})


@require_http_methods(["GET", "POST"])
def backups_view(request):
    require_super_admin_access(request.user)
    if request.method == "POST":
        create_backup_bundle(BackupBundleKind.MANUAL, actor=request.user, request=request)
        messages.success(request, "Backup created.")
        return redirect("backups")
    bundles = BackupBundle.objects.select_related("created_by")
    return render(
        request,
        "inventory/backups.html",
        {
            "bundles": bundles,
            "maintenance_mode": bool(get_setting("maintenance_mode", False)),
        },
    )


def backup_download_view(request, bundle_id):
    require_super_admin_access(request.user)
    bundle = get_object_or_404(BackupBundle, pk=bundle_id)
    log_event("backup_downloaded", actor=request.user, target=bundle, request=request)
    return FileResponse(open(bundle.archive_path, "rb"), as_attachment=True, filename=bundle.archive_name)


@require_http_methods(["POST"])
def backup_restore_view(request, bundle_id):
    require_super_admin_access(request.user)
    bundle = get_object_or_404(BackupBundle, pk=bundle_id)
    try:
        restore_backup_bundle(bundle, actor=request.user, request=request)
        set_setting("maintenance_mode", False, actor=request.user)
    except ValidationError as exc:
        messages.error(request, exc)
    else:
        messages.success(request, "Backup restored and maintenance mode disabled.")
    return redirect("backups")


@require_http_methods(["GET", "POST"])
def staff_view(request):
    require_admin_access(request.user)
    editing_staff_member = _get_optional_object(StaffMember, request.GET.get("edit") or request.POST.get("staff_id"))
    form = StaffMemberForm(request.POST or None, instance=editing_staff_member)

    if request.method == "POST":
        action = request.POST.get("action", "save_staff")
        if action == "delete_staff":
            staff_member = get_object_or_404(StaffMember, pk=request.POST.get("staff_id"))
            return _delete_managed_object(
                request,
                staff_member,
                redirect_name="staff",
                event_type="staff_member_deleted",
                success_message="Staff member deleted.",
                protected_message="This staff member cannot be deleted while assignment history still references them.",
            )
        if action == "save_staff" and form.is_valid():
            is_create = editing_staff_member is None
            staff_member = form.save()
            log_event(
                "staff_member_created" if is_create else "staff_member_updated",
                actor=request.user,
                target=staff_member,
                request=request,
            )
            messages.success(request, "Staff member created." if is_create else "Staff member updated.")
            return redirect("staff")
    context = {
        "form": form,
        "staff_members": StaffMember.objects.select_related("department", "location"),
        "editing_staff_member": editing_staff_member,
    }
    return render(request, "inventory/staff.html", context)


@require_http_methods(["GET", "POST"])
def departments_view(request):
    require_admin_access(request.user)
    editing_department = _get_optional_object(
        Department,
        request.GET.get("edit_department") or request.POST.get("department_id"),
    )
    editing_location = _get_optional_object(
        Location,
        request.GET.get("edit_location") or request.POST.get("location_id"),
    )
    department_form = DepartmentForm(prefix="department", data=request.POST or None, instance=editing_department)
    location_form = LocationForm(prefix="location", data=request.POST or None, instance=editing_location)

    if request.method == "POST":
        action = request.POST.get("action")
        if action == "delete_department":
            department = get_object_or_404(Department, pk=request.POST.get("department_id"))
            return _delete_managed_object(
                request,
                department,
                redirect_name="departments",
                event_type="department_deleted",
                success_message="Department deleted.",
                protected_message="Department could not be deleted.",
            )
        if action == "save_department" and department_form.is_valid():
            is_create = editing_department is None
            department = department_form.save()
            log_event(
                "department_created" if is_create else "department_updated",
                actor=request.user,
                target=department,
                request=request,
            )
            messages.success(request, "Department created." if is_create else "Department updated.")
            return redirect("departments")
        if action == "delete_location":
            location = get_object_or_404(Location, pk=request.POST.get("location_id"))
            return _delete_managed_object(
                request,
                location,
                redirect_name="departments",
                event_type="location_deleted",
                success_message="Location deleted.",
                protected_message="Location could not be deleted.",
            )
        if action == "save_location" and location_form.is_valid():
            is_create = editing_location is None
            location = location_form.save()
            log_event(
                "location_created" if is_create else "location_updated",
                actor=request.user,
                target=location,
                request=request,
            )
            messages.success(request, "Location created." if is_create else "Location updated.")
            return redirect("departments")

    context = {
        "department_form": department_form,
        "location_form": location_form,
        "departments": Department.objects.all(),
        "editing_department": editing_department,
        "editing_location": editing_location,
        "locations": Location.objects.all(),
    }
    return render(request, "inventory/departments.html", context)


@require_http_methods(["GET", "POST"])
def vendors_view(request):
    require_admin_access(request.user)
    editing_vendor = _get_optional_object(Vendor, request.GET.get("edit") or request.POST.get("vendor_id"))
    form = VendorForm(request.POST or None, instance=editing_vendor)

    if request.method == "POST":
        action = request.POST.get("action", "save_vendor")
        if action == "delete_vendor":
            vendor = get_object_or_404(Vendor, pk=request.POST.get("vendor_id"))
            return _delete_managed_object(
                request,
                vendor,
                redirect_name="vendors",
                event_type="vendor_deleted",
                success_message="Vendor deleted.",
                protected_message="Vendor could not be deleted.",
            )
        if action == "save_vendor" and form.is_valid():
            is_create = editing_vendor is None
            vendor = form.save()
            log_event(
                "vendor_created" if is_create else "vendor_updated",
                actor=request.user,
                target=vendor,
                request=request,
            )
            messages.success(request, "Vendor created." if is_create else "Vendor updated.")
            return redirect("vendors")

    context = {
        "form": form,
        "editing_vendor": editing_vendor,
        "vendors": Vendor.objects.all(),
    }
    return render(request, "inventory/vendors.html", context)


@require_http_methods(["GET", "POST"])
def admin_users_view(request):
    require_super_admin_access(request.user)
    create_form = AdminUserCreateForm(user_model=User, prefix="create")

    if request.method == "POST":
        action = request.POST.get("action")
        if action == "create_user":
            create_form = AdminUserCreateForm(request.POST, user_model=User, prefix="create")
            if create_form.is_valid():
                user = User.objects.create_user(
                    username=create_form.cleaned_data["username"],
                    email=create_form.cleaned_data["email"],
                    password=create_form.cleaned_data["password"],
                )
                set_user_admin_role(
                    user,
                    create_form.cleaned_data["role"],
                    actor=request.user,
                    request=request,
                )
                log_event(
                    "admin_user_created",
                    actor=request.user,
                    target=user,
                    request=request,
                    description=f"Managed admin user {user.get_username()} created.",
                    metadata={"role": create_form.cleaned_data["role"]},
                )
                messages.success(request, "Admin user created.")
                return redirect("admin-users")
        elif action == "update_user":
            managed_user = get_object_or_404(User, pk=request.POST.get("user_id"))
            requested_role = request.POST.get("role", "")
            requested_active_state = request.POST.get("is_active") == "on"
            try:
                if requested_role != get_user_admin_role(managed_user):
                    set_user_admin_role(
                        managed_user,
                        requested_role,
                        actor=request.user,
                        request=request,
                    )
                if requested_active_state != managed_user.is_active:
                    set_managed_user_active_state(
                        managed_user,
                        is_active=requested_active_state,
                        actor=request.user,
                        request=request,
                    )
            except ValidationError as exc:
                messages.error(request, exc)
            else:
                messages.success(request, "Admin user updated.")
                return redirect("admin-users")
        elif action == "delete_user":
            managed_user = get_object_or_404(User, pk=request.POST.get("user_id"))
            try:
                delete_managed_user(
                    managed_user,
                    actor=request.user,
                    request=request,
                )
            except ValidationError as exc:
                messages.error(request, exc)
            else:
                messages.success(request, "Admin user deleted.")
                return redirect("admin-users")

    managed_users = list(User.objects.order_by("username").prefetch_related("groups"))
    for managed_user in managed_users:
        managed_user.admin_role = get_user_admin_role(managed_user)
    context = {
        "create_form": create_form,
        "managed_users": managed_users,
        "admin_role": ADMIN_ROLE,
        "super_admin_role": SUPER_ADMIN_ROLE,
    }
    return render(request, "inventory/admin_users.html", context)


@require_http_methods(["GET", "POST"])
def settings_view(request):
    require_super_admin_access(request.user)
    initial = {
        "maintenance_mode": bool(get_setting("maintenance_mode", False)),
        "alert_recipients": ", ".join(get_alert_recipient_list()),
    }
    form = SettingsForm(request.POST or None, initial=initial)
    if request.method == "POST" and form.is_valid():
        maintenance_mode = form.cleaned_data["maintenance_mode"]
        recipients = set_alert_recipient_list(form.cleaned_data["alert_recipients"], actor=request.user)
        set_setting("maintenance_mode", maintenance_mode, actor=request.user)
        log_event(
            "settings_updated",
            actor=request.user,
            request=request,
            description="System settings updated.",
            metadata={
                "maintenance_mode": maintenance_mode,
                "alert_recipient_count": len(recipients),
            },
        )
        messages.success(request, "System settings updated.")
        return redirect("settings")
    context = {
        "form": form,
        "backup_retention_days": get_setting("backup_retention_days", 14),
        "maintenance_mode": bool(get_setting("maintenance_mode", False)),
        "current_alert_recipients": get_alert_recipient_list(),
    }
    return render(request, "inventory/settings.html", context)


def audit_log_view(request):
    require_super_admin_access(request.user)
    queryset = AuditEvent.objects.select_related("actor")
    event_type = request.GET.get("event_type", "").strip()
    success = request.GET.get("success", "").strip()
    if event_type:
        queryset = queryset.filter(event_type=event_type)
    if success in {"0", "1"}:
        queryset = queryset.filter(success=success == "1")
    context = {
        "events": queryset[:200],
        "filters": request.GET,
        "export_querystring": request.GET.urlencode(),
    }
    return render(request, "inventory/audit_log.html", context)
