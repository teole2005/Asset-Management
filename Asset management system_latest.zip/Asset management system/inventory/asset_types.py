from django.db.models import Case, IntegerField, Value, When

from .models import AssetType
from .utils import clean_text


DEFAULT_ASSET_TYPE_NAMES = ("Laptop", "Monitor", "Desktop", "Printer")


def canonicalize_asset_type_name(value):
    normalized = clean_text(value)
    if not normalized:
        return ""

    lowered = normalized.casefold()
    for default_name in DEFAULT_ASSET_TYPE_NAMES:
        if lowered == default_name.casefold():
            return default_name

    return normalized


def ensure_default_asset_types():
    existing_names = set(
        AssetType.objects.filter(name__in=DEFAULT_ASSET_TYPE_NAMES).values_list("name", flat=True)
    )
    AssetType.objects.bulk_create(
        [AssetType(name=name) for name in DEFAULT_ASSET_TYPE_NAMES if name not in existing_names],
        ignore_conflicts=True,
    )


def asset_types_queryset():
    sort_key = Case(
        *[When(name=name, then=Value(index)) for index, name in enumerate(DEFAULT_ASSET_TYPE_NAMES)],
        default=Value(len(DEFAULT_ASSET_TYPE_NAMES)),
        output_field=IntegerField(),
    )
    return AssetType.objects.annotate(_sort_key=sort_key).order_by("_sort_key", "name")
