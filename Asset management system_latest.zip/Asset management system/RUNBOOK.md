# Asset Management System Runbook

Last updated: 2026-03-11
Workspace: `C:\Users\zhengyu\Downloads\Asset management system`

## Runtime Baseline

- Tested in this workspace with `Python 3.14.2`
- Python package baseline:
  - `Django==6.0.3`
  - `openpyxl==3.1.5`
  - `filetype==1.2.0`
- Primary database file: `db.sqlite3`
- Local media root: `media/`
- Backup archive root: `var/backups/`

## Local Setup And Run

1. Create and activate a virtual environment.
2. Install dependencies:

```powershell
python -m pip install -r requirements.txt
```

3. Apply migrations and seed the required groups/settings:

```powershell
python manage.py migrate
```

4. Bootstrap the first operator account:

```powershell
python manage.py createsuperuser
```

`is_superuser` users are treated as `super_admin` by the app, so this is sufficient for first login and restore/settings access.

5. Start the local app:

```powershell
python manage.py runserver
```

6. Open `http://127.0.0.1:8000/login`.

After the first login, create lower-privilege `admin` users from the in-app `Admin Users` page if needed.

### Real Email Delivery

By default, alert emails use Django's console backend, which prints messages to the terminal instead of delivering them.

To send real emails, set these environment variables before starting `runserver` or running `send_daily_alerts`:

```powershell
setx DJANGO_EMAIL_BACKEND "django.core.mail.backends.smtp.EmailBackend"
setx DJANGO_DEFAULT_FROM_EMAIL "it-ticketing@manforce.my"
setx DJANGO_EMAIL_HOST "mail.manforce.my"
setx DJANGO_EMAIL_PORT "465"
setx DJANGO_EMAIL_HOST_USER "it-ticketing@manforce.my"
setx DJANGO_EMAIL_HOST_PASSWORD "P@ssw0rd1!@#"
setx DJANGO_EMAIL_USE_TLS "0"
setx DJANGO_EMAIL_USE_SSL "1"
Important:

setx only affects new terminals, not the current one
after running it, close and reopen PowerShell / VS Code terminal

python -c "import os; print(os.environ.get('DJANGO_EMAIL_BACKEND')); print(os.environ.get('DJANGO_EMAIL_HOST'))"

python manage.py send_daily_alerts
```

Optional:

```powershell
$env:DJANGO_EMAIL_USE_SSL='0'
$env:DJANGO_EMAIL_TIMEOUT='30'
```

After setting those values, restart the Django process and run:

```powershell
python manage.py send_daily_alerts
```

Use an app password or provider-specific SMTP credential where required. Do not hardcode secrets in the repository.

## Import Workflow

Use `/imports` as an `admin` or `super_admin` user.

1. Upload a `.csv` or `.xlsx` file.
2. Review and adjust the detected column mapping.
3. Run `Dry Run`.
4. Review `Summary`, `Duplicate Report`, and `Row Errors`.
5. Commit only when the batch shows no validation errors and no duplicates.

Import behavior to expect:

- Header detection skips preamble rows and uses the first detected real header row.
- Legacy `Occupied` status is normalized to `Assigned`.
- Missing `asset_tag` values default to the row `tracking_code`.
- Commit is all-or-nothing inside one database transaction.

### Primary Workbook Note

The primary source workbook is `Asset_Search_listing_latest.xlsx`.

As verified on 2026-03-11, the workbook produced `269` import rows and a raw dry run was not commit-ready because the source data still contains:

- Row `120`: invalid lifespan value and warranty expiry earlier than purchase date
- Row `121`: invalid lifespan value and warranty expiry earlier than purchase date
- Row `122`: invalid lifespan value and warranty expiry earlier than purchase date
- Row `128`: duplicate `tracking_code` `DT/MFM/083`
- Row `128`: duplicate `asset_tag` `DT/MFM/083`
- Row `217`: duplicate `serial_no` `'CNC748NSDY`
- Row `240`: duplicate `serial_no` `'FYDD91A014506`
- Row `246`: duplicate `serial_no` `'TX7143902151`
- Row `263`: duplicate `serial_no` `'CN71A3H207`

That result is expected from the current workbook contents; the app is correctly surfacing source-data issues rather than silently importing them.

## Backup And Restore

Backup and restore are `super_admin` only.

### Manual Backup

1. Log in as `super_admin`.
2. Open `/backups`.
3. Select `Create Manual Backup`.

The bundle is stored under `var/backups/` and includes:

- a live SQLite snapshot
- the manifest with schema/hash metadata
- attachment files referenced by the snapshot
- stored import source files referenced by the snapshot

### Nightly Backup

Run:

```powershell
python manage.py nightly_backup
```

Nightly backups are retained for `14` days by default.

### Restore

1. Log in as `super_admin`.
2. Open `/settings`.
3. Enable maintenance mode and save.
4. Open `/backups`.
5. Select `Restore` on the target bundle.

Restore behavior:

- maintenance mode is required before restore
- a pre-restore safety backup is created automatically
- the archive hash, manifest, schema version, SQLite integrity, and restored media are validated
- the app disables maintenance mode automatically only after a successful restore

If restore fails, the app rolls database and media back to the pre-restore state and leaves maintenance mode under operator control.

## Verification Commands

Minimum verification:

```powershell
python manage.py check
python manage.py test -v 2
```

Useful targeted checks:

```powershell
python manage.py test inventory.tests.test_imports.ImportWorkflowTests.test_real_workbook_dry_run_uses_actual_header_row_and_reports_duplicates -v 2
python manage.py test inventory.tests.test_backups.BackupWorkflowTests.test_backup_and_restore_include_import_source_files -v 2
```

## Operational Constraints

- SQLite and `db.sqlite3` must stay on the same local server disk as the running app.
- Do not place the SQLite database on a network share or network-mounted filesystem.
- Do not run multiple application servers against the same SQLite file.
- Uploaded files remain on the local filesystem under `media/`; restore assumes local filesystem access to that tree.
- Backups are ZIP archives for recovery, not report exports.
- `media/` should stay outside the public web root; access is enforced through authenticated app routes.

## Remaining Gaps

- No browser automation suite was added; final verification is through Django checks, Django test client coverage, and the real workbook dry-run path.
- There is still no sanitized copy of `Asset_Search_listing_latest.xlsx`; operators must correct the source workbook issues above before a full commit of that file will succeed.
