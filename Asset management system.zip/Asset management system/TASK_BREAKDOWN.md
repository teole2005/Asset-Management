# Task Breakdown

Project: Asset Management System
Derived from: `c:\Users\zhengyu\Downloads\Asset_Management_System.md`
Purpose: This file defines the numbered implementation tasks. Task numbers are defined here, not implied by the main spec.

## How To Use This File

- Each new chat must read this file before starting work.
- Only work on the next incomplete task unless `TASK_STATUS.md` explicitly says otherwise.
- If code for a later task already exists partially, do not mark that task complete until its acceptance criteria are verified.
- If an earlier task must be reopened, record the reason in `TASK_STATUS.md` first.

## Task Order

### Task 1: Project Foundation And Baseline Architecture

- Status: `Complete`
- Goal:
  - Establish the Django project, initial schema, core service modules, route structure, templates, permissions, SQLite startup hardening, and baseline tests.
- Acceptance criteria:
  - Django project scaffold exists and runs.
  - Core models and migrations exist.
  - SQLite foreign keys and WAL are enforced.
  - Main route skeleton exists.
  - Baseline test suite runs successfully.

### Task 2: Controlled Import Workflow And Source Data Migration

- Status: `Complete`
- Goal:
  - Finish and verify the controlled CSV/XLSX import flow, with special focus on the primary migration source `Asset_Search_listing_latest.xlsx`.
- Acceptance criteria:
  - Import upload accepts CSV/XLSX and detects headers correctly.
  - Column mapping is editable and persists per batch.
  - Dry-run validation reports missing required fields, invalid dates/prices, and duplicate `tracking_code`, `asset_tag`, and `serial_no`.
  - Commit runs as one transaction and rolls back the whole batch on failure.
  - Legacy `Occupied` imports as `Assigned`.
  - `asset_tag` defaults to `tracking_code` when missing.
  - Source spreadsheet migration path is verified against real workbook data.
  - Tests cover dry-run failures, duplicate handling, and full-batch rollback behavior.
- Primary files likely involved:
  - `inventory/imports.py`
  - `inventory/views.py`
  - `templates/inventory/imports.html`
  - `templates/inventory/import_detail.html`
  - `inventory/tests/test_imports.py`

### Task 3: Asset Lifecycle Workflows And Admin CRUD Completion

- Status: `Complete`
- Goal:
  - Finish and verify the day-to-day admin workflows for asset operations.
- Acceptance criteria:
  - Asset CRUD is complete and stable.
  - Staff, departments, locations, and vendors can be managed through the app.
  - Assignment create/return workflow is complete and enforced.
  - Repair open/close workflow is complete and enforced.
  - Sale/disposal workflow enforces lifecycle rules and logs suggested vs final price.
  - Physical audits support `found/missing`, verified location/condition, and follow-up actions.
  - Attachment upload/download/delete flow is complete and authorized.
  - Derived fields display correctly from source data and history.
- Primary files likely involved:
  - `inventory/views.py`
  - `inventory/forms.py`
  - `inventory/services.py`
  - `templates/inventory/*.html`
  - `inventory/tests/test_integrity.py`

### Task 4: Export, Backup, Restore, And Maintenance Operations

- Status: `Complete`
- Goal:
  - Finish and verify the operational workflows for exports and disaster recovery.
- Acceptance criteria:
  - CSV/XLSX export works for assets, assignments, repairs, sales/disposals, audits, and audit/activity views.
  - Export respects current filters/search where required.
  - Security/auth audit export is limited to `super_admin`.
  - Manual backup works from the UI.
  - Nightly backup command is functional.
  - Restore requires maintenance mode, creates a pre-restore safety backup, validates manifest/hash/schema, and restores DB plus media together.
  - Restore runs integrity checks before returning the app to service.
  - Tests cover backup creation and restore validation paths.
- Primary files likely involved:
  - `inventory/exports.py`
  - `inventory/backups.py`
  - `inventory/views.py`
  - `templates/inventory/backups.html`
  - `inventory/management/commands/nightly_backup.py`

### Task 5: Security Hardening, Authorization Boundaries, And Admin Governance

- Status: `Complete`
- Goal:
  - Complete the security-sensitive behaviors required by the spec.
- Acceptance criteria:
  - `admin` and `super_admin` boundaries are fully enforced on routes and actions.
  - Deny-by-default behavior is verified for all admin routes.
  - Login/logout, failed login logging, and throttling are fully verified.
  - Session rotation occurs on login and privilege changes.
  - CSRF enforcement is verified for state-changing requests.
  - File access is authorized for upload/download/delete paths.
  - `super_admin`-only capabilities remain restricted, including restore, system settings, security logs, and admin-user management.
  - Audit logging covers permission-denied attempts and security events.
- Primary files likely involved:
  - `inventory/middleware.py`
  - `inventory/permissions.py`
  - `inventory/signals.py`
  - `inventory/views.py`
  - `inventory/tests/test_security.py`

### Task 6: Dashboard, Alerts, And Operational Reporting Polish

- Status: `Complete`
- Goal:
  - Complete the dashboard and notification features expected for v1 operations.
- Acceptance criteria:
  - Dashboard shows totals by status, due-for-replacement, due-for-audit, warranty due soon, open repairs, missing invoices, and recent changes.
  - `Never audited` is shown separately from `audit due`.
  - Daily email reminder command uses configured recipients and includes due-soon and overdue summaries.
  - Settings page cleanly manages maintenance mode and alert recipients.
  - UI output is coherent for normal admin use.
- Primary files likely involved:
  - `inventory/views.py`
  - `inventory/management/commands/send_daily_alerts.py`
  - `templates/inventory/dashboard.html`
  - `templates/inventory/settings.html`

### Task 7: Final Verification, Sample Data Load, And Handoff Readiness

- Status: `Complete`
- Goal:
  - Finish the project with full verification and a clean operational handoff.
- Acceptance criteria:
  - End-to-end verification is run against the completed implementation.
  - The primary workbook import is exercised on realistic data.
  - Remaining test gaps are closed or explicitly documented.
  - Run instructions, backup/restore usage, and task handoff notes are current.
  - `TASK_STATUS.md` reflects the final verified state.
- Primary files likely involved:
  - `TASK_STATUS.md`
  - test files under `inventory/tests/`
  - optional docs added to the repo as needed

## Current Next Task

- All defined tasks are complete. There is no next task in the current breakdown.
