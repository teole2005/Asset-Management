from pathlib import Path

from django import forms
from django.core.validators import validate_email
from django.contrib.auth import password_validation
from django.contrib.auth.forms import AuthenticationForm
from django.utils import timezone

from .permissions import ADMIN_ROLE, SUPER_ADMIN_ROLE
from .models import (
    Asset,
    AssetStatus,
    Assignment,
    Department,
    ImportBatch,
    Location,
    PhysicalAudit,
    PhysicalAuditResult,
    RepairLog,
    SaleDisposal,
    StaffMember,
    Vendor,
)


class BaseFormMixin:
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for field in self.fields.values():
            css = field.widget.attrs.get("class", "")
            if isinstance(field.widget, forms.CheckboxInput):
                field.widget.attrs["class"] = f"{css} form-check-input".strip()
                continue
            field.widget.attrs["class"] = f"{css} form-control".strip()


class LoginForm(BaseFormMixin, AuthenticationForm):
    username = forms.CharField(widget=forms.TextInput(attrs={"autofocus": True}))


class AssetForm(BaseFormMixin, forms.ModelForm):
    class Meta:
        model = Asset
        fields = [
            "legacy_no",
            "type",
            "owner",
            "tracking_code",
            "asset_tag",
            "brand",
            "model",
            "serial_no",
            "price",
            "purchase_date",
            "estimate_lifespan_months",
            "start_date",
            "warranty_expiry_date",
            "vendor",
            "invoice_no",
            "condition",
            "status",
            "current_location",
            "department",
            "custodian_it_owner",
            "specs_json",
        ]
        widgets = {
            "purchase_date": forms.DateInput(attrs={"type": "date"}),
            "start_date": forms.DateInput(attrs={"type": "date"}),
            "warranty_expiry_date": forms.DateInput(attrs={"type": "date"}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["status"].choices = [
            (AssetStatus.AVAILABLE, AssetStatus.AVAILABLE),
            (AssetStatus.RETIRED, AssetStatus.RETIRED),
        ]
        if self.instance and self.instance.pk and self.instance.status in {AssetStatus.SOLD, AssetStatus.DISPOSED}:
            self.fields["status"].disabled = True


class AssignmentForm(BaseFormMixin, forms.ModelForm):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["staff_member"].queryset = StaffMember.objects.filter(is_active=True)

    class Meta:
        model = Assignment
        fields = ["staff_member", "assigned_at", "notes"]
        widgets = {
            "assigned_at": forms.DateInput(attrs={"type": "date"}),
            "notes": forms.Textarea(attrs={"rows": 3}),
        }


class ReturnAssignmentForm(BaseFormMixin, forms.Form):
    returned_at = forms.DateField(
        initial=timezone.localdate,
        widget=forms.DateInput(attrs={"type": "date"}),
    )


class RepairLogForm(BaseFormMixin, forms.ModelForm):
    class Meta:
        model = RepairLog
        fields = ["issue", "vendor", "opened_at", "cost", "resolution_notes"]
        widgets = {
            "opened_at": forms.DateInput(attrs={"type": "date"}),
            "issue": forms.Textarea(attrs={"rows": 3}),
            "resolution_notes": forms.Textarea(attrs={"rows": 3}),
        }


class RepairCloseForm(BaseFormMixin, forms.Form):
    closed_at = forms.DateField(
        initial=timezone.localdate,
        widget=forms.DateInput(attrs={"type": "date"}),
    )
    resolution_notes = forms.CharField(widget=forms.Textarea(attrs={"rows": 3}), required=False)


class SaleDisposalForm(BaseFormMixin, forms.ModelForm):
    def clean(self):
        cleaned_data = super().clean()
        if cleaned_data.get("final_price") in (None, "") and self.suggested_price is not None:
            cleaned_data["final_price"] = self.suggested_price
            self.instance.final_price = self.suggested_price
        return cleaned_data

    class Meta:
        model = SaleDisposal
        fields = ["action", "recorded_at", "final_price", "notes"]
        widgets = {
            "recorded_at": forms.DateInput(attrs={"type": "date"}),
            "notes": forms.Textarea(attrs={"rows": 3}),
        }

    def __init__(self, *args, **kwargs):
        suggested_price = kwargs.pop("suggested_price", None)
        super().__init__(*args, **kwargs)
        self.suggested_price = suggested_price
        self.fields["final_price"].required = False
        if suggested_price is not None:
            self.fields["final_price"].help_text = f"Suggested straight-line price: RM {suggested_price}"
            self.fields["final_price"].initial = suggested_price


class AttachmentForm(BaseFormMixin, forms.Form):
    file = forms.FileField()
    description = forms.CharField(required=False, max_length=255)


class PhysicalAuditForm(BaseFormMixin, forms.ModelForm):
    def clean(self):
        cleaned_data = super().clean()
        result = cleaned_data.get("result")
        follow_up_action = (cleaned_data.get("follow_up_action") or "").strip()
        if result == PhysicalAuditResult.MISSING and not follow_up_action:
            self.add_error("follow_up_action", "Follow-up action is required when an asset is marked missing.")
        return cleaned_data

    class Meta:
        model = PhysicalAudit
        fields = [
            "asset",
            "result",
            "verified_location",
            "verified_condition",
            "audited_at",
            "follow_up_action",
        ]
        widgets = {
            "audited_at": forms.DateTimeInput(attrs={"type": "datetime-local"}),
            "follow_up_action": forms.Textarea(attrs={"rows": 3}),
        }


class StaffMemberForm(BaseFormMixin, forms.ModelForm):
    class Meta:
        model = StaffMember
        fields = ["name", "email", "employee_id", "department", "location", "is_active"]


class DepartmentForm(BaseFormMixin, forms.ModelForm):
    class Meta:
        model = Department
        fields = ["name", "code"]


class LocationForm(BaseFormMixin, forms.ModelForm):
    class Meta:
        model = Location
        fields = ["name", "description"]


class VendorForm(BaseFormMixin, forms.ModelForm):
    class Meta:
        model = Vendor
        fields = ["name", "email", "phone", "notes"]
        widgets = {"notes": forms.Textarea(attrs={"rows": 3})}


class ImportUploadForm(BaseFormMixin, forms.ModelForm):
    class Meta:
        model = ImportBatch
        fields = ["source_file"]

    def clean_source_file(self):
        source_file = self.cleaned_data["source_file"]
        if Path(source_file.name).suffix.lower() not in {".csv", ".xlsx"}:
            raise forms.ValidationError("Only CSV and XLSX files are supported.")
        return source_file


class SettingsForm(BaseFormMixin, forms.Form):
    maintenance_mode = forms.BooleanField(required=False)
    alert_recipients = forms.CharField(
        required=False,
        help_text="Comma-separated email recipients for daily reminders.",
        widget=forms.Textarea(attrs={"rows": 3}),
    )

    def clean_alert_recipients(self):
        raw_value = self.cleaned_data.get("alert_recipients", "")
        recipients = []
        seen = set()
        invalid = []

        for token in raw_value.replace(";", ",").replace("\n", ",").split(","):
            email = token.strip()
            if not email or email in seen:
                continue
            try:
                validate_email(email)
            except forms.ValidationError:
                invalid.append(email)
                continue
            recipients.append(email)
            seen.add(email)

        if invalid:
            raise forms.ValidationError(
                f"Enter valid email addresses only. Invalid: {', '.join(invalid)}"
            )
        return ", ".join(recipients)


class AdminUserCreateForm(BaseFormMixin, forms.Form):
    username = forms.CharField(max_length=150)
    email = forms.EmailField(required=False)
    password = forms.CharField(widget=forms.PasswordInput())
    role = forms.ChoiceField(
        choices=[
            (ADMIN_ROLE, "Admin"),
            (SUPER_ADMIN_ROLE, "Super Admin"),
        ]
    )

    def __init__(self, *args, user_model=None, **kwargs):
        self.user_model = user_model
        super().__init__(*args, **kwargs)

    def clean_username(self):
        username = self.cleaned_data["username"].strip()
        if self.user_model and self.user_model.objects.filter(username=username).exists():
            raise forms.ValidationError("A user with that username already exists.")
        return username

    def clean_password(self):
        password = self.cleaned_data["password"]
        if self.user_model is not None:
            temp_user = self.user_model(username=self.cleaned_data.get("username", ""))
            password_validation.validate_password(password, temp_user)
        return password
