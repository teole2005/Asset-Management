from django.core.checks import Error, Tags, register
from django.db import connections


SQLITE_WAL_ERROR = "inventory.E001"
SQLITE_FOREIGN_KEY_ERROR = "inventory.E002"


def _pragma_value(alias, pragma_name):
    connection = connections[alias]
    with connection.cursor() as cursor:
        cursor.execute(f"PRAGMA {pragma_name};")
        row = cursor.fetchone()
    return row[0] if row else None


@register(Tags.database)
def sqlite_runtime_health(app_configs, **kwargs):
    errors = []
    connection = connections["default"]
    if connection.vendor != "sqlite":
        return errors

    try:
        connection.ensure_connection()
        foreign_keys = _pragma_value("default", "foreign_keys")
        journal_mode = str(_pragma_value("default", "journal_mode")).lower()
    except Exception as exc:  # pragma: no cover
        return [
            Error(
                "SQLite startup health check failed.",
                hint=str(exc),
                id=SQLITE_WAL_ERROR,
            )
        ]

    if foreign_keys != 1:
        errors.append(
            Error(
                "SQLite foreign key enforcement is not active.",
                hint="The app requires PRAGMA foreign_keys=ON on every connection.",
                id=SQLITE_FOREIGN_KEY_ERROR,
            )
        )
    if journal_mode != "wal":
        errors.append(
            Error(
                "SQLite WAL mode is not active.",
                hint="The app requires PRAGMA journal_mode=WAL.",
                id=SQLITE_WAL_ERROR,
            )
        )
    return errors
