from django.conf import settings
from django.core.exceptions import PermissionDenied
from django.shortcuts import redirect, render
from django.urls import Resolver404, resolve, reverse

from .permissions import (
    ADMIN_ROLE,
    SUPER_ADMIN_ROLE,
    has_admin_access,
    has_super_admin_access,
    required_role_for_url_name,
)
from .services import ensure_runtime_security_state, get_setting, log_event


class StartupHealthCheckMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response
        self.checked = False

    def __call__(self, request):
        if not self.checked:
            self.checked = True
            ensure_runtime_security_state()
        return self.get_response(request)


class SessionSecurityMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        if request.user.is_authenticated:
            profile = getattr(request.user, "security_profile", None)
            if profile:
                version = profile.permissions_version.isoformat()
                stored_version = request.session.get("permissions_version")
                if stored_version and stored_version != version:
                    request.session.cycle_key()
                    log_event(
                        "session_rotated_permission_change",
                        actor=request.user,
                        request=request,
                        success=True,
                    )
                request.session["permissions_version"] = version
        return self.get_response(request)


class MaintenanceModeMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        if not get_setting("maintenance_mode", False):
            return self.get_response(request)

        exempt_prefixes = {
            reverse("login"),
            reverse("logout"),
            "/django-admin/",
            settings.STATIC_URL,
        }
        if any(request.path.startswith(prefix) for prefix in exempt_prefixes):
            return self.get_response(request)
        if request.user.is_authenticated and has_super_admin_access(request.user):
            return self.get_response(request)
        return render(request, "inventory/maintenance.html", status=503)


class EnforceLoginMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        exempt_paths = {
            reverse("login"),
            reverse("logout"),
        }
        if (
            request.user.is_authenticated
            or request.path in exempt_paths
            or request.path.startswith("/django-admin/")
            or request.path.startswith(settings.STATIC_URL)
        ):
            return self.get_response(request)

        return redirect(f"{reverse('login')}?next={request.path}")


class PermissionDeniedAuditMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        try:
            return self.get_response(request)
        except PermissionDenied:
            if getattr(request, "permission_denied_logged", False):
                raise
            metadata = {
                "path": request.path,
                "method": request.method,
            }
            metadata.update(getattr(request, "audit_denial_metadata", {}))
            log_event(
                "permission_denied",
                actor=request.user if request.user.is_authenticated else None,
                request=request,
                success=False,
                metadata=metadata,
            )
            raise


class RouteAuthorizationMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        if (
            not request.user.is_authenticated
            or request.path.startswith("/django-admin/")
            or request.path.startswith(settings.STATIC_URL)
        ):
            return self.get_response(request)

        try:
            match = resolve(request.path_info)
        except Resolver404:
            return self.get_response(request)

        required_role = required_role_for_url_name(match.url_name)
        if not required_role:
            return self.get_response(request)

        request.audit_denial_metadata = {
            "url_name": match.url_name,
            "required_role": required_role,
        }
        if required_role == SUPER_ADMIN_ROLE and not has_super_admin_access(request.user):
            log_event(
                "permission_denied",
                actor=request.user,
                request=request,
                success=False,
                metadata={**request.audit_denial_metadata, "path": request.path, "method": request.method},
            )
            request.permission_denied_logged = True
            raise PermissionDenied("Super-admin access required.")
        if required_role == ADMIN_ROLE and not has_admin_access(request.user):
            log_event(
                "permission_denied",
                actor=request.user,
                request=request,
                success=False,
                metadata={**request.audit_denial_metadata, "path": request.path, "method": request.method},
            )
            request.permission_denied_logged = True
            raise PermissionDenied("Admin access required.")
        return self.get_response(request)
