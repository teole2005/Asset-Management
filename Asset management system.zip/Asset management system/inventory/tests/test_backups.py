import base64
import json
import tempfile
import zipfile
from datetime import date, timedelta
from decimal import Decimal
from pathlib import Path

from django.contrib.auth import get_user_model
from django.contrib.auth.models import Group
from django.core.exceptions import ValidationError
from django.core.files.uploadedfile import SimpleUploadedFile
from django.core.management import call_command
from django.test import TransactionTestCase, override_settings
from django.urls import reverse

from inventory.backups import create_backup_bundle, restore_backup_bundle
from inventory.imports import create_batch_from_upload
from inventory.models import Asset, AssetType, Attachment, BackupBundle, BackupBundleKind, Department, ImportBatch, Location
from inventory.services import create_attachment, set_setting
from inventory.utils import hash_file


User = get_user_model()
PNG_1X1 = base64.b64decode(
    "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO4B8t8AAAAASUVORK5CYII="
)


class BackupWorkflowTests(TransactionTestCase):
    reset_sequences = True

    def setUp(self):
        super().setUp()
        self.media_dir = tempfile.TemporaryDirectory()
        self.backup_dir = tempfile.TemporaryDirectory()
        self.settings_override = override_settings(
            MEDIA_ROOT=Path(self.media_dir.name),
            BACKUP_ROOT=Path(self.backup_dir.name),
        )
        self.settings_override.enable()
        self.addCleanup(self.settings_override.disable)
        self.addCleanup(self.media_dir.cleanup)
        self.addCleanup(self.backup_dir.cleanup)

        self.super_group = Group.objects.get(name="super_admin")
        self.super_user = User.objects.create_user(username="backup-super", password="test-password-123")
        self.super_user.groups.add(self.super_group)
        self.asset_type = AssetType.objects.create(name="Laptop")
        self.department = Department.objects.create(name="IT")
        self.location = Location.objects.create(name="HQ")
        self.client.force_login(self.super_user)
        set_setting("maintenance_mode", False)

    def create_asset(self, tracking_code="TRK-BKP", asset_tag="TAG-BKP", serial_no="SER-BKP", brand="Dell"):
        return Asset.objects.create(
            type=self.asset_type,
            tracking_code=tracking_code,
            asset_tag=asset_tag,
            brand=brand,
            model="Latitude",
            serial_no=serial_no,
            price=Decimal("2500.00"),
            purchase_date=date.today() - timedelta(days=180),
            estimate_lifespan_months=48,
            department=self.department,
            current_location=self.location,
            created_by=self.super_user,
            updated_by=self.super_user,
        )

    def create_attachment_for_asset(self, asset, filename="invoice.png"):
        upload = SimpleUploadedFile(filename, PNG_1X1, content_type="image/png")
        return create_attachment(asset, upload, "Invoice", self.super_user)

    def create_import_batch(self, filename="assets.csv"):
        csv_text = "\n".join(
            [
                "Type,Tracking Code,Brand,Model,Serial No.,Price,Purchase Date,Estimate Lifespan,Assignment Status",
                "Laptop,TRK-IMP,Dell,Latitude,SER-IMP,3200,2026-01-01,60 month,Available",
            ]
        )
        upload = SimpleUploadedFile(filename, csv_text.encode("utf-8"), content_type="text/csv")
        return create_batch_from_upload(upload, actor=self.super_user)

    def rewrite_bundle_manifest(self, bundle, manifest):
        archive_path = Path(bundle.archive_path)
        temp_archive_path = archive_path.with_suffix(".tmp.zip")
        with zipfile.ZipFile(archive_path, "r") as source_archive:
            with zipfile.ZipFile(temp_archive_path, "w", zipfile.ZIP_DEFLATED) as target_archive:
                for info in source_archive.infolist():
                    if info.filename == "manifest.json":
                        target_archive.writestr("manifest.json", json.dumps(manifest, indent=2))
                    else:
                        target_archive.writestr(info, source_archive.read(info.filename))
        temp_archive_path.replace(archive_path)
        bundle.manifest = manifest
        bundle.sha256 = hash_file(archive_path)
        bundle.size_bytes = archive_path.stat().st_size
        bundle.save(update_fields=["manifest", "sha256", "size_bytes"])

    def test_manual_backup_from_ui_creates_bundle_with_snapshot_and_media(self):
        asset = self.create_asset()
        attachment = self.create_attachment_for_asset(asset)

        response = self.client.post(reverse("backups"))
        self.assertEqual(response.status_code, 302)

        bundle = BackupBundle.objects.get(kind=BackupBundleKind.MANUAL)
        self.assertTrue(Path(bundle.archive_path).exists())

        with zipfile.ZipFile(bundle.archive_path, "r") as archive:
            names = archive.namelist()
            self.assertIn("snapshot.sqlite3", names)
            self.assertIn("manifest.json", names)
            self.assertIn(f"media/{attachment.file.name}", names)
            manifest = json.loads(archive.read("manifest.json").decode("utf-8"))

        media_paths = [entry["path"] for entry in manifest["media"]]
        self.assertIn(attachment.file.name, media_paths)
        self.assertEqual(manifest["kind"], BackupBundleKind.MANUAL)

    def test_nightly_backup_command_creates_bundle(self):
        self.create_asset(tracking_code="TRK-NIGHT", asset_tag="TAG-NIGHT", serial_no="SER-NIGHT")

        call_command("nightly_backup")

        bundle = BackupBundle.objects.get(kind=BackupBundleKind.NIGHTLY)
        self.assertTrue(Path(bundle.archive_path).exists())

    def test_backup_and_restore_include_import_source_files(self):
        batch = self.create_import_batch()
        original_source_name = batch.source_file.name
        original_source_bytes = Path(batch.source_file.path).read_bytes()
        bundle = create_backup_bundle(BackupBundleKind.MANUAL, actor=self.super_user)

        with zipfile.ZipFile(bundle.archive_path, "r") as archive:
            archive_names = archive.namelist()
            self.assertIn(f"media/{original_source_name}", archive_names)
            manifest = json.loads(archive.read("manifest.json").decode("utf-8"))

        media_paths = [entry["path"] for entry in manifest["media"]]
        self.assertIn(original_source_name, media_paths)

        batch.source_file.delete(save=False)
        batch.delete()
        self.assertFalse(ImportBatch.objects.filter(batch_id=batch.batch_id).exists())
        set_setting("maintenance_mode", True)

        restore_backup_bundle(bundle, actor=self.super_user)

        restored_batch = ImportBatch.objects.get(batch_id=batch.batch_id)
        restored_source_path = Path(restored_batch.source_file.path)
        self.assertEqual(restored_batch.source_file.name, original_source_name)
        self.assertTrue(restored_source_path.exists())
        self.assertEqual(restored_source_path.read_bytes(), original_source_bytes)

    def test_restore_requires_maintenance_mode(self):
        bundle = create_backup_bundle(BackupBundleKind.MANUAL, actor=self.super_user)

        with self.assertRaisesMessage(ValidationError, "Enable maintenance mode before restoring a backup."):
            restore_backup_bundle(bundle, actor=self.super_user)

        self.assertEqual(BackupBundle.objects.filter(kind=BackupBundleKind.PRE_RESTORE).count(), 0)

    def test_restore_rejects_archive_hash_mismatch_after_creating_safety_backup(self):
        bundle = create_backup_bundle(BackupBundleKind.MANUAL, actor=self.super_user)
        bundle.sha256 = "0" * 64
        bundle.save(update_fields=["sha256"])
        set_setting("maintenance_mode", True)

        with self.assertRaisesMessage(ValidationError, "archive hash"):
            restore_backup_bundle(bundle, actor=self.super_user)

        self.assertEqual(BackupBundle.objects.filter(kind=BackupBundleKind.PRE_RESTORE).count(), 1)

    def test_restore_rejects_schema_mismatch(self):
        bundle = create_backup_bundle(BackupBundleKind.MANUAL, actor=self.super_user)
        tampered_manifest = dict(bundle.manifest)
        tampered_manifest["schema_version"] = [["inventory", "9999_invalid_schema"]]
        self.rewrite_bundle_manifest(bundle, tampered_manifest)
        set_setting("maintenance_mode", True)

        with self.assertRaisesMessage(ValidationError, "schema version"):
            restore_backup_bundle(bundle, actor=self.super_user)

        self.assertEqual(BackupBundle.objects.filter(kind=BackupBundleKind.PRE_RESTORE).count(), 1)

    def test_restore_restores_database_media_and_bundle_catalog(self):
        asset = self.create_asset(brand="Dell")
        attachment = self.create_attachment_for_asset(asset)
        bundle = create_backup_bundle(BackupBundleKind.MANUAL, actor=self.super_user)
        original_attachment_hash = attachment.sha256
        original_attachment_name = attachment.file.name
        original_attachment_pk = attachment.pk

        asset.brand = "HP"
        asset.save(update_fields=["brand"])
        self.create_asset(tracking_code="TRK-LATER", asset_tag="TAG-LATER", serial_no="SER-LATER", brand="Lenovo")
        attachment.file.delete(save=False)
        attachment.delete()
        set_setting("maintenance_mode", True)

        restored_bundle = restore_backup_bundle(bundle, actor=self.super_user)

        restored_asset = Asset.objects.get(pk=asset.pk)
        restored_attachment = Attachment.objects.get(pk=original_attachment_pk)
        self.assertEqual(restored_asset.brand, "Dell")
        self.assertFalse(Asset.objects.filter(tracking_code="TRK-LATER").exists())
        self.assertEqual(restored_attachment.file.name, original_attachment_name)
        self.assertEqual(restored_attachment.sha256, original_attachment_hash)
        self.assertTrue(Path(restored_attachment.file.path).exists())
        self.assertTrue(BackupBundle.objects.filter(bundle_id=bundle.bundle_id).exists())
        self.assertTrue(BackupBundle.objects.filter(kind=BackupBundleKind.PRE_RESTORE).exists())
        self.assertTrue(BackupBundle.objects.filter(pk=restored_bundle.pk).exists())
