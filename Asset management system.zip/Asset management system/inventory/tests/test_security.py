import base64
import tempfile
from datetime import date, timedelta
from decimal import Decimal
from pathlib import Path

from django.contrib.auth import get_user_model
from django.contrib.auth.models import Group
from django.core.exceptions import PermissionDenied
from django.core.files.uploadedfile import SimpleUploadedFile
from django.test import Client, TestCase, override_settings
from django.urls import reverse

from inventory.backups import create_backup_bundle
from inventory.models import Asset, AssetCondition, AssetType, Attachment, AuditEvent, BackupBundleKind, Department, Location, StaffMember
from inventory.permissions import ADMIN_URL_NAMES, SUPER_ADMIN_URL_NAMES
from inventory.services import create_assignment, create_attachment, set_setting


User = get_user_model()
PNG_1X1 = base64.b64decode(
    "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO4B8t8AAAAASUVORK5CYII="
)


@override_settings(ANTIVIRUS_COMMAND="")
class SecurityTests(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.admin_group = Group.objects.get(name="admin")
        cls.super_group = Group.objects.get(name="super_admin")
        cls.admin_user = User.objects.create_user(username="admin-user", password="test-password-123")
        cls.admin_user.groups.add(cls.admin_group)
        cls.super_user = User.objects.create_user(username="super-user", password="test-password-123")
        cls.super_user.groups.add(cls.super_group)
        cls.regular_user = User.objects.create_user(username="regular-user", password="test-password-123")
        cls.asset_type = AssetType.objects.create(name="Laptop")
        cls.department = Department.objects.create(name="IT")
        cls.location = Location.objects.create(name="HQ")
        cls.staff_member = StaffMember.objects.create(
            name="Security Staff",
            email="security.staff@example.com",
            department=cls.department,
            location=cls.location,
        )

    def setUp(self):
        self.media_dir = tempfile.TemporaryDirectory(ignore_cleanup_errors=True)
        self.backup_dir = tempfile.TemporaryDirectory(ignore_cleanup_errors=True)
        self.settings_override = override_settings(
            MEDIA_ROOT=Path(self.media_dir.name),
            BACKUP_ROOT=Path(self.backup_dir.name),
        )
        self.settings_override.enable()
        self.addCleanup(self.settings_override.disable)
        self.addCleanup(self.media_dir.cleanup)
        self.addCleanup(self.backup_dir.cleanup)
        set_setting("maintenance_mode", False)

    def create_asset(self, **overrides):
        defaults = {
            "type": self.asset_type,
            "tracking_code": f"TRK-{Asset.objects.count() + 1}",
            "asset_tag": f"TAG-{Asset.objects.count() + 1}",
            "brand": "Dell",
            "model": "Latitude",
            "serial_no": f"SER-{Asset.objects.count() + 1}",
            "price": Decimal("2500.00"),
            "purchase_date": date.today() - timedelta(days=30),
            "estimate_lifespan_months": 48,
            "condition": AssetCondition.GOOD,
            "department": self.department,
            "current_location": self.location,
            "created_by": self.admin_user,
            "updated_by": self.admin_user,
        }
        defaults.update(overrides)
        return Asset.objects.create(**defaults)

    def create_upload(self, filename="invoice.png"):
        return SimpleUploadedFile(filename, PNG_1X1, content_type="image/png")

    def admin_route_specs(self):
        route_specs = {
            "dashboard": ("get", reverse("dashboard"), None),
            "asset-list": ("get", reverse("asset-list"), None),
            "asset-create": ("get", reverse("asset-create"), None),
            "asset-detail": ("get", reverse("asset-detail", args=[999]), None),
            "asset-edit": ("get", reverse("asset-edit", args=[999]), None),
            "asset-assign": ("get", reverse("asset-assign", args=[999]), None),
            "assignment-return": ("post", reverse("assignment-return", args=[999]), {}),
            "asset-repair": ("get", reverse("asset-repair", args=[999]), None),
            "repair-close": ("post", reverse("repair-close", args=[999]), {}),
            "asset-sell": ("get", reverse("asset-sell", args=[999]), None),
            "attachment-download": ("get", reverse("attachment-download", args=[999]), None),
            "attachment-delete": ("post", reverse("attachment-delete", args=[999]), {}),
            "audits": ("get", reverse("audits"), None),
            "imports": ("get", reverse("imports"), None),
            "import-detail": ("get", reverse("import-detail", args=[999]), None),
            "exports": ("get", reverse("exports"), None),
            "staff": ("get", reverse("staff"), None),
            "departments": ("get", reverse("departments"), None),
            "vendors": ("get", reverse("vendors"), None),
            "backups": ("get", reverse("backups"), None),
            "backup-download": ("get", reverse("backup-download", args=[999]), None),
            "backup-restore": ("post", reverse("backup-restore", args=[999]), {}),
            "admin-users": ("get", reverse("admin-users"), None),
            "settings": ("get", reverse("settings"), None),
            "audit-log": ("get", reverse("audit-log"), None),
        }
        self.assertEqual(set(route_specs), ADMIN_URL_NAMES | SUPER_ADMIN_URL_NAMES)
        return route_specs

    def perform_request(self, client, method, path, data=None):
        request_fn = getattr(client, method)
        if data is None:
            return request_fn(path)
        return request_fn(path, data)

    def test_non_admins_are_denied_by_default_for_all_admin_routes(self):
        anonymous_client = Client()
        for route_name, (method, path, data) in self.admin_route_specs().items():
            response = self.perform_request(anonymous_client, method, path, data)
            self.assertEqual(response.status_code, 302, route_name)
            self.assertTrue(response.url.startswith(f"{reverse('login')}?next="), route_name)

        regular_client = Client()
        regular_client.force_login(self.regular_user)
        for route_name, (method, path, data) in self.admin_route_specs().items():
            response = self.perform_request(regular_client, method, path, data)
            self.assertEqual(response.status_code, 403, route_name)

        denied_events = AuditEvent.objects.filter(event_type="permission_denied", actor=self.regular_user)
        self.assertEqual(denied_events.count(), len(self.admin_route_specs()))

    def test_admin_cannot_access_super_admin_routes(self):
        bundle = create_backup_bundle(BackupBundleKind.MANUAL, actor=self.super_user)
        client = Client()
        client.force_login(self.admin_user)

        self.assertEqual(client.get(reverse("settings")).status_code, 403)
        self.assertEqual(client.get(reverse("backups")).status_code, 403)
        self.assertEqual(client.get(reverse("audit-log")).status_code, 403)
        self.assertEqual(client.get(reverse("admin-users")).status_code, 403)
        self.assertEqual(client.get(reverse("backup-download", args=[bundle.pk])).status_code, 403)
        self.assertEqual(client.post(reverse("backup-restore", args=[bundle.pk]), {}).status_code, 403)

    def test_super_admin_can_access_security_routes_and_backup_actions(self):
        bundle = create_backup_bundle(BackupBundleKind.MANUAL, actor=self.super_user)
        client = Client()
        client.force_login(self.super_user)

        self.assertEqual(client.get(reverse("settings")).status_code, 200)
        self.assertEqual(client.get(reverse("backups")).status_code, 200)
        self.assertEqual(client.get(reverse("audit-log")).status_code, 200)
        self.assertEqual(client.get(reverse("admin-users")).status_code, 200)

        restore_response = client.post(reverse("backup-restore", args=[bundle.pk]), {})
        self.assertEqual(restore_response.status_code, 302)

    def test_login_logout_audit_and_session_rotation(self):
        client = Client(enforce_csrf_checks=True)
        session = client.session
        session["prelogin"] = True
        session.save()
        initial_session_key = session.session_key

        client.get(reverse("login"))
        csrf_token = client.cookies["csrftoken"].value
        login_response = client.post(
            reverse("login"),
            {
                "username": self.admin_user.username,
                "password": "test-password-123",
                "csrfmiddlewaretoken": csrf_token,
            },
        )
        self.assertEqual(login_response.status_code, 302)
        self.assertNotEqual(client.session.session_key, initial_session_key)
        self.assertTrue(AuditEvent.objects.filter(event_type="login", actor=self.admin_user).exists())
        self.assertTrue(AuditEvent.objects.filter(event_type="session_rotated_login", actor=self.admin_user).exists())

        logout_response = client.post(
            reverse("logout"),
            {"csrfmiddlewaretoken": client.cookies["csrftoken"].value},
        )
        self.assertEqual(logout_response.status_code, 302)
        self.assertNotIn("_auth_user_id", client.session)
        self.assertTrue(AuditEvent.objects.filter(event_type="logout", actor=self.admin_user).exists())
        self.assertEqual(client.get(reverse("logout")).status_code, 405)

    def test_login_throttling_after_failed_attempts(self):
        client = Client()
        for _ in range(5):
            response = client.post(reverse("login"), {"username": "admin-user", "password": "wrong-password"})
            self.assertEqual(response.status_code, 200)

        response = client.post(reverse("login"), {"username": "admin-user", "password": "wrong-password"})
        self.assertContains(response, "Too many failed login attempts")
        self.assertGreaterEqual(AuditEvent.objects.filter(event_type="login_failed").count(), 5)
        self.assertTrue(AuditEvent.objects.filter(event_type="login_throttled").exists())

    def test_session_rotates_on_privilege_change(self):
        managed_user = User.objects.create_user(username="rotating-user", password="test-password-123")
        managed_user.groups.add(self.admin_group)

        client = Client()
        self.assertTrue(client.login(username="rotating-user", password="test-password-123"))
        original_session_key = client.session.session_key

        managed_user.groups.add(self.super_group)
        response = client.get(reverse("dashboard"))
        self.assertEqual(response.status_code, 200)
        self.assertNotEqual(client.session.session_key, original_session_key)
        self.assertTrue(
            AuditEvent.objects.filter(
                event_type="session_rotated_permission_change",
                actor=managed_user,
            ).exists()
        )

    def test_csrf_rejection_is_logged_for_state_changing_requests(self):
        client = Client(enforce_csrf_checks=True)
        client.force_login(self.admin_user)

        response = client.post(
            reverse("staff"),
            {
                "action": "save_staff",
                "name": "Blocked Staff",
                "email": "blocked.staff@example.com",
                "department": self.department.pk,
                "location": self.location.pk,
                "is_active": "on",
            },
        )
        self.assertEqual(response.status_code, 403)
        self.assertTrue(AuditEvent.objects.filter(event_type="csrf_rejected", actor=self.admin_user).exists())

    def test_attachment_paths_require_authorization_and_are_audited(self):
        asset = self.create_asset(tracking_code="TRK-SEC-FILE", asset_tag="TAG-SEC-FILE", serial_no="SER-SEC-FILE")

        admin_client = Client()
        admin_client.force_login(self.admin_user)
        upload_response = admin_client.post(
            reverse("asset-detail", args=[asset.pk]),
            {"file": self.create_upload(), "description": "Invoice"},
        )
        self.assertEqual(upload_response.status_code, 302)
        attachment = Attachment.objects.get(asset=asset)
        attachment_for_delete = create_attachment(asset, self.create_upload("delete.png"), "Delete me", self.admin_user)
        self.assertTrue(AuditEvent.objects.filter(event_type="attachment_uploaded", actor=self.admin_user).exists())

        anonymous_response = Client().get(reverse("attachment-download", args=[attachment.pk]))
        self.assertEqual(anonymous_response.status_code, 302)

        regular_client = Client()
        regular_client.force_login(self.regular_user)
        denied_upload = regular_client.post(
            reverse("asset-detail", args=[asset.pk]),
            {"file": self.create_upload("denied.png"), "description": "Blocked"},
        )
        self.assertEqual(denied_upload.status_code, 403)
        self.assertEqual(regular_client.get(reverse("attachment-download", args=[attachment.pk])).status_code, 403)
        self.assertEqual(regular_client.post(reverse("attachment-delete", args=[attachment.pk]), {}).status_code, 403)

        download_response = admin_client.get(reverse("attachment-download", args=[attachment.pk]))
        self.assertEqual(download_response.status_code, 200)

        delete_response = admin_client.post(reverse("attachment-delete", args=[attachment_for_delete.pk]), {})
        self.assertEqual(delete_response.status_code, 302)
        self.assertFalse(Attachment.objects.filter(pk=attachment_for_delete.pk).exists())
        self.assertTrue(AuditEvent.objects.filter(event_type="attachment_downloaded", actor=self.admin_user).exists())
        self.assertTrue(AuditEvent.objects.filter(event_type="attachment_deleted", actor=self.admin_user).exists())

    def test_super_admin_can_manage_admin_users(self):
        client = Client()
        client.force_login(self.super_user)

        create_response = client.post(
            reverse("admin-users"),
            {
                "action": "create_user",
                "create-username": "managed-admin",
                "create-email": "managed-admin@example.com",
                "create-password": "managed-password-123",
                "create-role": "admin",
            },
        )
        self.assertEqual(create_response.status_code, 302)

        managed_user = User.objects.get(username="managed-admin")
        self.assertTrue(managed_user.groups.filter(name="admin").exists())
        self.assertTrue(AuditEvent.objects.filter(event_type="admin_user_created", actor=self.super_user).exists())
        self.assertTrue(AuditEvent.objects.filter(event_type="admin_role_changed", actor=self.super_user).exists())

        update_response = client.post(
            reverse("admin-users"),
            {
                "action": "update_user",
                "user_id": managed_user.pk,
                "role": "super_admin",
                "is_active": "on",
            },
        )
        self.assertEqual(update_response.status_code, 302)
        managed_user.refresh_from_db()
        self.assertTrue(managed_user.groups.filter(name="super_admin").exists())

    def test_last_super_admin_cannot_be_demoted(self):
        client = Client()
        client.force_login(self.super_user)

        response = client.post(
            reverse("admin-users"),
            {
                "action": "update_user",
                "user_id": self.super_user.pk,
                "role": "admin",
                "is_active": "on",
            },
        )
        self.assertEqual(response.status_code, 200)
        self.super_user.refresh_from_db()
        self.assertTrue(self.super_user.groups.filter(name="super_admin").exists())
        self.assertContains(response, "At least one active super-admin must remain.")

    def test_service_layer_rejects_non_admin_and_non_super_admin_actions(self):
        asset = self.create_asset(tracking_code="TRK-SVC", asset_tag="TAG-SVC", serial_no="SER-SVC")

        with self.assertRaises(PermissionDenied):
            create_assignment(asset, self.staff_member, date.today(), "", self.regular_user)

        with self.assertRaises(PermissionDenied):
            create_attachment(asset, self.create_upload("service.png"), "Invoice", self.regular_user)

        with self.assertRaises(PermissionDenied):
            create_backup_bundle(BackupBundleKind.MANUAL, actor=self.admin_user)
