from django.core.management.base import BaseCommand
from django.core.mail import send_mail
from django.utils import timezone

from inventory.services import build_operational_report, get_alert_recipient_list, log_event


def _format_days(days_remaining):
    if days_remaining is None:
        return "date unavailable"
    if days_remaining < 0:
        return f"{abs(days_remaining)} days overdue"
    if days_remaining == 0:
        return "due today"
    if days_remaining == 1:
        return "1 day remaining"
    return f"{days_remaining} days remaining"


def _append_due_section(lines, title, items, *, limit=20):
    lines.append(f"{title}: {len(items)}")
    if not items:
        lines.append("- None")
    else:
        for item in items[:limit]:
            asset = item["asset"]
            due_date = item["due_date"].isoformat() if item["due_date"] else "-"
            lines.append(
                f"- {asset.tracking_code} | {asset.status} | due {due_date} | {_format_days(item['days_remaining'])}"
            )
        if len(items) > limit:
            lines.append(f"- ... {len(items) - limit} more")
    lines.append("")


class Command(BaseCommand):
    help = "Send daily reminder emails for due-soon and overdue assets."

    def handle(self, *args, **options):
        recipients = get_alert_recipient_list()
        if not recipients:
            self.stdout.write(self.style.WARNING("No alert recipients configured."))
            return

        report = build_operational_report()
        report_date = timezone.localdate()

        lines = [
            f"Asset management daily summary for {report_date.isoformat()}",
            "",
            "Summary",
            f"- Replacement due soon: {len(report['replacement_due_soon_assets'])}",
            f"- Replacement overdue: {len(report['replacement_overdue_assets'])}",
            f"- Audit due soon: {len(report['audit_due_soon_assets'])}",
            f"- Audit overdue: {len(report['audit_overdue_assets'])}",
            f"- Never audited: {report['never_audited_count']}",
            f"- Warranty due soon: {len(report['warranty_due_soon_assets'])}",
            f"- Warranty overdue: {len(report['warranty_overdue_assets'])}",
            f"- Open repairs: {report['open_repairs_count']}",
            f"- Missing invoices: {report['missing_invoices']}",
            "",
        ]
        _append_due_section(lines, "Replacement due soon", report["replacement_due_soon_assets"])
        _append_due_section(lines, "Replacement overdue", report["replacement_overdue_assets"])
        _append_due_section(lines, "Audit due soon", report["audit_due_soon_assets"])
        _append_due_section(lines, "Audit overdue", report["audit_overdue_assets"])
        _append_due_section(lines, "Never audited", report["never_audited_assets"])
        _append_due_section(lines, "Warranty due soon", report["warranty_due_soon_assets"])
        _append_due_section(lines, "Warranty overdue", report["warranty_overdue_assets"])

        lines.append(f"Open repairs: {report['open_repairs_count']}")
        if not report["open_repairs"]:
            lines.append("- None")
        else:
            for repair in report["open_repairs"][:20]:
                lines.append(
                    f"- {repair.asset.tracking_code} | opened {repair.opened_at.isoformat()} | {repair.issue}"
                )
            if len(report["open_repairs"]) > 20:
                lines.append(f"- ... {len(report['open_repairs']) - 20} more")
        lines.append("")

        lines.append(f"Missing invoices: {report['missing_invoices']}")
        if not report["missing_invoice_assets"]:
            lines.append("- None")
        else:
            for asset in report["missing_invoice_assets"][:20]:
                lines.append(f"- {asset.tracking_code} | {asset.status} | {asset.brand} {asset.model}")
            if len(report["missing_invoice_assets"]) > 20:
                lines.append(f"- ... {len(report['missing_invoice_assets']) - 20} more")

        send_mail(
            subject=f"Asset management daily reminder - {report_date.isoformat()}",
            message="\n".join(lines),
            from_email=None,
            recipient_list=recipients,
            fail_silently=False,
        )
        log_event(
            "daily_alerts_sent",
            description="Daily alert summary sent.",
            metadata={
                "recipients": recipients,
                "replacement_due_soon": len(report["replacement_due_soon_assets"]),
                "replacement_overdue": len(report["replacement_overdue_assets"]),
                "audit_due_soon": len(report["audit_due_soon_assets"]),
                "audit_overdue": len(report["audit_overdue_assets"]),
                "never_audited": report["never_audited_count"],
                "warranty_due_soon": len(report["warranty_due_soon_assets"]),
                "warranty_overdue": len(report["warranty_overdue_assets"]),
                "open_repairs": report["open_repairs_count"],
                "missing_invoices": report["missing_invoices"],
            },
        )
        self.stdout.write(self.style.SUCCESS(f"Alerts sent to {', '.join(recipients)}"))
