from django.core.management.base import BaseCommand

from inventory.backups import create_backup_bundle
from inventory.models import BackupBundleKind


class Command(BaseCommand):
    help = "Create the nightly backup bundle."

    def handle(self, *args, **options):
        bundle = create_backup_bundle(BackupBundleKind.NIGHTLY)
        self.stdout.write(self.style.SUCCESS(f"Created nightly backup {bundle.bundle_id}"))
