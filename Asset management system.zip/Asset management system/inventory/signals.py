from django.contrib.auth import get_user_model
from django.contrib.auth.models import Group
from django.contrib.auth.signals import user_logged_in, user_logged_out, user_login_failed
from django.db.backends.signals import connection_created
from django.db.models.signals import m2m_changed, post_migrate, post_save
from django.dispatch import receiver

from .models import SystemSetting, UserSecurityProfile
from .permissions import ADMIN_ROLE, SUPER_ADMIN_ROLE
from .services import ensure_runtime_security_state, log_event


User = get_user_model()


@receiver(connection_created)
def configure_sqlite_pragmas(sender, connection, **kwargs):
    if connection.vendor != "sqlite":
        return
    with connection.cursor() as cursor:
        cursor.execute("PRAGMA foreign_keys = ON;")
        cursor.execute("PRAGMA journal_mode = WAL;")
        cursor.fetchone()


@receiver(post_migrate)
def ensure_seed_data(sender, **kwargs):
    Group.objects.get_or_create(name=ADMIN_ROLE)
    Group.objects.get_or_create(name=SUPER_ADMIN_ROLE)
    SystemSetting.objects.get_or_create(key="maintenance_mode", defaults={"value": False})
    SystemSetting.objects.get_or_create(key="alert_recipients", defaults={"value": []})
    ensure_runtime_security_state()


@receiver(post_save, sender=User)
def ensure_user_security_profile(sender, instance, created, update_fields=None, **kwargs):
    profile, profile_created = UserSecurityProfile.objects.get_or_create(user=instance)
    privilege_fields = {"is_active", "is_staff", "is_superuser"}
    if created or profile_created:
        return
    if update_fields is None or privilege_fields.intersection(update_fields):
        profile.save(update_fields=["permissions_version"])


@receiver(m2m_changed, sender=User.groups.through)
@receiver(m2m_changed, sender=User.user_permissions.through)
def refresh_user_security_profile(sender, instance, **kwargs):
    profile, _ = UserSecurityProfile.objects.get_or_create(user=instance)
    profile.save()


@receiver(user_logged_in)
def audit_login(sender, request, user, **kwargs):
    request.session.cycle_key()
    profile, _ = UserSecurityProfile.objects.get_or_create(user=user)
    request.session["permissions_version"] = profile.permissions_version.isoformat()
    log_event("login", actor=user, request=request, description="User login.")
    log_event("session_rotated_login", actor=user, request=request, description="Session rotated after login.")


@receiver(user_logged_out)
def audit_logout(sender, request, user, **kwargs):
    if user:
        log_event("logout", actor=user, request=request, description="User logout.")


@receiver(user_login_failed)
def audit_login_failure(sender, credentials, request, **kwargs):
    username = credentials.get("username", "")
    log_event(
        "login_failed",
        request=request,
        success=False,
        metadata={"username": username},
        description="Failed login attempt.",
    )
