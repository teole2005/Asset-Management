import json
import shutil
import sqlite3
import tempfile
import zipfile
from datetime import timedelta
from io import StringIO
from pathlib import Path

from django.conf import settings
from django.core.exceptions import ValidationError
from django.core.management import call_command
from django.db import connections
from django.utils import timezone

from .models import Attachment, BackupBundle, BackupBundleKind, ImportBatch
from .permissions import require_super_admin_access
from .services import ensure_runtime_security_state, get_setting, log_event, touch_instance
from .utils import hash_file, make_json_safe


def _database_path():
    return Path(settings.DATABASES["default"]["NAME"])


def _backup_root():
    return Path(settings.BACKUP_ROOT)


def _backup_db_snapshot(snapshot_path):
    database_path = _database_path()
    source = sqlite3.connect(database_path)
    target = sqlite3.connect(snapshot_path)
    try:
        source.backup(target)
    finally:
        source.close()
        target.close()


def _snapshot_media_paths(snapshot_path):
    media_paths = set()
    snapshot_db = sqlite3.connect(snapshot_path)
    try:
        attachment_rows = snapshot_db.execute(
            f"SELECT file FROM {Attachment._meta.db_table} WHERE file <> ''"
        ).fetchall()
        import_rows = snapshot_db.execute(
            f"SELECT source_file FROM {ImportBatch._meta.db_table} WHERE source_file <> ''"
        ).fetchall()
    finally:
        snapshot_db.close()
    for relative_path, in attachment_rows:
        media_paths.add(relative_path)
    for relative_path, in import_rows:
        media_paths.add(relative_path)
    return sorted(media_paths)


def _schema_version_rows(database_path=None):
    if database_path is not None:
        database = sqlite3.connect(database_path)
        try:
            rows = database.execute(
                "SELECT app, name FROM django_migrations ORDER BY app, name"
            ).fetchall()
        finally:
            database.close()
    else:
        with connections["default"].cursor() as cursor:
            cursor.execute("SELECT app, name FROM django_migrations ORDER BY app, name")
            rows = cursor.fetchall()
    return [[app, name] for app, name in rows]


def _normalize_schema_rows(rows):
    normalized_rows = []
    for row in rows or []:
        if isinstance(row, dict):
            app = row.get("app")
            name = row.get("name")
        else:
            try:
                app, name = row
            except (TypeError, ValueError) as exc:
                raise ValidationError("Backup manifest schema version is invalid.") from exc
        normalized_rows.append((str(app), str(name)))
    return normalized_rows


def _validate_archive(bundle):
    archive_path = Path(bundle.archive_path)
    if not archive_path.exists():
        raise ValidationError("Backup archive file is missing.")
    if not zipfile.is_zipfile(archive_path):
        raise ValidationError("Backup archive is not a valid ZIP file.")
    if hash_file(archive_path) != bundle.sha256:
        raise ValidationError("Backup archive hash does not match the recorded bundle hash.")
    return archive_path


def _load_manifest(temp_dir_path):
    manifest_path = temp_dir_path / "manifest.json"
    if not manifest_path.exists():
        raise ValidationError("Backup manifest is missing.")
    try:
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise ValidationError("Backup manifest could not be read.") from exc

    required_keys = {"bundle_id", "created_at", "schema_version", "db_snapshot", "media"}
    if not required_keys.issubset(manifest):
        raise ValidationError("Backup manifest is incomplete.")
    db_snapshot = manifest.get("db_snapshot")
    if not isinstance(db_snapshot, dict):
        raise ValidationError("Backup manifest snapshot entry is invalid.")
    if not {"filename", "sha256", "size_bytes"}.issubset(db_snapshot):
        raise ValidationError("Backup manifest snapshot entry is incomplete.")
    if not isinstance(manifest.get("media"), list):
        raise ValidationError("Backup manifest media entry is invalid.")
    return manifest


def _validate_manifest_metadata(bundle, manifest):
    if manifest["bundle_id"] != bundle.bundle_id:
        raise ValidationError("Backup manifest bundle ID does not match the selected backup.")
    if bundle.manifest and make_json_safe(manifest) != make_json_safe(bundle.manifest):
        raise ValidationError("Backup manifest does not match the recorded bundle metadata.")


def _validate_schema_version(manifest, database_path=None, expected_schema=None):
    try:
        recorded_schema = _normalize_schema_rows(manifest.get("schema_version"))
        expected_schema = _normalize_schema_rows(expected_schema or _schema_version_rows())
    except (sqlite3.Error, ValidationError) as exc:
        raise ValidationError("Backup schema version could not be validated.") from exc
    if recorded_schema != expected_schema:
        raise ValidationError("Backup schema version does not match the running application schema.")
    if database_path is not None:
        try:
            restored_schema = _normalize_schema_rows(_schema_version_rows(database_path=database_path))
        except sqlite3.Error as exc:
            raise ValidationError("Restored database schema could not be validated.") from exc
        if restored_schema != expected_schema:
            raise ValidationError("Restored database schema does not match the running application schema.")


def _validate_sqlite_integrity(database_path):
    database = None
    try:
        database = sqlite3.connect(database_path)
        row = database.execute("PRAGMA integrity_check;").fetchone()
    except sqlite3.Error as exc:
        raise ValidationError("SQLite integrity check could not be completed.") from exc
    finally:
        if database is not None:
            database.close()
    if not row or row[0] != "ok":
        raise ValidationError("SQLite integrity check failed.")


def _bundle_state(bundle):
    return {
        "bundle_id": bundle.bundle_id,
        "kind": bundle.kind,
        "archive_name": bundle.archive_name,
        "archive_path": bundle.archive_path,
        "size_bytes": bundle.size_bytes,
        "manifest": make_json_safe(bundle.manifest),
        "sha256": bundle.sha256,
        "created_at": bundle.created_at,
        "updated_at": bundle.updated_at,
    }


def _restore_bundle_record(bundle_state):
    bundle, _ = BackupBundle.objects.update_or_create(
        bundle_id=bundle_state["bundle_id"],
        defaults={
            "kind": bundle_state["kind"],
            "archive_name": bundle_state["archive_name"],
            "archive_path": bundle_state["archive_path"],
            "size_bytes": bundle_state["size_bytes"],
            "manifest": bundle_state["manifest"],
            "sha256": bundle_state["sha256"],
        },
    )
    BackupBundle.objects.filter(pk=bundle.pk).update(
        created_at=bundle_state["created_at"],
        updated_at=bundle_state["updated_at"],
    )
    return BackupBundle.objects.get(pk=bundle.pk)


def create_backup_bundle(kind, actor=None, request=None):
    if actor is not None:
        require_super_admin_access(actor)
    backup_root = _backup_root()
    backup_root.mkdir(parents=True, exist_ok=True)
    bundle_id = f"BKP-{timezone.now():%Y%m%d%H%M%S%f}"

    with tempfile.TemporaryDirectory() as temp_dir:
        temp_dir_path = Path(temp_dir)
        snapshot_path = temp_dir_path / "snapshot.sqlite3"
        _backup_db_snapshot(snapshot_path)

        media_root = Path(settings.MEDIA_ROOT)
        staged_media_dir = temp_dir_path / "media"
        staged_media_dir.mkdir(exist_ok=True)
        media_manifest = []
        for relative_path in _snapshot_media_paths(snapshot_path):
            source_path = media_root / relative_path
            if not source_path.exists():
                continue
            destination_path = staged_media_dir / relative_path
            destination_path.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(source_path, destination_path)
            media_manifest.append(
                {
                    "path": relative_path,
                    "sha256": hash_file(destination_path),
                    "size_bytes": destination_path.stat().st_size,
                }
            )

        manifest = {
            "bundle_id": bundle_id,
            "kind": kind,
            "created_at": timezone.now().isoformat(),
            "schema_version": _schema_version_rows(database_path=snapshot_path),
            "db_snapshot": {
                "filename": "snapshot.sqlite3",
                "sha256": hash_file(snapshot_path),
                "size_bytes": snapshot_path.stat().st_size,
            },
            "media": media_manifest,
        }
        manifest = make_json_safe(manifest)
        manifest_path = temp_dir_path / "manifest.json"
        manifest_path.write_text(json.dumps(manifest, indent=2), encoding="utf-8")

        archive_name = f"{bundle_id}.zip"
        archive_path = backup_root / archive_name
        with zipfile.ZipFile(archive_path, "w", zipfile.ZIP_DEFLATED) as archive:
            archive.write(snapshot_path, arcname="snapshot.sqlite3")
            archive.write(manifest_path, arcname="manifest.json")
            for media_file in staged_media_dir.rglob("*"):
                if media_file.is_file():
                    archive.write(media_file, arcname=str(media_file.relative_to(temp_dir_path)))

    bundle = BackupBundle(
        bundle_id=bundle_id,
        kind=kind,
        archive_name=archive_name,
        archive_path=str(archive_path),
        size_bytes=archive_path.stat().st_size,
        manifest=manifest,
        sha256=hash_file(archive_path),
    )
    touch_instance(bundle, actor)
    bundle.save()
    log_event(
        "backup_created",
        actor=actor,
        target=bundle,
        request=request,
        description=f"Backup bundle {bundle_id} created.",
        metadata={"kind": kind},
    )
    _prune_nightly_backups()
    return bundle


def _prune_nightly_backups():
    retention_days = get_setting("backup_retention_days", settings.BACKUP_RETENTION_DAYS)
    cutoff = timezone.now() - timedelta(days=retention_days)
    for bundle in BackupBundle.objects.filter(kind=BackupBundleKind.NIGHTLY, created_at__lt=cutoff):
        Path(bundle.archive_path).unlink(missing_ok=True)
        bundle.delete()


def _validate_backup_contents(temp_dir_path, manifest):
    snapshot_path = temp_dir_path / manifest["db_snapshot"]["filename"]
    if not snapshot_path.exists():
        raise ValidationError("Backup snapshot file is missing.")
    if snapshot_path.stat().st_size != manifest["db_snapshot"]["size_bytes"]:
        raise ValidationError("Backup snapshot size does not match manifest.")
    if hash_file(snapshot_path) != manifest["db_snapshot"]["sha256"]:
        raise ValidationError("Backup snapshot hash does not match manifest.")
    for media_entry in manifest["media"]:
        media_path = temp_dir_path / "media" / media_entry["path"]
        if not media_path.exists():
            raise ValidationError(f"Missing media file in backup: {media_entry['path']}")
        if media_path.stat().st_size != media_entry["size_bytes"]:
            raise ValidationError(f"Backup media size mismatch: {media_entry['path']}")
        if hash_file(media_path) != media_entry["sha256"]:
            raise ValidationError(f"Backup media hash mismatch: {media_entry['path']}")


def _replace_live_database(source_path, destination_path):
    source = sqlite3.connect(source_path)
    destination = sqlite3.connect(destination_path)
    try:
        source.backup(destination)
    finally:
        source.close()
        destination.close()


def _replace_media_tree(source_root, destination_root):
    source_root = Path(source_root) if source_root else None
    destination_root = Path(destination_root)
    if destination_root.exists():
        shutil.rmtree(destination_root)
    if source_root and source_root.exists():
        shutil.copytree(source_root, destination_root)
    else:
        destination_root.mkdir(parents=True, exist_ok=True)


def _validate_restored_media(media_root, manifest):
    media_root = Path(media_root)
    for media_entry in manifest["media"]:
        restored_path = media_root / media_entry["path"]
        if not restored_path.exists():
            raise ValidationError(f"Restored media file is missing: {media_entry['path']}")
        if restored_path.stat().st_size != media_entry["size_bytes"]:
            raise ValidationError(f"Restored media size mismatch: {media_entry['path']}")
        if hash_file(restored_path) != media_entry["sha256"]:
            raise ValidationError(f"Restored media hash mismatch: {media_entry['path']}")


def _run_post_restore_checks(manifest, expected_schema):
    ensure_runtime_security_state()
    _validate_sqlite_integrity(_database_path())
    _validate_schema_version(manifest, database_path=_database_path(), expected_schema=expected_schema)
    _validate_restored_media(settings.MEDIA_ROOT, manifest)
    try:
        call_command("check", stdout=StringIO(), stderr=StringIO())
    except Exception as exc:
        raise ValidationError("Django system checks failed after restore.") from exc


def restore_backup_bundle(bundle, actor, request=None):
    require_super_admin_access(actor)
    if not get_setting("maintenance_mode", False):
        raise ValidationError("Enable maintenance mode before restoring a backup.")

    safety_bundle = create_backup_bundle(BackupBundleKind.PRE_RESTORE, actor=actor, request=request)
    bundle_state = _bundle_state(bundle)
    safety_bundle_state = _bundle_state(safety_bundle)
    expected_schema = _schema_version_rows()

    with tempfile.TemporaryDirectory() as temp_dir:
        temp_dir_path = Path(temp_dir)
        archive_path = _validate_archive(bundle)
        with zipfile.ZipFile(archive_path) as archive:
            archive.extractall(temp_dir_path)
        manifest = _load_manifest(temp_dir_path)
        _validate_manifest_metadata(bundle, manifest)
        _validate_backup_contents(temp_dir_path, manifest)
        _validate_schema_version(manifest, expected_schema=expected_schema)

        snapshot_path = temp_dir_path / manifest["db_snapshot"]["filename"]
        media_restore_path = temp_dir_path / "media"
        _validate_sqlite_integrity(snapshot_path)

        connections.close_all()
        database_path = _database_path()
        rollback_db_path = temp_dir_path / "rollback.sqlite3"
        rollback_media_path = temp_dir_path / "rollback_media"
        _backup_db_snapshot(rollback_db_path)
        if Path(settings.MEDIA_ROOT).exists():
            shutil.copytree(settings.MEDIA_ROOT, rollback_media_path)

        try:
            _replace_live_database(snapshot_path, database_path)
            _replace_media_tree(media_restore_path, settings.MEDIA_ROOT)
            _run_post_restore_checks(manifest, expected_schema)
            restored_bundle = _restore_bundle_record(bundle_state)
            _restore_bundle_record(safety_bundle_state)
        except Exception as exc:
            _replace_live_database(rollback_db_path, database_path)
            _replace_media_tree(
                rollback_media_path if rollback_media_path.exists() else None,
                settings.MEDIA_ROOT,
            )
            ensure_runtime_security_state()
            if isinstance(exc, ValidationError):
                raise
            raise ValidationError(
                "Backup restore failed before the system could be returned to service."
            ) from exc

    log_event(
        "backup_restored",
        actor=actor,
        target=restored_bundle,
        request=request,
        description=f"Backup bundle {bundle.bundle_id} restored.",
    )
    return restored_bundle
