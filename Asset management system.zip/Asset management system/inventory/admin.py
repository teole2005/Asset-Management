from django.contrib import admin

from .models import (
    Asset,
    AssetType,
    Assignment,
    Attachment,
    AuditEvent,
    BackupBundle,
    Department,
    ImportBatch,
    Location,
    PhysicalAudit,
    RepairLog,
    SaleDisposal,
    StaffMember,
    SystemSetting,
    UserSecurityProfile,
    Vendor,
)


@admin.register(Asset)
class AssetAdmin(admin.ModelAdmin):
    list_display = ("tracking_code", "asset_tag", "type", "status", "brand", "model")
    search_fields = ("tracking_code", "asset_tag", "serial_no", "brand", "model")
    list_filter = ("status", "type", "department")


admin.site.register(AssetType)
admin.site.register(Assignment)
admin.site.register(Attachment)
admin.site.register(AuditEvent)
admin.site.register(BackupBundle)
admin.site.register(Department)
admin.site.register(ImportBatch)
admin.site.register(Location)
admin.site.register(PhysicalAudit)
admin.site.register(RepairLog)
admin.site.register(SaleDisposal)
admin.site.register(StaffMember)
admin.site.register(SystemSetting)
admin.site.register(UserSecurityProfile)
admin.site.register(Vendor)
