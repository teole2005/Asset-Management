from django.contrib.auth.mixins import UserPassesTestMixin
from django.core.exceptions import PermissionDenied


ADMIN_ROLE = "admin"
SUPER_ADMIN_ROLE = "super_admin"
PUBLIC_URL_NAMES = frozenset({"login", "logout"})
SUPER_ADMIN_URL_NAMES = frozenset(
    {
        "backups",
        "backup-download",
        "backup-restore",
        "settings",
        "audit-log",
        "admin-users",
    }
)
ADMIN_URL_NAMES = frozenset(
    {
        "dashboard",
        "asset-list",
        "asset-create",
        "asset-detail",
        "asset-edit",
        "asset-assign",
        "assignment-return",
        "asset-repair",
        "repair-close",
        "asset-sell",
        "attachment-download",
        "attachment-delete",
        "audits",
        "imports",
        "import-detail",
        "exports",
        "staff",
        "departments",
        "vendors",
    }
)


def has_admin_access(user):
    if not user.is_authenticated:
        return False
    if user.is_superuser:
        return True
    return user.groups.filter(name__in=[ADMIN_ROLE, SUPER_ADMIN_ROLE]).exists()


def has_super_admin_access(user):
    if not user.is_authenticated:
        return False
    if user.is_superuser:
        return True
    return user.groups.filter(name=SUPER_ADMIN_ROLE).exists()


def get_user_admin_role(user):
    if not getattr(user, "is_authenticated", False):
        return ""
    if has_super_admin_access(user):
        return SUPER_ADMIN_ROLE
    if has_admin_access(user):
        return ADMIN_ROLE
    return ""


def required_role_for_url_name(url_name):
    if not url_name or url_name in PUBLIC_URL_NAMES:
        return ""
    if url_name in SUPER_ADMIN_URL_NAMES:
        return SUPER_ADMIN_ROLE
    if url_name in ADMIN_URL_NAMES:
        return ADMIN_ROLE
    return ""


def require_admin_access(user):
    if not has_admin_access(user):
        raise PermissionDenied("Admin access required.")


def require_super_admin_access(user):
    if not has_super_admin_access(user):
        raise PermissionDenied("Super-admin access required.")


class AdminRequiredMixin(UserPassesTestMixin):
    def test_func(self):
        return has_admin_access(self.request.user)


class SuperAdminRequiredMixin(UserPassesTestMixin):
    def test_func(self):
        return has_super_admin_access(self.request.user)
