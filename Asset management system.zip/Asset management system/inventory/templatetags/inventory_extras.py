from django import template


register = template.Library()


@register.filter
def get_item(mapping, key):
    if mapping is None:
        return ""
    return mapping.get(key, "")


@register.filter
def yes_no(value):
    return "Yes" if value else "No"


@register.filter
def has_group(user, group_name):
    if not getattr(user, "is_authenticated", False):
        return False
    if user.is_superuser:
        return True
    return user.groups.filter(name=group_name).exists()
