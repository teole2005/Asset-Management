import csv
import hashlib
from datetime import date, datetime, timedelta
from decimal import Decimal, InvalidOperation
from pathlib import Path


def clean_text(value):
    if value is None:
        return ""
    return str(value).strip()


def parse_date(value):
    if value in (None, ""):
        return None
    if isinstance(value, datetime):
        return value.date()
    if isinstance(value, date):
        return value
    text = clean_text(value)
    for fmt in ("%Y-%m-%d", "%d/%m/%Y", "%m/%d/%Y", "%d-%m-%Y"):
        try:
            return datetime.strptime(text, fmt).date()
        except ValueError:
            continue
    return None


def parse_currency(value):
    if value in (None, ""):
        return None
    if isinstance(value, Decimal):
        return value
    if isinstance(value, (int, float)):
        return Decimal(str(value))
    text = clean_text(value).replace("RM", "").replace(",", "")
    try:
        return Decimal(text)
    except InvalidOperation:
        return None


def parse_lifespan_months(value):
    if value in (None, ""):
        return None
    if isinstance(value, int):
        return value
    text = clean_text(value).lower().replace("months", "").replace("month", "").strip()
    try:
        return int(float(text))
    except ValueError:
        return None


def add_months(value, months):
    if value is None or months is None:
        return None
    month_index = value.month - 1 + months
    year = value.year + month_index // 12
    month = month_index % 12 + 1
    max_days = [
        31,
        29 if year % 4 == 0 and (year % 100 != 0 or year % 400 == 0) else 28,
        31,
        30,
        31,
        30,
        31,
        31,
        30,
        31,
        30,
        31,
    ]
    day = min(value.day, max_days[month - 1])
    return date(year, month, day)


def years_used(start_date, end_date=None):
    if not start_date:
        return None
    end_date = end_date or date.today()
    return round((end_date - start_date).days / 365.25, 1)


def days_until(value, today=None):
    if not value:
        return None
    today = today or date.today()
    return (value - today).days


def hash_file(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for chunk in iter(lambda: handle.read(8192), b""):
            digest.update(chunk)
    return digest.hexdigest()


def csv_bytes(rows, headers):
    from io import StringIO

    stream = StringIO()
    writer = csv.DictWriter(stream, fieldnames=headers)
    writer.writeheader()
    for row in rows:
        writer.writerow(row)
    return stream.getvalue().encode("utf-8-sig")


def next_due_date(reference_date, cadence_days):
    if not reference_date:
        return None
    return reference_date + timedelta(days=cadence_days)


def make_json_safe(value):
    if isinstance(value, dict):
        return {str(key): make_json_safe(item) for key, item in value.items()}
    if isinstance(value, list):
        return [make_json_safe(item) for item in value]
    if isinstance(value, tuple):
        return [make_json_safe(item) for item in value]
    if isinstance(value, Decimal):
        return str(value)
    if isinstance(value, (date, datetime)):
        return value.isoformat()
    return value
